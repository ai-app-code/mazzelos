# 📋 TOKİ Veri Uygulaması - Proje Özeti (v2 Prod-Ready)

## 🎯 Proje Hedefleri

| Hedef | Açıklama | Durum |
|-------|----------|-------|
| **Veri Çekme** | TOKİ'den otomatik veri çekme (Cheerio + Playwright) | ✅ Tasarlandı |
| **Seviye-Merkezli Güncelleme** | ↑=updated, ↓=regressed, =&alan=meta_updated | ✅ Tasarlandı |
| **Veri Saklama** | PostgreSQL'de verileri saklama + tarihçe | ✅ Tasarlandı |
| **Senkronizasyon** | BullMQ ile periyodik (02:00) + manuel tetik | ✅ Tasarlandı |
| **Değişim Takibi** | Snapshot + Change log (TRACKED_FIELDS) | ✅ Tasarlandı |
| **Modern UI** | Next.js + Tailwind + shadcn/ui | ✅ Tasarlandı |
| **Analitik** | Dashboard, timeline, diff viewer | ✅ Tasarlandı |
| **Export** | CSV + JSON (V2'de Excel) | ✅ Tasarlandı |
| **Admin Panel** | JWT auth, sync trigger, logs | ✅ Tasarlandı |
| **Monitoring** | Winston, Sentry, Slack alerts | ✅ Tasarlandı |

---

## 🛠️ Teknoloji Stack (Onaylı)

### Frontend
```
┌──────────────────────────────────┐
│ Next.js 14 (App Router)          │
│ + Tailwind CSS 3.x               │
│ + shadcn/ui Components           │
│ + TanStack Query (React Query)   │
│ + React Hook Form + Zod          │
│ + Recharts (Charts)              │
│ + Lucide React (Icons)           │
└──────────────────────────────────┘
```

### Backend & Ingest
```
┌──────────────────────────────────┐
│ Express.js + Node.js 20          │
│ + Prisma ORM (PostgreSQL 15)     │
│ + Zod (Validation)               │
│ + Cheerio (HTML parse)           │
│ + Playwright (Fallback)          │
│ + BullMQ (Job Queue)             │
│ + Redis 7 (Cache + Queue)        │
│ + Winston (Logging)              │
│ + Sentry (Error Tracking)        │
└──────────────────────────────────┘
```

### DevOps & Monitoring
```
┌──────────────────────────────────┐
│ Docker + docker-compose          │
│ PostgreSQL 15 + Redis 7          │
│ Node.js 20+                      │
│ pnpm (Package Manager)           │
│ GitHub Actions (CI/CD)           │
│ Sentry (FE/BE monitoring)        │
│ Slack Webhooks (Alerts)          │
└──────────────────────────────────┘
```

---

## 📁 Klasör Yapısı (Özet)

```
tokidb/app/
├── frontend/                 # Next.js Frontend
│   ├── app/                  # Pages & layouts
│   ├── components/           # React components
│   ├── lib/                  # Utilities & hooks
│   └── public/               # Static files
│
├── backend/                  # Express Backend
│   ├── src/
│   │   ├── routes/           # API endpoints
│   │   ├── services/         # Business logic
│   │   ├── jobs/             # Cron jobs
│   │   └── models/           # Database models
│   └── prisma/               # Database schema
│
├── shared/                   # Shared types & constants
├── docker-compose.yml        # Docker setup
└── README.md
```

---

## 🗄️ Veritabanı Tabloları

| Tablo | Amaç | Kayıt Sayısı |
|-------|------|-------------|
| **cities** | İller | ~81 |
| **project_types** | Proje tipleri | ~30 |
| **projects** | Projeler | ~5000+ |
| **sync_history** | Senkronizasyon geçmişi | Artan |
| **project_changes** | Değişiklik geçmişi | Artan |

---

## 🔄 Senkronizasyon Akışı (Seviye-Merkezli)

```
1. FETCH (TOKİ'den veri çek)
   ├─ GET /illere-gore-projeler (60s timeout, 3 retry)
   ├─ HTML snapshot logu (anomali kontrol)
   └─ Cheerio parse (fallback: Playwright)

2. PARSE & VALIDATE (Ayrıştır ve doğrula)
   ├─ Parser auto-detect (v1, v2, v3)
   ├─ Zod schema validation
   ├─ Seviye ayrıştırması (%, metin, varyantlar)
   ├─ Duplicate detection (Levenshtein)
   └─ Validation error logging

3. COMPARE (Veritabanı ile karşılaştır)
   ├─ Seviye ↑ → updated (+snapshot)
   ├─ Seviye ↓ → regressed (+snapshot)
   ├─ Seviye = & alan değişti → meta_updated (+snapshot)
   ├─ Yeni → created
   └─ Kayboldu → deleted (soft; is_active=false)

4. STORE (Veritabanına kaydet)
   ├─ UPSERT cities & project_types
   ├─ INSERT/UPDATE projects
   ├─ CREATE snapshots (seçici: 180 gün sıcak, >180 gün zstd arşiv)
   ├─ LOG changes (TRACKED_FIELDS)
   └─ UPDATE sync_history

5. ALERT (Uyarı gönder)
   ├─ Job başarısız → Slack + Email + Sentry
   ├─ HTML anomali → Slack + Sentry
   └─ Parse error → Log + Sentry
```

---

## 🎨 Frontend Sayfaları (Revize)

| Sayfa | Özellikler |
|-------|-----------|
| **Dashboard** | 📊 Toplam proje, ortalama Seviye, bugün created/updated/regressed/deleted, şehir/tip dağılım |
| **Projects** | 📋 Filtre (İl, Tip, Durum, Seviye, Regressed), Seviye ↑/↓ ikonlar, bulk export |
| **Project Detail** | 🔍 Timeline (created→updated→regressed), diff viewer, snapshot karşılaştırma |
| **Sync Panel** | 🔄 Son 10 job durumu, "Şimdi Tara" butonu (admin), ingest logları |
| **Settings** | ⚙️ (V2) Konfigürasyon, manuel sync trigger |

---

## 🔌 API Endpoints (Revize)

```
GET    /api/cities                           # {id, name, project_count, avg_seviye}
GET    /api/project-types

GET    /api/projects?city_id=&type_id=&status=&min_seviye=&q=&page=&size=&regressed_only=
GET    /api/projects/:toki_id                # {project, recent_changes[0..N]}
GET    /api/projects/:toki_id/changes?limit=

GET    /api/export.csv?...                   # CSV export
GET    /api/export.json?...                  # JSON export

GET    /api/sync/status                      # {last_job, created, updated, regressed, deleted, errors}
POST   /api/admin/sync/trigger               # JWT required, rate-limit 1/5dk

GET    /api/analytics/summary                # {total, avg_seviye, by_city, by_type}
GET    /api/analytics/changes?days=          # Değişiklik geçmişi

POST   /auth/login                           # {username, password} → JWT token
```

---

## ⏰ Senkronizasyon Takvimi

```
Periyodik Sync:
├─ Her gün 02:00 UTC'de çalış
├─ Haftalık tam tarama (Pazartesi 03:00)
└─ Aylık veritabanı temizliği

Manual Sync:
├─ Kullanıcı dashboard'dan tetikleyebilir
├─ Rate limit: 1 istek/5 dakika
└─ Timeout: 5 dakika
```

---

## 📊 Performans Hedefleri

| Metrik | Hedef | Açıklama |
|--------|-------|----------|
| İlk yükleme | < 2s | Dashboard açılış |
| Proje listesi | < 500ms | API response |
| Senkronizasyon | < 5 dakika | Tam tarama |
| Database query | < 100ms | Ortalama |
| API response | < 200ms | Ortalama |

---

## 📅 Geliştirme Takvimi (Revize)

| Faza | Görev | Süre | Durum |
|------|-------|------|-------|
| **F1** | İskelet & Şema (Monorepo, Docker, Prisma, JWT, Zod, parser v1) | 2–3 gün | 🚀 Başlıyor |
| **F2** | Ingest & Diff (Parser auto-detect, Playwright, diff kuralları, snapshots) | 3–4 gün | ⏳ Sonra |
| **F3** | REST API (Liste, detay, changes, export, BullMQ, Sentry) | 3 gün | ⏳ Sonra |
| **F4** | Frontend UI (Dashboard, Projects, Detail, Sync Panel) | 4 gün | ⏳ Sonra |
| **F5** | Stabilizasyon (Testler, temizlik, dokümantasyon) | 2 gün | ⏳ Sonra |
| **TOPLAM** | | **14–16 gün** | Prod-Ready |

---

## ✅ Başarı Kriterleri (Prod-Ready)

- [ ] Prisma şema + migration tamamlandı
- [ ] Docker Compose (postgres, redis, api, web) çalışıyor
- [ ] Parser v1 (Cheerio) + Playwright fallback çalışıyor
- [ ] Zod validation + enum'lar tanımlandı
- [ ] JWT admin auth + rate-limit aktif
- [ ] BullMQ job (02:00 + manuel) çalışıyor
- [ ] Winston logger + Sentry integration aktif
- [ ] Alert mekanizması (Slack, Email) çalışıyor
- [ ] REST API (liste, detay, changes, export) çalışıyor
- [ ] Frontend (Dashboard, Projects, Detail, Sync Panel) responsive
- [ ] Parser fixtures (≥20 test case) geçiyor
- [ ] E2E testler geçiyor
- [ ] Deployment başarılı
- [ ] Monitoring aktif (SLO ≥99%/ay)

---

## 🔐 Güvenlik Özellikleri

✅ Environment variables (.env)
✅ Input validation (Zod)
✅ SQL injection prevention (Prisma ORM)
✅ CORS configuration
✅ Rate limiting
✅ Helmet.js (security headers)
✅ HTTPS only
✅ No sensitive data in logs

---

## 📦 Bağımlılıklar (Özet)

### Frontend (~20 paket)
- next, react, tailwindcss, shadcn-ui
- @tanstack/react-query, react-hook-form, zod
- recharts, lucide-react

### Backend (~15 paket)
- express, prisma, @prisma/client
- axios, cheerio, bull, redis
- zod, winston, helmet, express-rate-limit

---

## 💰 Tahmini Maliyet

| Kalem | Maliyet |
|-------|---------|
| Geliştirme (15 gün) | ~$3,000-5,000 |
| Server (aylık) | $50-100 |
| Database (aylık) | $20-50 |
| CDN (aylık) | $10-20 |
| **TOPLAM (ilk ay)** | **~$3,080-5,170** |

---

## 🎓 Öğrenilen Dersler

### Yapılması Gerekenler ✅
- Veritabanı tasarımı kritik
- API design önemli
- Performance monitoring gerekli
- Security best practices uygula
- Responsive tasarım zorunlu

### Yapılmaması Gerekenler ❌
- Tüm verileri HTML'de gömmek
- Pagination olmadan tüm verileri göstermek
- Client-side filtreleme için çok fazla veri
- Mobile-first yaklaşım olmadan tasarım
- Monitoring olmadan deployment

---

---

**Hazırlayan:** Augment Agent (Revize)
**Tarih:** 2025-10-24
**Durum:** Prod-Ready Plan ✅ → F1 Başlangıç 🚀

