# 🔧 TOKİ Veri Uygulaması - Teknik Detaylar (v2 Prod-Ready)

## 1️⃣ Frontend Teknolojileri

### Next.js 14 (App Router)
```typescript
// Avantajları:
✅ Server-side rendering (SSR)
✅ Static generation (SSG)
✅ API routes built-in
✅ Image optimization
✅ Font optimization
✅ TypeScript support
```

### Tailwind CSS + shadcn/ui
```typescript
// Neden?
✅ Hızlı UI geliştirme
✅ Responsive design
✅ Dark mode support
✅ Accessibility (a11y)
✅ Customizable components
```

### TanStack Query (React Query)
```typescript
// Neden?
✅ Server state management
✅ Automatic caching
✅ Background refetching
✅ Optimistic updates
✅ Infinite queries
```

---

## 2️⃣ Backend Teknolojileri

### Express.js
```typescript
// Neden?
✅ Lightweight
✅ Flexible routing
✅ Middleware ecosystem
✅ Easy to test
✅ Production-ready
```

### Prisma ORM
```typescript
// Neden?
✅ Type-safe queries
✅ Auto-generated migrations
✅ Relation handling
✅ Query optimization
✅ Easy to use
```

### Bull (Redis Queue)
```typescript
// Neden?
✅ Job scheduling
✅ Retry logic
✅ Concurrency control
✅ Monitoring
✅ Persistence
```

---

## 3️⃣ Parser Mimarisi (Dayanıklı)

### Versiyonlu Parser Katmanı
```typescript
// services/parser/
├── html-v1.ts          // Güncel DOM şeması
├── html-v2.ts          // (Ileride eklenecek)
├── html-v3.ts          // (Ileride eklenecek)
├── auto-detect.ts      // HTML snapshot imza → doğru parser'ı seç
└── fallback.ts         // Playwright render (Cheerio başarısızsa)

// Feature flags
PARSER_FORCE=v1         // .env'de elle sabitleme mümkün
```

### Fallback Zinciri
```
1. Cheerio (ham HTML parse; hızlı)
   ↓ başarısızsa
2. Playwright (render edilmiş DOM)
   ↓ başarısızsa
3. Heuristik (tablo başlık metinlerinden sütun indeks eşleme)
```

### Data Extraction (Zod Validated)
```typescript
// ProjectRowSchema (Zod)
{
  tokiId: number,              // URL'den çıkarılır
  cityId: number,              // 1..81
  name: string,                // trim, min 3
  projectType: string,         // normalize + upsert
  status: enum(ProjectStatus), // normalize
  contractor: string | null,
  unitCount: number | null,    // nonnegative
  seviyePct: number | null,    // 0..100 (%, metin, varyantlar)
  detailUrl: url
}

// Seviye Varyantları
"%100" → 100
"100%" → 100
"100,00 %" → 100
"Tamamlandı" → 100
"Tamamlandı %100" → 100
null → null
```

---

## 4️⃣ Güncelleme Karar Kuralları (Seviye-Merkezli)

### Diff Algorithm
```typescript
// Karşılaştırma (Seviye Öncelikli):

1. Seviye ↑ (ör. 78.0 → 82.0)
   → change_type = "updated"
   → +snapshot
   → last_seen_at güncelle

2. Seviye ↓ (ör. 82.0 → 81.0)
   → change_type = "regressed"
   → +snapshot
   → (olası veri düzeltmesi; ayrı raporlanır)

3. Seviye = ama TRACKED_FIELDS'dan biri değişti
   → change_type = "meta_updated"
   → +snapshot
   → diff'e metinsel farklar yazılır

4. Yeni kayıt (DB'de yok)
   → change_type = "created"
   → first_seen_at = now()

5. Kayıt kaybolmuş (DB'de var, yeni dump'ta yok)
   → change_type = "deleted"
   → is_active = false (soft delete)

6. Hiçbir değişiklik yok
   → SKIP
```

### Change Tracking (Granülarite)
```typescript
// TRACKED_FIELDS
["seviye_pct", "status", "contractor", "unit_count", "name", "project_type_id", "detail_url"]

// changes.fields = { field: {old, new} }
{
  toki_id: 123,
  change_type: "updated",
  fields: {
    seviye_pct: { old: 78.0, new: 82.0 },
    status: { old: "İnşaat", new: "Satış" }
  },
  at: "2025-10-24T10:30:00Z"
}
```

### Snapshot Stratejisi (Seçici)
```typescript
// Snapshot SADECE change olduğunda
if (change_type === 'created' ||
    change_type === 'updated' ||
    change_type === 'regressed' ||
    change_type === 'meta_updated') {
  await createSnapshot(project);
}

// Retention Policy
- 0–180 gün: Sıcak saklama (PostgreSQL)
- >180 gün: zstd sıkıştırılmış arşiv (S3 veya disk)
- "High-churn" projelerde: 1 günde 1 snapshot sınırı
```

### Duplicate Detection (Levenshtein)
```typescript
// Aynı şehir + benzer ad + aynı yüklenici + ±5 unit_count
const duplicates = await db.projects.findMany({
  where: {
    city_id: newProject.city_id,
    contractor: newProject.contractor,
    unit_count: { gte: newProject.unit_count - 5, lte: newProject.unit_count + 5 }
  }
});

duplicates.forEach(dup => {
  const distance = levenshtein(dup.name, newProject.name);
  if (distance < 3) {
    // Merge advisory log
    logger.warn(`Possible duplicate: ${dup.toki_id} vs ${newProject.toki_id}`);
  }
});
```

---

## 5️⃣ API Tasarımı

### RESTful Endpoints
```
GET    /api/projects              # Paginated list
GET    /api/projects/:id          # Detail
GET    /api/projects/search       # Search
GET    /api/cities                # All cities
GET    /api/project-types         # All types
GET    /api/sync/status           # Sync status
POST   /api/sync/trigger          # Manual sync
GET    /api/analytics/summary     # Stats
GET    /api/analytics/changes     # Change history
```

### Response Format
```typescript
// Success
{
  success: true,
  data: { ... },
  meta: { page: 1, total: 100 }
}

// Error
{
  success: false,
  error: "Invalid input",
  code: "VALIDATION_ERROR"
}
```

---

## 6️⃣ Database Indexing

```sql
-- Performance optimization
CREATE INDEX idx_projects_city_id ON projects(city_id);
CREATE INDEX idx_projects_type_id ON projects(project_type_id);
CREATE INDEX idx_projects_toki_id ON projects(toki_id);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_changes_project_id ON project_changes(project_id);
CREATE INDEX idx_sync_date ON sync_history(sync_date DESC);
```

---

## 7️⃣ Job Scheduling & Monitoring (BullMQ)

### Repeatable Job
```typescript
// Periyodik Sync
const job = await syncQueue.add(
  { type: 'full_sync' },
  {
    repeat: {
      pattern: '0 2 * * *',  // Her gün 02:00 UTC
      tz: 'UTC',
      startDate: new Date(),
      endDate: null
    },
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: true,
    removeOnFail: false
  }
);

// Jitter (±20 dk)
const jitter = Math.random() * 1200000; // 0–20 dk
setTimeout(() => startSync(), jitter);
```

### Event Listeners
```typescript
syncQueue.on('completed', (job) => {
  logger.info(`Sync completed: ${job.data.stats}`);
  // Sentry event
  Sentry.captureMessage('Sync completed', 'info');
  // WebSocket event
  io.emit('sync:completed', job.data.stats);
});

syncQueue.on('failed', (job, err) => {
  logger.error(`Sync failed: ${err.message}`);
  // Sentry alert
  Sentry.captureException(err);
  // Slack webhook
  notifySlack(`❌ Sync failed: ${err.message}`);
  // Email
  notifyEmail('admin@example.com', `Sync failed: ${err.message}`);
});
```

### SLO'lar
```
- Başarı oranı ≥ 99%/ay
- Ortalama ingest süresi < 3 dk
- HTML boyut anomalisi (±50%) → alarm
- Job timeout: 5 dakika
```

---

## 8️⃣ Error Handling & Logging

### Winston Logger Setup
```typescript
// config/logger.ts
import winston from 'winston';

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({
      filename: 'logs/error.log',
      level: 'error',
      maxsize: 10485760,  // 10MB
      maxFiles: 10
    }),
    new winston.transports.File({
      filename: 'logs/combined.log',
      maxsize: 10485760,
      maxFiles: 30
    }),
    ...(process.env.NODE_ENV !== 'production'
      ? [new winston.transports.Console({ format: winston.format.simple() })]
      : [])
  ]
});
```

### Alert Mekanizması
```typescript
// services/alerts/types.ts
export enum AlertType {
  SYNC_FAILED = 'sync_failed',
  HTML_ANOMALY = 'html_anomaly',
  PARSE_ERROR = 'parse_error',
  DUPLICATE_DETECTED = 'duplicate_detected',
  PARSER_VERSION_CHANGED = 'parser_version_changed'
}

// services/alerts/config.ts
export const ALERT_CONFIG = {
  [AlertType.SYNC_FAILED]: {
    channels: ['slack', 'sentry', 'email'],
    severity: 'critical'
  },
  [AlertType.HTML_ANOMALY]: {
    channels: ['slack', 'sentry'],
    severity: 'warning'
  }
};
```

### Hata Türleri & Handling
```
1. Network errors (TOKİ ulaşılamıyor)
   → Retry 3 kez, exponential backoff
   → Alert: SYNC_FAILED

2. Parse errors (HTML değişti)
   → Log error, parser version değiştir
   → Alert: PARSE_ERROR

3. HTML anomali (boyut ±50%)
   → Log warning, snapshot karşılaştır
   → Alert: HTML_ANOMALY

4. Validation errors
   → Log line index, field, reason
   → sync_history.errors++

5. Database errors
   → Rollback transaction, retry
   → Alert: SYNC_FAILED

6. Duplicate detected
   → Log advisory, UI rozeti
   → Alert: DUPLICATE_DETECTED
```

---

## 9️⃣ Security Measures

```typescript
// Güvenlik:
✅ Environment variables (.env)
✅ Input validation (Zod)
✅ SQL injection prevention (Prisma)
✅ CORS configuration
✅ Rate limiting (express-rate-limit)
✅ Helmet.js (security headers)
✅ HTTPS only
✅ No sensitive data in logs
```

---

## 🔟 Admin Auth & Security

### JWT Setup
```typescript
// config/auth.ts
import jwt from 'jsonwebtoken';

export function generateAdminToken(username: string): string {
  return jwt.sign(
    { role: 'admin', username },
    process.env.JWT_SECRET!,
    { expiresIn: '24h' }
  );
}

export function verifyAdminToken(token: string) {
  try {
    return jwt.verify(token, process.env.JWT_SECRET!);
  } catch (err) {
    throw new Error('Invalid token');
  }
}

// Middleware
export function adminAuthMiddleware(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Unauthorized' });

  try {
    const decoded = verifyAdminToken(token);
    if (decoded.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    req.admin = decoded;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
}
```

### Audit Log
```typescript
// Log her admin action
logger.info(`Admin action: ${req.admin.username} triggered sync at ${new Date()}`);
```

---

## 📦 Dependencies Summary (Prod-Ready)

### Frontend
```json
{
  "next": "^14.0.0",
  "react": "^18.2.0",
  "tailwindcss": "^3.3.0",
  "shadcn-ui": "latest",
  "@tanstack/react-query": "^5.0.0",
  "react-hook-form": "^7.48.0",
  "zod": "^3.22.0",
  "recharts": "^2.10.0",
  "lucide-react": "^0.292.0",
  "@sentry/nextjs": "^7.0.0"
}
```

### Backend
```json
{
  "express": "^4.18.0",
  "prisma": "^5.0.0",
  "@prisma/client": "^5.0.0",
  "axios": "^1.6.0",
  "cheerio": "^1.0.0",
  "playwright": "^1.40.0",
  "bullmq": "^5.0.0",
  "redis": "^4.6.0",
  "zod": "^3.22.0",
  "winston": "^3.11.0",
  "helmet": "^7.1.0",
  "express-rate-limit": "^7.1.0",
  "jsonwebtoken": "^9.1.0",
  "levenshtein-edit-distance": "^2.0.5",
  "@sentry/node": "^7.0.0"
}
```

---

## 🚀 Deployment & Environment

### Docker Compose Services
```yaml
services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: tokidb
      POSTGRES_USER: tokiuser
      POSTGRES_PASSWORD: tokipass
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U tokiuser"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  api:
    build: ./backend
    environment:
      DATABASE_URL: postgresql://tokiuser:tokipass@postgres:5432/tokidb
      REDIS_URL: redis://redis:6379
      NODE_ENV: development
      PORT: 3000
    ports:
      - "3000:3000"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy

  web:
    build: ./frontend
    environment:
      NEXT_PUBLIC_API_URL: http://localhost:3000
    ports:
      - "3001:3000"
    depends_on:
      - api
```

### Environment Variables (.env.example)
```
# Database
DATABASE_URL=postgresql://tokiuser:tokipass@postgres:5432/tokidb
REDIS_URL=redis://redis:6379

# Server
NODE_ENV=development
PORT=3000

# TOKİ
TOKI_URL=https://www.toki.gov.tr/illere-gore-projeler
PARSER_FORCE=v1

# Auth
JWT_SECRET=your-secret-key-here-min-32-chars

# Alerts
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/...
ALERT_EMAIL=admin@example.com
SENTRY_DSN=https://...

# Logging
LOG_LEVEL=info

# Rate Limit
RATE_LIMIT_WINDOW_MS=300000
RATE_LIMIT_MAX_REQUESTS=30
```

---

**Hazırlayan:** Augment Agent (Revize)
**Tarih:** 2025-10-24
**Durum:** Prod-Ready Plan ✅ → F1 Başlangıç 🚀

