# 🚀 TOKİDB Projesini Başlat

**Adım adım talimatlar**

---

## 📋 Ön Koşullar

Aşağıdakilerden birini seçin:

### Option 1: Docker ile (Önerilen - En Kolay)
- Docker Desktop kurulu olmalı
- ~5 dakika

### Option 2: Lokal Development
- Node.js 20+ kurulu olmalı
- PostgreSQL 15 kurulu olmalı
- Redis 7 kurulu olmalı
- ~15 dakika

---

## 🐳 Option 1: Docker ile Başlat (Önerilen)

### Adım 1: Docker Desktop Kur

**Windows:**
1. https://www.docker.com/products/docker-desktop adresine git
2. "Docker Desktop for Windows" indir
3. Installer'ı çalıştır
4. WSL 2 backend'i seç
5. Kurulumu tamamla
6. Bilgisayarı yeniden başlat

**Mac:**
1. https://www.docker.com/products/docker-desktop adresine git
2. "Docker Desktop for Mac" indir
3. DMG dosyasını aç
4. Docker.app'ı Applications klasörüne sürükle
5. Applications'dan Docker'ı başlat

**Linux:**
```bash
sudo apt-get update
sudo apt-get install -y docker.io docker-compose
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -aG docker $USER
```

### Adım 2: Docker'ın Çalıştığını Kontrol Et

```bash
docker --version
docker-compose --version
```

### Adım 3: Projeyi Başlat

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

# Tüm services'i başlat
docker-compose up -d

# Logs'u izle (Ctrl+C ile çık)
docker-compose logs -f
```

### Adım 4: Database Setup

```bash
docker-compose exec backend pnpm run db:setup
```

### Adım 5: Tarayıcıda Aç

```
http://localhost:3000
```

### Adım 6: Giriş Yap

- **Email:** admin@tokidb.local
- **Şifre:** admin123

---

## 💻 Option 2: Lokal Development

### Adım 1: Node.js Kur

**Windows:**
```powershell
# Option A: Chocolatey ile
choco install nodejs

# Option B: https://nodejs.org/ adresinden indir ve kur
```

**Mac:**
```bash
brew install node
```

**Linux:**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### Adım 2: pnpm Kur

```bash
npm install -g pnpm
```

### Adım 3: Versiyonları Kontrol Et

```bash
node --version      # v20+
npm --version       # 10+
pnpm --version      # 8+
```

### Adım 4: PostgreSQL & Redis Başlat

**Option A: Docker ile (Kolay)**
```bash
docker-compose up -d postgres redis
```

**Option B: Lokal kurulum**
- PostgreSQL 15 kur ve başlat
- Redis 7 kur ve başlat

### Adım 5: Dependencies Kur

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app
pnpm install
```

### Adım 6: Environment Setup

```bash
cp .env.example .env

# .env dosyasını düzenle (opsiyonel)
# DATABASE_URL ve REDIS_URL kontrol et
```

### Adım 7: Database Migration

```bash
pnpm run db:setup
```

### Adım 8: Development Servers Başlat

**Terminal 1: Backend**
```bash
cd backend
pnpm run dev
```

**Terminal 2: Frontend**
```bash
cd frontend
pnpm run dev
```

### Adım 9: Tarayıcıda Aç

```
http://localhost:3000
```

### Adım 10: Giriş Yap

- **Email:** admin@tokidb.local
- **Şifre:** admin123

---

## ✅ Başarılı Kurulum Kontrol Listesi

- [ ] Services çalışıyor (`docker-compose ps` veya dev servers)
- [ ] http://localhost:3000 açılıyor
- [ ] Login sayfası görünüyor
- [ ] Demo kimlik bilgileri ile giriş yapılıyor
- [ ] Projects sayfası yükleniyor
- [ ] Admin panel erişilebiliyor

---

## 🧪 Tests Çalıştır

```bash
# Tüm tests
pnpm run test

# Integration tests
pnpm run test:integration

# E2E tests
pnpm run test:e2e
```

---

## 📊 Monitoring

### Services Status

```bash
docker-compose ps
```

### Logs

```bash
# Tüm logs
docker-compose logs -f

# Sadece backend
docker-compose logs -f backend

# Sadece frontend
docker-compose logs -f frontend
```

### Health Check

```bash
# Backend health
curl http://localhost:3001/health

# Frontend
curl http://localhost:3000
```

---

## 🛑 Durdur

```bash
# Tüm services'i durdur
docker-compose down

# Volumes'ü sil (database reset)
docker-compose down -v
```

---

## 🆘 Sorun Giderme

### Docker başlamıyor

```bash
# Docker Desktop'ı yeniden başlat
# Veya:
docker-compose restart
```

### Port zaten kullanımda

```bash
# Port kullanan process'i bul
# Windows
netstat -ano | findstr :3000

# Mac/Linux
lsof -i :3000

# Process'i kapat
taskkill /PID <PID> /F  # Windows
kill -9 <PID>           # Mac/Linux
```

### Database bağlantı hatası

```bash
# PostgreSQL çalışıyor mu kontrol et
docker-compose ps postgres

# Logs kontrol et
docker-compose logs postgres

# Yeniden başlat
docker-compose restart postgres
```

### Dependencies hatası

```bash
# Cache temizle
pnpm store prune

# Yeniden kur
pnpm install --force
```

---

## 📚 Daha Fazla Bilgi

- **Kurulum Rehberi:** SETUP_INSTRUCTIONS.md
- **Quick Start:** QUICK_START.md
- **Sorun Giderme:** TROUBLESHOOTING.md
- **API Referansı:** API_DOCS.md
- **Deployment:** DEPLOYMENT_GUIDE.md

---

## 🎯 Sonraki Adımlar

1. ✅ Projeyi başlat
2. ✅ Frontend'i test et
3. ✅ Admin panel'i test et
4. ✅ API endpoints'i test et
5. ✅ Tests çalıştır
6. ✅ Production deployment'ı yap

---

**Kurulum Süresi:** 
- Docker ile: ~5 dakika ⚡
- Lokal ile: ~15 dakika

**Sorun mu var?** Bkz. TROUBLESHOOTING.md

