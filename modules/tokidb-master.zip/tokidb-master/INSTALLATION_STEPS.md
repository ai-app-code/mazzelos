# 📥 Adım Adım Kurulum Rehberi

**TOKİDB Projesini Ayağa Kaldırmak İçin Tüm Adımlar**

---

## 🔴 KRITIK: Hemen Kurulması Gereken

### ADIM 1: Node.js 20+ Kur (5 dakika)

**Windows:**

**Option A: Chocolatey ile (Kolay)**
```powershell
# Chocolatey yüklü mü kontrol et
choco --version

# Yüklü değilse: https://chocolatey.org/install adresinden kur

# Node.js kur
choco install nodejs

# Kontrol et
node --version      # v20+
npm --version       # 10+
```

**Option B: Direct Download**
1. https://nodejs.org/ adresine git
2. LTS versiyonunu (20+) indir
3. Installer'ı çalıştır
4. "Add to PATH" seçeneğini işaretle
5. Kurulumu tamamla
6. PowerShell'i yeniden aç

**Option C: Windows Package Manager**
```powershell
winget install OpenJS.NodeJS
```

**Kurulum Kontrol:**
```powershell
node --version      # v20.x.x
npm --version       # 10.x.x
```

---

### ADIM 2: Docker Desktop Kur (10 dakika)

**Windows:**

1. https://www.docker.com/products/docker-desktop adresine git
2. "Docker Desktop for Windows" indir
3. Installer'ı çalıştır
4. Kurulum sırasında:
   - ✅ "Install required Windows components for WSL 2" seç
   - ✅ "Use WSL 2 instead of Hyper-V" seç
5. Kurulumu tamamla
6. **Bilgisayarı yeniden başlat** (ÖNEMLI!)
7. Docker Desktop'ı başlat

**Kurulum Kontrol:**
```powershell
docker --version
docker-compose --version
```

**Sorun: WSL 2 yüklü değil**
```powershell
# WSL 2 kur
wsl --install

# Bilgisayarı yeniden başlat
```

---

### ADIM 3: pnpm Kur (1 dakika)

```powershell
npm install -g pnpm

# Kontrol et
pnpm --version      # 8+
```

---

### ADIM 4: PostgreSQL & Redis Başlat (2 dakika)

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

# Docker ile başlat
docker-compose up -d postgres redis

# Kontrol et
docker-compose ps

# Logs kontrol et
docker-compose logs postgres
docker-compose logs redis
```

**Bekleme:** ~30 saniye (services başlaması için)

---

### ADIM 5: Dependencies Kur (5 dakika)

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

pnpm install

# Kontrol et
pnpm list
```

---

### ADIM 6: Environment Setup (1 dakika)

```bash
# .env dosyası oluştur
cp .env.example .env

# .env dosyasını düzenle (opsiyonel)
# Varsayılan değerler zaten ayarlanmış
```

---

### ADIM 7: Database Migration (2 dakika)

```bash
pnpm run db:setup

# Kontrol et
docker-compose exec postgres psql -U tokidb -d tokidb -c "\dt"
```

---

### ADIM 8: Backend Dev Server Başlat (Terminal 1)

```bash
cd backend
pnpm run dev

# Bekleme: ~10 saniye
# Çıktı: "Server running on http://localhost:3001"
```

---

### ADIM 9: Frontend Dev Server Başlat (Terminal 2)

```bash
cd frontend
pnpm run dev

# Bekleme: ~15 saniye
# Çıktı: "ready - started server on 0.0.0.0:3000"
```

---

### ADIM 10: Tarayıcıda Aç

```
http://localhost:3000
```

**Bekleme:** ~5 saniye (sayfa yüklenmesi için)

---

### ADIM 11: Giriş Yap

- **Email:** admin@tokidb.local
- **Şifre:** admin123

---

## ✅ Başarılı Kurulum Kontrol Listesi

- [ ] Node.js 20+ kurulu (`node --version`)
- [ ] npm 10+ kurulu (`npm --version`)
- [ ] pnpm 8+ kurulu (`pnpm --version`)
- [ ] Docker Desktop kurulu (`docker --version`)
- [ ] Docker Compose kurulu (`docker-compose --version`)
- [ ] PostgreSQL çalışıyor (`docker-compose ps`)
- [ ] Redis çalışıyor (`docker-compose ps`)
- [ ] Dependencies kuruldu (`pnpm install`)
- [ ] Database migration tamamlandı (`pnpm run db:setup`)
- [ ] Backend dev server çalışıyor (Terminal 1)
- [ ] Frontend dev server çalışıyor (Terminal 2)
- [ ] http://localhost:3000 açılıyor
- [ ] Login sayfası görünüyor
- [ ] Demo kimlik bilgileri ile giriş yapılıyor
- [ ] Projects sayfası yükleniyor

---

## 🆘 Sorun Giderme

### Node.js kurulumu başarısız

```powershell
# Chocolatey yüklü mü kontrol et
choco --version

# Yüklü değilse: https://chocolatey.org/install
```

### Docker kurulumu başarısız

```powershell
# WSL 2 kurulu mu kontrol et
wsl --list --verbose

# Yüklü değilse:
wsl --install
# Bilgisayarı yeniden başlat
```

### Port zaten kullanımda

```powershell
# Port kullanan process'i bul
netstat -ano | findstr :3000

# Process'i kapat
taskkill /PID <PID> /F
```

### PostgreSQL bağlantı hatası

```bash
# PostgreSQL çalışıyor mu kontrol et
docker-compose ps postgres

# Logs kontrol et
docker-compose logs postgres

# Yeniden başlat
docker-compose restart postgres
```

### Dependencies kurulumu başarısız

```bash
# Cache temizle
pnpm store prune

# Yeniden kur
pnpm install --force
```

---

## 📊 Kurulum Süresi

| Adım | Süre |
|------|------|
| Node.js | 5 min |
| Docker | 10 min |
| pnpm | 1 min |
| PostgreSQL & Redis | 2 min |
| Dependencies | 5 min |
| Database Setup | 2 min |
| Backend Server | 1 min |
| Frontend Server | 1 min |
| **TOPLAM** | **~27 dakika** |

---

## 🎯 Sonraki Adımlar

1. ✅ Tüm adımları tamamla
2. ✅ Frontend'i test et
3. ✅ Admin panel'i test et
4. ✅ API endpoints'i test et
5. ✅ Tests çalıştır
6. ✅ Production deployment'ı yap

---

**Başlamaya hazır mısınız?** 🚀

