# 🔒 Security Audit Checklist

**Tarih:** 25 Ekim 2025  
**Hedef:** Tüm security kontrolleri yapıp vulnerabilities'i fix etmek

---

## 🔐 Authentication & Authorization

### JWT Security
- [ ] Token expiry: 24 hours ✅
- [ ] Token refresh mechanism
- [ ] Token revocation on logout
- [ ] Secure token storage (httpOnly cookies)
- [ ] Token validation on every request ✅

### Password Security
- [ ] Password hashing (bcrypt) - TODO
- [ ] Password strength validation
- [ ] Password reset mechanism
- [ ] Rate limiting on login attempts

### Admin Access
- [ ] Admin middleware verification ✅
- [ ] Role-based access control (RBAC)
- [ ] Audit logging for admin actions
- [ ] IP whitelisting (optional)

---

## 🛡️ API Security

### CORS Configuration
```typescript
// Whitelist production domains
const corsOptions = {
  origin: [
    'https://tokidb.com',
    'https://www.tokidb.com',
    'http://localhost:3000' // dev only
  ],
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
};

app.use(cors(corsOptions));
```

**Checklist:**
- [ ] CORS whitelist configured
- [ ] Credentials allowed only for trusted domains
- [ ] Preflight requests handled

### Rate Limiting
```typescript
// Different limits for different endpoints
const adminLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 1 // 1 request per 5 minutes
});

const publicLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 30 // 30 requests per 5 minutes
});

app.post('/api/admin/sync/trigger', adminLimiter, ...);
app.get('/api/projects', publicLimiter, ...);
```

**Checklist:**
- [ ] Admin endpoints: 1 req/5min
- [ ] Public endpoints: 30 req/5min
- [ ] API endpoints: 100 req/5min
- [ ] Rate limit headers sent

### Security Headers
```typescript
// Helmet.js configuration
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'", 'https://api.sentry.io']
    }
  },
  hsts: {
    maxAge: 31536000, // 1 year
    includeSubDomains: true,
    preload: true
  },
  frameguard: { action: 'deny' },
  noSniff: true,
  xssFilter: true
}));
```

**Checklist:**
- [ ] Content-Security-Policy set
- [ ] X-Frame-Options: DENY
- [ ] X-Content-Type-Options: nosniff
- [ ] X-XSS-Protection: 1; mode=block
- [ ] Strict-Transport-Security set

---

## 💾 Data Security

### SQL Injection Prevention
- [x] Prisma ORM (parameterized queries) ✅
- [ ] Input validation (Zod) ✅
- [ ] No raw SQL queries
- [ ] Prepared statements

### XSS Prevention
- [x] React auto-escaping ✅
- [ ] Content-Security-Policy header
- [ ] Input sanitization
- [ ] Output encoding

### CSRF Protection
- [ ] CSRF token generation
- [ ] CSRF token validation
- [ ] SameSite cookie attribute
- [ ] Double-submit cookie pattern

**Implementation:**
```typescript
// SameSite cookie
res.cookie('authToken', token, {
  httpOnly: true,
  secure: true, // HTTPS only
  sameSite: 'strict',
  maxAge: 24 * 60 * 60 * 1000 // 24 hours
});
```

---

## 🔑 Secrets Management

### Environment Variables
- [ ] .env.example created ✅
- [ ] .env in .gitignore ✅
- [ ] No secrets in code
- [ ] Secrets in CI/CD (GitHub Actions)

**Sensitive Variables:**
- [ ] DATABASE_URL
- [ ] REDIS_URL
- [ ] JWT_SECRET
- [ ] ADMIN_EMAIL
- [ ] ADMIN_PASSWORD
- [ ] SENTRY_DSN
- [ ] SLACK_WEBHOOK_URL

### Secrets Rotation
- [ ] JWT_SECRET rotation policy
- [ ] Database password rotation
- [ ] API key rotation

---

## 📝 Logging & Monitoring

### Audit Logging
- [ ] Login attempts logged
- [ ] Admin actions logged
- [ ] API errors logged
- [ ] Sensitive data not logged

### Error Handling
- [ ] Generic error messages to users
- [ ] Detailed errors in logs only
- [ ] Stack traces not exposed
- [ ] Error tracking (Sentry) ✅

---

## 🧪 Security Testing

### Dependency Scanning
```bash
# Check for vulnerabilities
npm audit
npm audit fix

# Snyk scanning
snyk test
```

**Checklist:**
- [ ] npm audit passed
- [ ] No high/critical vulnerabilities
- [ ] Dependencies updated

### OWASP Top 10
- [ ] A01: Broken Access Control
- [ ] A02: Cryptographic Failures
- [ ] A03: Injection
- [ ] A04: Insecure Design
- [ ] A05: Security Misconfiguration
- [ ] A06: Vulnerable Components
- [ ] A07: Authentication Failures
- [ ] A08: Data Integrity Failures
- [ ] A09: Logging & Monitoring
- [ ] A10: SSRF

---

## ✅ Security Checklist

### Critical
- [ ] CORS configured
- [ ] Rate limiting enabled
- [ ] JWT validation
- [ ] SQL injection prevention
- [ ] XSS prevention
- [ ] CSRF protection

### High
- [ ] Security headers set
- [ ] Secrets management
- [ ] Audit logging
- [ ] Error handling
- [ ] Dependency scanning

### Medium
- [ ] Password hashing
- [ ] Token refresh
- [ ] IP whitelisting
- [ ] API versioning
- [ ] Documentation

---

## 🎯 Success Criteria

- ✅ 0 critical vulnerabilities
- ✅ 0 high vulnerabilities
- ✅ All security headers set
- ✅ Rate limiting working
- ✅ Audit logging enabled
- ✅ npm audit passed

---

**Tahmini Süre:** 1 gün

