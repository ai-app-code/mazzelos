'use client';

import { useState } from 'react';
import { useProjects } from '@/hooks/useProjects';
import { ProjectFilter, ProjectStatus } from '@tokidb/shared';
import { ProjectCard } from './ProjectCard';

interface ProjectListProps {
  filters: ProjectFilter;
}

export function ProjectList({ filters }: ProjectListProps) {
  const [page, setPage] = useState(1);
  const limit = 20;

  const { data, isLoading, error } = useProjects({
    ...filters,
    page,
    limit,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
        <p className="text-red-800">Hata: {(error as Error).message}</p>
      </div>
    );
  }

  const projects: any[] = (data?.data as any[]) || [];
  const meta = data?.meta;

  if (projects.length === 0) {
    return (
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-12 text-center">
        <div className="max-w-md mx-auto">
          <svg className="mx-auto h-16 w-16 text-blue-400 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
          </svg>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Henüz Proje Verisi Yok</h3>
          <p className="text-gray-600 mb-4">
            TOKİ web sitesinden proje verilerini çekmek için senkronizasyon başlatmanız gerekiyor.
          </p>
          <div className="space-y-2 text-sm text-gray-700">
            <p>📍 <strong>Adım 1:</strong> Admin paneline giriş yapın</p>
            <p>🔄 <strong>Adım 2:</strong> "Senkronizasyonu Başlat" butonuna tıklayın</p>
            <p>⏱️ <strong>Adım 3:</strong> İşlem tamamlanana kadar bekleyin (2-3 dakika)</p>
          </div>
          <div className="mt-6">
            <a
              href="/admin"
              className="inline-block bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
            >
              Admin Paneline Git
            </a>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Project Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {projects.map((project: any) => (
          <ProjectCard key={project.id} project={project} />
        ))}
      </div>

      {/* Pagination */}
      {meta && meta.total_pages && meta.total_pages > 1 && (
        <div className="flex justify-center items-center space-x-4">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Önceki
          </button>

          <span className="text-gray-700">
            Sayfa {page} / {meta.total_pages}
          </span>

          <button
            onClick={() => setPage((p) => Math.min(meta.total_pages || 1, p + 1))}
            disabled={page === meta.total_pages}
            className="px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Sonraki
          </button>
        </div>
      )}
    </div>
  );
}

