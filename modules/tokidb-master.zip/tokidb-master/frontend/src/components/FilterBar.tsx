'use client';

import { ProjectFilter, ProjectStatus } from '@tokidb/shared';
import { useCities } from '@/hooks/useCities';

interface FilterBarProps {
  filters: ProjectFilter;
  onFiltersChange: (filters: ProjectFilter) => void;
}

export function FilterBar({ filters, onFiltersChange }: FilterBarProps) {
  const { data: citiesResponse } = useCities();
  const cities: any[] = (citiesResponse?.data as any[]) || [];

  const handleChange = (key: keyof ProjectFilter, value: any) => {
    onFiltersChange({
      ...filters,
      [key]: value || undefined,
    });
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Search */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ara
          </label>
          <input
            type="text"
            placeholder="Proje adı..."
            value={filters.search || ''}
            onChange={(e) => handleChange('search', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        {/* City Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            İl
          </label>
          <select
            value={filters.city_id || ''}
            onChange={(e) => handleChange('city_id', e.target.value ? parseInt(e.target.value) : undefined)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Tümü</option>
            {cities.map((city: any) => (
              <option key={city.id} value={city.id}>
                {city.name}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Durum
          </label>
          <select
            value={filters.status || ''}
            onChange={(e) => handleChange('status', e.target.value || undefined)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Tümü</option>
            <option value={ProjectStatus.ACTIVE}>Devam Ediyor</option>
            <option value={ProjectStatus.COMPLETED}>Tamamlandı</option>
            <option value={ProjectStatus.PLANNED}>Planlandı</option>
            <option value={ProjectStatus.CANCELLED}>İptal</option>
          </select>
        </div>

        {/* Seviye Range */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Seviye (%)
          </label>
          <div className="flex space-x-2">
            <input
              type="number"
              placeholder="Min"
              min="0"
              max="100"
              value={filters.min_seviye || ''}
              onChange={(e) => handleChange('min_seviye', e.target.value ? parseFloat(e.target.value) : undefined)}
              className="w-1/2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <input
              type="number"
              placeholder="Max"
              min="0"
              max="100"
              value={filters.max_seviye || ''}
              onChange={(e) => handleChange('max_seviye', e.target.value ? parseFloat(e.target.value) : undefined)}
              className="w-1/2 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>

      {/* Clear Filters */}
      {Object.keys(filters).length > 0 && (
        <div className="mt-4">
          <button
            onClick={() => onFiltersChange({})}
            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            Filtreleri Temizle
          </button>
        </div>
      )}
    </div>
  );
}

