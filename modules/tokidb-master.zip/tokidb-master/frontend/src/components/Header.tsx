'use client';

import Link from 'next/link';

export function Header() {
  return (
    <header className="bg-white shadow-sm border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">T</span>
            </div>
            <span className="text-xl font-bold text-gray-900">TOKİDB</span>
          </Link>

          <nav className="flex items-center space-x-6 overflow-x-auto">
            <Link
              href="/dashboard"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              Dashboard
            </Link>
            <Link
              href="/"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              Projeler
            </Link>
            <Link
              href="/cities"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              🏙️ Şehirler
            </Link>
            <Link
              href="/companies"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              🏢 Firmalar
            </Link>
            <Link
              href="/partnerships"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              🤝 Ortaklıklar
            </Link>
            <Link
              href="/mosques"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              🕌 Camiler
            </Link>
            <Link
              href="/parsing"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              🤖 Şehirler
            </Link>
            <Link
              href="/logs"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              Loglar
            </Link>
            <Link
              href="/admin"
              className="text-gray-600 hover:text-gray-900 transition-colors whitespace-nowrap"
            >
              Admin
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}

