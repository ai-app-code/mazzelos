'use client';

import { useEffect, useState } from 'react';

interface ParsingProgress {
  total: number;
  completed: number;
  pending_llm: number;
  rate_limited: number;
  failed: number;
  progress_pct: number;
  last_processed_id: number | null;
  is_rate_limited: boolean;
  retry_after_seconds?: number;
  current_batch_job_id?: string;
  current_batch_status?: string;
}

export default function ParsingCard() {
  const [progress, setProgress] = useState<ParsingProgress | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [loading, setLoading] = useState(true);

  // Fetch progress
  const fetchProgress = async () => {
    try {
      const res = await fetch('/api/parsing/progress');
      const data = await res.json();
      setProgress(data);
    } catch (error) {
      console.error('Error fetching parsing progress:', error);
    }
  };

  useEffect(() => {
    fetchProgress();
    const interval = setInterval(fetchProgress, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleFirstRun = async () => {
    setIsRunning(true);
    try {
      await fetch('/api/parsing/first-run', { method: 'POST' });
      await fetchProgress();
    } catch (error) {
      console.error('Error starting FirstRun:', error);
    } finally {
      setIsRunning(false);
    }
  };

  const handleResume = async () => {
    setIsRunning(true);
    try {
      await fetch('/api/parsing/resume', { method: 'POST' });
      await fetchProgress();
    } catch (error) {
      console.error('Error resuming parsing:', error);
    } finally {
      setIsRunning(false);
    }
  };

  const handleFullRun = async () => {
    if (!confirm('⚠️ Bu işlem TÜM yüklenicileri yeniden parse edecek ve eski verileri override edecektir. Devam etmek istiyor musunuz?')) {
      return;
    }
    setIsRunning(true);
    try {
      await fetch('/api/parsing/full-run', { method: 'POST' });
      await fetchProgress();
    } catch (error) {
      console.error('Error starting full parsing:', error);
    } finally {
      setIsRunning(false);
    }
  };

  if (!progress) {
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-bold mb-4">🔄 Contractor Parsing</h3>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <span className="text-sm font-medium">Progress</span>
          <span className="text-sm font-medium">{progress.progress_pct.toFixed(1)}%</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div
            className="bg-blue-600 h-3 rounded-full transition-all duration-300"
            style={{ width: `${progress.progress_pct}%` }}
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 p-3 rounded">
          <p className="text-xs text-gray-600">Total</p>
          <p className="text-2xl font-bold">{progress.total}</p>
        </div>
        <div className="bg-green-50 p-3 rounded">
          <p className="text-xs text-gray-600">✅ Completed</p>
          <p className="text-2xl font-bold text-green-600">{progress.completed}</p>
        </div>
        <div className="bg-yellow-50 p-3 rounded">
          <p className="text-xs text-gray-600">⏳ Pending LLM</p>
          <p className="text-2xl font-bold text-yellow-600">{progress.pending_llm}</p>
        </div>
        <div className="bg-red-50 p-3 rounded">
          <p className="text-xs text-gray-600">⏸️ Rate Limited</p>
          <p className="text-2xl font-bold text-red-600">{progress.rate_limited}</p>
        </div>
      </div>

      {/* Rate Limit Status */}
      {progress.is_rate_limited && (
        <div className="bg-red-50 border border-red-200 rounded p-3 mb-4">
          <p className="text-sm text-red-800">
            ⏸️ Rate limited. Resuming in {progress.retry_after_seconds}s...
          </p>
        </div>
      )}

      {/* Gemini LLM Status */}
      <div className="bg-purple-50 border border-purple-200 rounded p-3 mb-4">
        <div className="flex items-center justify-between">
          <p className="text-sm text-purple-800">
            🤖 Gemini LLM Status
          </p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-xs text-purple-600">Connected</span>
          </div>
        </div>
        <p className="text-xs text-purple-600 mt-1">
          Pending LLM: {progress.pending_llm} | Batch Job: {progress.current_batch_status || 'None'}
        </p>
      </div>

      {/* Batch Job Status */}
      {progress.current_batch_job_id && (
        <div className="bg-blue-50 border border-blue-200 rounded p-3 mb-4">
          <p className="text-sm text-blue-800">
            📦 Batch Job: {progress.current_batch_status}
          </p>
          <p className="text-xs text-blue-600 mt-1">{progress.current_batch_job_id}</p>
        </div>
      )}

      {/* Buttons */}
      <div className="flex gap-2 flex-col">
        <div className="flex gap-2">
          <button
            onClick={handleFirstRun}
            disabled={isRunning}
            className="flex-1 bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
          >
            {isRunning ? '⏳ Running...' : '🔄 First Run'}
          </button>
          <button
            onClick={handleResume}
            disabled={isRunning || !progress.is_rate_limited}
            className="flex-1 bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
          >
            {isRunning ? '⏳ Running...' : '▶️ Resume'}
          </button>
        </div>
        <button
          onClick={handleFullRun}
          disabled={isRunning}
          className="w-full bg-orange-600 text-white px-4 py-2 rounded hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
        >
          {isRunning ? '⏳ Running...' : '🔄 Full Re-Parse (All Contractors)'}
        </button>
      </div>
    </div>
  );
}

