'use client';

import Link from 'next/link';
import { ProjectStatus } from '@tokidb/shared';

interface ProjectCardProps {
  project: any;
}

export function ProjectCard({ project }: ProjectCardProps) {
  const statusColors = {
    [ProjectStatus.ACTIVE]: 'bg-green-100 text-green-800',
    [ProjectStatus.COMPLETED]: 'bg-blue-100 text-blue-800',
    [ProjectStatus.PLANNED]: 'bg-yellow-100 text-yellow-800',
    [ProjectStatus.CANCELLED]: 'bg-red-100 text-red-800',
    [ProjectStatus.UNKNOWN]: 'bg-gray-100 text-gray-800',
  };

  const statusLabels = {
    [ProjectStatus.ACTIVE]: 'Devam Ediyor',
    [ProjectStatus.COMPLETED]: 'Tamamlandı',
    [ProjectStatus.PLANNED]: 'Planlandı',
    [ProjectStatus.CANCELLED]: 'İptal',
    [ProjectStatus.UNKNOWN]: 'Bilinmiyor',
  };

  return (
    <Link href={`/projects/${project.toki_id}`}>
      <div className="bg-white rounded-lg shadow-sm border hover:shadow-md transition-shadow p-6 cursor-pointer">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <h3 className="font-semibold text-gray-900 mb-1 line-clamp-2">
              {project.name}
            </h3>
            <p className="text-sm text-gray-600">
              {project.city.name} • {project.project_type.name}
            </p>
          </div>
          <span
            className={`px-2 py-1 rounded-full text-xs font-medium ${
              statusColors[project.status as ProjectStatus]
            }`}
          >
            {statusLabels[project.status as ProjectStatus]}
          </span>
        </div>

        {/* Progress */}
        {project.seviye_pct !== null && (
          <div className="mb-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-gray-600">Seviye</span>
              <span className="text-sm font-semibold text-gray-900">
                %{project.seviye_pct.toFixed(1)}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all"
                style={{ width: `${project.seviye_pct}%` }}
              />
            </div>
          </div>
        )}

        {/* Details */}
        <div className="space-y-2 text-sm">
          {project.contractor && (
            <div className="flex items-center text-gray-600">
              <span className="font-medium mr-2">Yüklenici:</span>
              <span className="truncate">{project.contractor}</span>
            </div>
          )}
          {project.unit_count && (
            <div className="flex items-center text-gray-600">
              <span className="font-medium mr-2">Konut:</span>
              <span>{project.unit_count} adet</span>
            </div>
          )}
        </div>
      </div>
    </Link>
  );
}

