/**
 * API Client for TOKİDB Backend
 */

import { ApiResponse, ProjectListQuery, ProjectFilter, ExportFormat } from '@tokidb/shared';

const API_BASE_URL = '/api';

class ApiClient {
  private baseUrl: string;
  private token: string | null = null;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
    
    // Load token from localStorage
    if (typeof window !== 'undefined') {
      this.token = localStorage.getItem('auth_token');
    }
  }

  setToken(token: string | null) {
    this.token = token;
    if (typeof window !== 'undefined') {
      if (token) {
        localStorage.setItem('auth_token', token);
      } else {
        localStorage.removeItem('auth_token');
      }
    }
  }

  async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    // ALWAYS check localStorage for the latest token (not just this.token)
    let currentToken = typeof window !== 'undefined' ? localStorage.getItem('auth_token') : null;
    if (!currentToken) {
      currentToken = this.token;
    }

    if (currentToken) {
      headers['Authorization'] = `Bearer ${currentToken}`;
    }

    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Request failed' }));
      throw new Error(error.error || `HTTP ${response.status}`);
    }

    return response.json();
  }

  // Cities
  async getCities() {
    return this.request('/cities');
  }

  async getCityById(id: number) {
    return this.request(`/cities/${id}`);
  }

  // Companies
  async getCompanies() {
    return this.request('/companies');
  }

  // Partnerships
  async getPartnerships() {
    return this.request('/partnerships');
  }

  // Projects
  async getProjects(query: ProjectListQuery) {
    const params = new URLSearchParams();
    Object.entries(query).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        params.append(key, String(value));
      }
    });
    return this.request(`/projects?${params.toString()}`);
  }

  async getProjectByTokiId(tokiId: string) {
    return this.request(`/projects/${tokiId}`);
  }

  // Export
  async exportProjects(format: ExportFormat, filters?: ProjectFilter) {
    const response = await fetch(`${this.baseUrl}/export`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(this.token && { Authorization: `Bearer ${this.token}` }),
      },
      body: JSON.stringify({ format, filters }),
    });

    if (!response.ok) {
      throw new Error('Export failed');
    }

    return response.blob();
  }

  // Sync
  async triggerSync() {
    return this.request('/sync', { method: 'POST' });
  }

  async getSyncHistory() {
    return this.request('/sync/history');
  }

  async getSyncStatus(id: number) {
    return this.request(`/sync/status/${id}`);
  }

  async cleanupStuckSyncs() {
    return this.request('/sync/cleanup-stuck', { method: 'POST' });
  }

  async deleteFailedSyncs() {
    return this.request('/sync/delete-failed', { method: 'POST' });
  }

  async cancelSync() {
    return this.request('/sync/cancel', { method: 'POST' });
  }

  // Auth
  async login(email: string, password: string) {
    const response = await this.request<{ token: string; user: { email: string } }>(
      '/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      }
    );

    if (response.success && response.data) {
      this.setToken(response.data.token);
    }

    return response;
  }

  // Dashboard
  async getDashboardStats() {
    return this.request('/dashboard/stats');
  }

  async getMosques(minSeviye: number, maxSeviye: number) {
    return this.request(`/dashboard/mosques?minSeviye=${minSeviye}&maxSeviye=${maxSeviye}`);
  }

  // Parsing
  async getParsingHealth() {
    return this.request('/parsing/health');
  }

  async getParsingProgress() {
    return this.request('/parsing/progress');
  }

  async firstRunParsing() {
    return this.request('/parsing/first-run', { method: 'POST' });
  }

  async fullParsing() {
    return this.request('/parsing/full-run', { method: 'POST' });
  }

  async resumeParsing() {
    return this.request('/parsing/resume', { method: 'POST' });
  }

  logout() {
    this.setToken(null);
  }
}

export const apiClient = new ApiClient(API_BASE_URL);

