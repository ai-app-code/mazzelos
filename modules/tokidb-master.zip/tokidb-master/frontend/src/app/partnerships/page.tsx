'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api';
import Link from 'next/link';
import { Header } from '@/components/Header';

interface Partnership {
  partners: string[];
  totalProjects: number;
  completedProjects: number;
  ongoingProjects: number;
  avgSeviye: number;
}

export default function PartnershipsPage() {
  const [partnerships, setPartnerships] = useState<Partnership[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPartnerships = async () => {
      try {
        setLoading(true);
        const response = await apiClient.getPartnerships();
        setPartnerships((response.data as any).partnerships || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch partnerships');
      } finally {
        setLoading(false);
      }
    };

    fetchPartnerships();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-gray-600">Ortaklıklar yükleniyor...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-red-600">Hata: {error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">🤝 Ortaklıklar</h1>
            <p className="text-gray-600">Toplam: <span className="font-bold text-blue-600">{partnerships.length}</span> ortaklık</p>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Ortaklar</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Toplam Proje</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Tamamlanan</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Devam Eden</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Ort. Seviye</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {partnerships.map((partnership, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">
                      <Link 
                        href={`/partnerships/${encodeURIComponent(partnership.partners.join(' | '))}`} 
                        className="text-blue-600 hover:underline"
                      >
                        {partnership.partners.join(' + ')}
                      </Link>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full font-semibold">
                        {partnership.totalProjects}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full">
                        {partnership.completedProjects}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full">
                        {partnership.ongoingProjects}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                      {partnership.avgSeviye.toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

