'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/Header';

export default function SyncPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSync = async () => {
    setIsLoading(true);
    setMessage('');
    setError('');

    try {
      const token = localStorage.getItem('token');
      if (!token) {
        router.push('/admin');
        return;
      }

      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();

      if (response.ok) {
        setMessage(`Sync başarılı! ${data.data?.stats?.total || 0} proje işlendi.`);
      } else {
        setError(data.error || 'Sync başarısız oldu.');
      }
    } catch (err) {
      setError('Bağlantı hatası. Lütfen tekrar deneyin.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            Manuel Senkronizasyon
          </h1>
          
          <div className="mb-6">
            <p className="text-gray-600 mb-4">
              TOKİ web sitesinden güncel proje verilerini çekmek için manuel senkronizasyon başlatabilirsiniz.
            </p>
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-4">
              <p className="text-sm text-yellow-800">
                ⚠️ <strong>Dikkat:</strong> Manuel sync işlemi birkaç dakika sürebilir. 
                Rate limiting nedeniyle 5 dakikada bir sync yapabilirsiniz.
              </p>
            </div>
          </div>

          {message && (
            <div className="bg-green-50 border border-green-200 rounded-md p-4 mb-4">
              <p className="text-green-800">{message}</p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-md p-4 mb-4">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          <div className="flex gap-4">
            <button
              onClick={handleSync}
              disabled={isLoading}
              className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
            >
              {isLoading ? 'Sync Yapılıyor...' : 'Sync Başlat'}
            </button>
            <button
              onClick={() => router.push('/admin')}
              className="bg-gray-200 text-gray-700 px-6 py-3 rounded-md hover:bg-gray-300 transition-colors"
            >
              Admin Paneline Dön
            </button>
          </div>

          <div className="mt-8 border-t pt-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-3">
              Otomatik Senkronizasyon
            </h2>
            <p className="text-gray-600">
              Sistem her gün saat 02:00 UTC'de otomatik olarak senkronizasyon yapar.
              Manuel sync sadece acil güncellemeler için kullanılmalıdır.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

