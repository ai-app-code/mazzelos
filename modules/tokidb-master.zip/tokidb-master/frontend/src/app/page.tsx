'use client';

import { ProjectList } from '@/components/ProjectList';
import { FilterBar } from '@/components/FilterBar';
import { Header } from '@/components/Header';
import { useState } from 'react';
import { ProjectFilter } from '@tokidb/shared';

export default function HomePage() {
  const [filters, setFilters] = useState<ProjectFilter>({});

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            TOKİ Proje Takip Sistemi
          </h1>
          <p className="text-gray-600">
            TOKİ projelerini takip edin, seviye değişikliklerini izleyin
          </p>
        </div>

        <FilterBar filters={filters} onFiltersChange={setFilters} />
        <ProjectList filters={filters} />
      </main>
    </div>
  );
}

