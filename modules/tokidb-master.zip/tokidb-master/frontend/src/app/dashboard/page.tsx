'use client';

import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api';
import Link from 'next/link';
import { Header } from '@/components/Header';

export default function DashboardPage() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['dashboard-stats'],
    queryFn: () => apiClient.getDashboardStats(),
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const stats = data?.data as any;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center text-red-600">
          <p className="text-lg font-semibold">Hata oluştu</p>
          <p className="text-sm">{error instanceof Error ? error.message : 'Bilinmeyen hata'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">TOKİ Proje Yönetim Sistemi - Genel İstatistikler</p>
          </div>

        {/* Main Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {/* Total Projects */}
          <Link href="/projeler">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Toplam Proje</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats?.totalProjects?.toLocaleString('tr-TR')}</p>
                </div>
                <div className="bg-blue-100 rounded-full p-3">
                  <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="mt-4 text-blue-600 hover:text-blue-800 text-sm font-medium">Detayları Gör →</p>
            </div>
          </Link>

          {/* Total Cities */}
          <Link href="/cities">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Şehir Sayısı</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats?.totalCities}</p>
                </div>
                <div className="bg-green-100 rounded-full p-3">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                </div>
              </div>
              <p className="mt-4 text-green-600 hover:text-green-800 text-sm font-medium">Detayları Gör →</p>
            </div>
          </Link>

          {/* Total Contractors */}
          <Link href="/companies">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Firma Sayısı</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats?.totalContractors}</p>
                </div>
                <div className="bg-purple-100 rounded-full p-3">
                  <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 12H9m6 0a6 6 0 11-12 0 6 6 0 0112 0z" />
                  </svg>
                </div>
              </div>
              <p className="mt-4 text-purple-600 hover:text-purple-800 text-sm font-medium">Detayları Gör →</p>
            </div>
          </Link>

          {/* Partnerships */}
          <Link href="/partnerships">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Ortaklık Sayısı</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats?.partnershipCount}</p>
                </div>
                <div className="bg-orange-100 rounded-full p-3">
                  <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.856-1.487M15 10a3 3 0 11-6 0 3 3 0 016 0zM6 20h12a6 6 0 00-6-6 6 6 0 00-6 6z" />
                  </svg>
                </div>
              </div>
              <p className="mt-4 text-orange-600 hover:text-orange-800 text-sm font-medium">Detayları Gör →</p>
            </div>
          </Link>

          {/* Mosque Projects */}
          <Link href="/mosques">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow cursor-pointer">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Cami Projeleri</p>
                  <p className="text-3xl font-bold text-gray-900 mt-2">{stats?.mosqueCount}</p>
                </div>
                <div className="bg-red-100 rounded-full p-3">
                  <span className="text-2xl">🕌</span>
                </div>
              </div>
              <p className="mt-4 text-red-600 hover:text-red-800 text-sm font-medium">Detayları Gör →</p>
            </div>
          </Link>
        </div>

        {/* Secondary Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Projects by Status */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Proje Durumu</h2>
            <div className="space-y-3">
              {stats?.projectsByStatus?.map((status: any) => (
                <div key={status.status} className="flex items-center justify-between">
                  <span className="text-gray-600">{status.status}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{
                          width: `${(status.count / (stats?.totalProjects || 1)) * 100}%`,
                        }}
                      ></div>
                    </div>
                    <span className="text-gray-900 font-semibold min-w-12 text-right">{status.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Projects by Type */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Proje Tipi</h2>
            <div className="space-y-3">
              {stats?.projectsByType?.map((type: any) => (
                <div key={type.type} className="flex items-center justify-between">
                  <span className="text-gray-600 truncate">{type.type}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-32 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-green-600 h-2 rounded-full"
                        style={{
                          width: `${(type.count / (stats?.totalProjects || 1)) * 100}%`,
                        }}
                      ></div>
                    </div>
                    <span className="text-gray-900 font-semibold min-w-12 text-right">{type.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Last Sync Info */}
        {stats?.lastSync && (
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Son Senkronizasyon</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <p className="text-gray-600 text-sm">Tarih</p>
                <p className="text-gray-900 font-semibold">
                  {new Date(stats.lastSync.date).toLocaleString('tr-TR')}
                </p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">Çekilen</p>
                <p className="text-gray-900 font-semibold">{stats.lastSync.projectsFetched}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">Oluşturulan</p>
                <p className="text-gray-900 font-semibold">{stats.lastSync.projectsCreated}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">Güncellenen</p>
                <p className="text-gray-900 font-semibold">{stats.lastSync.projectsUpdated}</p>
              </div>
            </div>
          </div>
        )}

        {/* Average Seviye */}
        <div className="mt-8 bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Ortalama İlerleme</h2>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <div className="w-full bg-gray-200 rounded-full h-4">
                <div
                  className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-4 rounded-full"
                  style={{ width: `${stats?.averageSeviye || 0}%` }}
                ></div>
              </div>
            </div>
            <span className="text-2xl font-bold text-gray-900 min-w-16 text-right">
              %{(stats?.averageSeviye || 0).toFixed(1)}
            </span>
          </div>
        </div>

        </div>
      </div>
    </div>
  );
}

