'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api';
import Link from 'next/link';
import { Header } from '@/components/Header';

interface Company {
  name: string;
  totalProjects: number;
  completedProjects: number;
  ongoingProjects: number;
  avgSeviye: number;
}

export default function CompaniesPage() {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCompanies = async () => {
      try {
        setLoading(true);
        const response = await apiClient.getCompanies();
        setCompanies((response.data as any).companies || []);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch companies');
      } finally {
        setLoading(false);
      }
    };

    fetchCompanies();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-gray-600">Firmalar yükleniyor...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-red-600">Hata: {error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">🏢 Firmalar</h1>
            <p className="text-gray-600">Toplam: <span className="font-bold text-blue-600">{companies.length}</span> firma</p>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Firma Adı</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Toplam Proje</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Tamamlanan</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Devam Eden</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Ort. Seviye</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {companies.map((company, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">
                      <Link href={`/companies/${encodeURIComponent(company.name)}`} className="text-blue-600 hover:underline">
                        {company.name}
                      </Link>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full font-semibold">
                        {company.totalProjects}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full">
                        {company.completedProjects}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full">
                        {company.ongoingProjects}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900">
                      {company.avgSeviye.toFixed(1)}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

