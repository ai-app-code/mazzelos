'use client';

import { useState, useEffect, useRef } from 'react';
import { Header } from '@/components/Header';
import { apiClient } from '@/lib/api';
import { useQuery, useMutation } from '@tanstack/react-query';

export default function AdminPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isClient, setIsClient] = useState(false);

  // Check if user is already logged in (has token in localStorage)
  const { data: syncHistory, refetch } = useQuery({
    queryKey: ['syncHistory'],
    queryFn: () => apiClient.getSyncHistory(),
    enabled: isLoggedIn,
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    setIsClient(true);
    const token = localStorage.getItem('auth_token');
    if (token) {
      setIsLoggedIn(true);
      // Token varsa hemen refetch yap
      refetch();
    }
  }, [refetch]);

  const loginMutation = useMutation({
    mutationFn: () => apiClient.login(email, password),
    onSuccess: () => {
      setIsLoggedIn(true);
      refetch();
    },
  });

  const [syncStatus, setSyncStatus] = useState<{
    isRunning: boolean;
    message: string;
    progress?: { current: number; total: number };
    stats?: { total: number; created: number; updated: number; unchanged: number };
  }>({ isRunning: false, message: '' });

  const [logs, setLogs] = useState<Array<{ timestamp: string; level: string; message: string }>>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);
  const [runningSyncId, setRunningSyncId] = useState<string | null>(null);

  // Cancel running sync mutation
  const cancelMutation = useMutation({
    mutationFn: () => apiClient.cancelSync(),
    onSuccess: (data: any) => {
      alert(`✅ Sync iptal edildi`);
      setRunningSyncId(null);
      setSyncStatus({ isRunning: false, message: '' });
      setLogs([]);
      refetch();
    },
    onError: (error: any) => {
      alert(`❌ Cancel failed: ${error.message}`);
    },
  });

  // Cleanup stuck syncs mutation
  const cleanupMutation = useMutation({
    mutationFn: () => apiClient.cleanupStuckSyncs(),
    onSuccess: (data: any) => {
      alert(`✅ ${data.data.message}`);
      refetch();
    },
    onError: (error: any) => {
      alert(`❌ Cleanup failed: ${error.message}`);
    },
  });

  // Delete failed syncs mutation
  const deleteFailedMutation = useMutation({
    mutationFn: () => apiClient.deleteFailedSyncs(),
    onSuccess: (data: any) => {
      alert(`✅ ${data.data.message}`);
      refetch();
    },
    onError: (error: any) => {
      alert(`❌ Delete failed: ${error.message}`);
    },
  });

  const syncMutation = useMutation({
    mutationFn: () => {
      // Check if sync is already running
      if (runningSyncId) {
        throw new Error('Senkronizasyon zaten çalışıyor! Lütfen tamamlanmasını bekleyin veya iptal edin.');
      }
      return apiClient.triggerSync();
    },
    onMutate: () => {
      console.log('🚀 [SYNC] Starting sync...');
      setSyncStatus({
        isRunning: true,
        message: 'Senkronizasyon başlatılıyor...',
        progress: { current: 0, total: 81 },
      });
    },
    onSuccess: (data: any) => {
      console.log('✅ [SYNC] Success response:', data);
      const syncId = data?.data?.sync_id;
      if (!syncId) {
        console.error('❌ [SYNC] No sync_id in response:', data);
        setSyncStatus({
          isRunning: false,
          message: 'Senkronizasyon başlatılamadı.',
        });
        return;
      }
      console.log('🔄 [SYNC] Sync started with ID:', syncId);
      setRunningSyncId(syncId);

      // Start polling for sync status
      setSyncStatus({
        isRunning: true,
        message: 'Senkronizasyon devam ediyor... (Arka planda çalışıyor)',
      });

      // Fetch logs immediately and then every 2 seconds
      const fetchLogs = async () => {
        try {
          const response = await fetch('/api/logs/stream?lines=100');
          if (!response.ok) {
            console.error('Log fetch failed:', response.status);
            return;
          }
          const logsData = await response.json();
          if (logsData.success && logsData.data) {
            setLogs(logsData.data);
            // Auto-scroll to bottom
            setTimeout(() => {
              logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
            }, 0);
          }
        } catch (error) {
          console.error('Log fetch error:', error);
        }
      };

      // Fetch logs immediately
      fetchLogs();

      const logInterval = setInterval(fetchLogs, 2000);

      const pollInterval = setInterval(async () => {
        try {
          const history = await apiClient.getSyncHistory();
          const currentSync = (history.data as any[]).find((s: any) => s.id === syncId);

          if (currentSync && currentSync.status !== 'RUNNING') {
            clearInterval(pollInterval);
            clearInterval(logInterval);
            setRunningSyncId(null);

            if (currentSync.status === 'SUCCESS') {
              setSyncStatus({
                isRunning: false,
                message: `✅ Senkronizasyon tamamlandı! ${currentSync.projects_created} proje oluşturuldu, ${currentSync.projects_updated} güncellendi.`,
              });
            } else {
              setSyncStatus({
                isRunning: false,
                message: `❌ Senkronizasyon başarısız: ${currentSync.error_message || 'Bilinmeyen hata'}`,
              });
            }

            setTimeout(() => {
              refetch();
              setSyncStatus({ isRunning: false, message: '' });
              setLogs([]);
            }, 5000);
          }
        } catch (error) {
          console.error('Polling error:', error);
        }
      }, 5000); // Poll every 5 seconds

      // Stop polling after 10 minutes (safety)
      setTimeout(() => {
        clearInterval(pollInterval);
        clearInterval(logInterval);
        setRunningSyncId(null);
        if (syncStatus.isRunning) {
          setSyncStatus({
            isRunning: false,
            message: 'Senkronizasyon zaman aşımına uğradı. Geçmişi kontrol edin.',
          });
          // Auto-trigger cleanup to mark stuck sync as FAILED
          console.log('🧹 Auto-triggering cleanup for stuck sync...');
          cleanupMutation.mutate();
          refetch();
        }
      }, 600000); // 10 minutes
    },
    onError: (error: any) => {
      console.error('❌ [SYNC] Error:', error);
      console.error('❌ [SYNC] Error response:', error?.response);
      console.error('❌ [SYNC] Error data:', error?.response?.data);
      setSyncStatus({
        isRunning: false,
        message: `Senkronizasyon başlatılamadı: ${error?.response?.data?.error || error?.message || 'Bilinmeyen hata'}`,
      });
    },
  });

  // Show loading state during hydration
  if (!isClient) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto bg-white rounded-lg shadow-sm border p-8">
            <p className="text-center text-gray-600">Yükleniyor...</p>
          </div>
        </main>
      </div>
    );
  }

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto bg-white rounded-lg shadow-sm border p-8">
            <h1 className="text-2xl font-bold text-gray-900 mb-6">Admin Girişi</h1>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                loginMutation.mutate();
              }}
            >
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Şifre
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <button
                type="submit"
                disabled={loginMutation.isPending}
                className="w-full bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                {loginMutation.isPending ? 'Giriş yapılıyor...' : 'Giriş Yap'}
              </button>
              {loginMutation.isError && (
                <p className="text-red-600 text-sm mt-2">
                  Giriş başarısız. Lütfen bilgilerinizi kontrol edin.
                </p>
              )}
            </form>
          </div>
        </main>
      </div>
    );
  }

  const history = (syncHistory?.data as any[]) || [];

  const handleLogout = () => {
    apiClient.logout();
    setIsLoggedIn(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Panel</h1>
            <p className="text-gray-600">Senkronizasyon yönetimi ve geçmişi</p>
          </div>
          <button
            onClick={handleLogout}
            className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-all"
          >
            Çıkış Yap
          </button>
        </div>

        {/* Sync Button */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Manuel Senkronizasyon</h2>

          <div className="flex gap-2">
            <button
              onClick={() => syncMutation.mutate()}
              disabled={syncStatus.isRunning || !!runningSyncId}
              className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {syncStatus.isRunning ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Veriler Çekiliyor...
                </span>
              ) : runningSyncId ? (
                <span className="flex items-center gap-2">
                  <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Çalışıyor...
                </span>
              ) : (
                '▶️ Senkronizasyonu Başlat'
              )}
            </button>
            {runningSyncId && (
              <button
                onClick={() => {
                  if (confirm('⚠️ Sync\'i iptal etmek istediğinize emin misiniz?')) {
                    cancelMutation.mutate();
                  }
                }}
                disabled={cancelMutation.isPending}
                className="bg-red-600 text-white px-6 py-3 rounded-md hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                {cancelMutation.isPending ? '⏳ İptal ediliyor...' : '⏹️ İptal Et'}
              </button>
            )}
            <button
              onClick={() => {
                if (confirm('⚠️ Stuck RUNNING syncs\'i FAILED olarak işaretle?')) {
                  cleanupMutation.mutate();
                }
              }}
              disabled={cleanupMutation.isPending}
              className="bg-orange-600 text-white px-6 py-3 rounded-md hover:bg-orange-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {cleanupMutation.isPending ? '⏳ Temizleniyor...' : '🧹 Stuck Sync\'leri Temizle'}
            </button>
            <button
              onClick={() => {
                if (confirm('⚠️ Tüm FAILED syncs\'leri silmek istediğinize emin misiniz?')) {
                  deleteFailedMutation.mutate();
                }
              }}
              disabled={deleteFailedMutation.isPending}
              className="bg-red-700 text-white px-6 py-3 rounded-md hover:bg-red-800 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {deleteFailedMutation.isPending ? '⏳ Siliniyor...' : '🗑️ FAILED Syncs\'leri Sil'}
            </button>
          </div>

          {/* Status Messages */}
          {syncStatus.message && (
            <div className={`mt-4 p-4 rounded-md ${
              syncStatus.isRunning
                ? 'bg-blue-50 border border-blue-200'
                : syncStatus.stats
                ? 'bg-green-50 border border-green-200'
                : 'bg-red-50 border border-red-200'
            }`}>
              <div className="flex items-start gap-3">
                {syncStatus.isRunning ? (
                  <svg className="animate-spin h-5 w-5 text-blue-600 mt-0.5" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                ) : syncStatus.stats ? (
                  <svg className="h-5 w-5 text-green-600 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                ) : (
                  <svg className="h-5 w-5 text-red-600 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                )}
                <div className="flex-1">
                  <p className={`font-medium ${
                    syncStatus.isRunning ? 'text-blue-900' : syncStatus.stats ? 'text-green-900' : 'text-red-900'
                  }`}>
                    {syncStatus.message}
                  </p>

                  {syncStatus.progress && syncStatus.isRunning && (
                    <div className="mt-2">
                      <div className="flex justify-between text-sm text-blue-700 mb-1">
                        <span>İlerleme</span>
                        <span>{syncStatus.progress.current} / {syncStatus.progress.total}</span>
                      </div>
                      <div className="w-full bg-blue-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${(syncStatus.progress.current / syncStatus.progress.total) * 100}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {syncStatus.stats && (
                    <div className="mt-3 grid grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-700">{syncStatus.stats.total}</div>
                        <div className="text-xs text-green-600">Toplam</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-700">{syncStatus.stats.created}</div>
                        <div className="text-xs text-blue-600">Yeni</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-700">{syncStatus.stats.updated}</div>
                        <div className="text-xs text-yellow-600">Güncellenen</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-gray-700">{syncStatus.stats.unchanged}</div>
                        <div className="text-xs text-gray-600">Değişmeyen</div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="mt-4 text-sm text-gray-600">
            <p>💡 <strong>Not:</strong> Senkronizasyon işlemi 81 il için veri çeker ve birkaç dakika sürebilir.</p>
            <p className="mt-1">⏰ Otomatik senkronizasyon her gün saat 02:00 UTC'de çalışır.</p>
          </div>

          {/* Live Log Viewer */}
          {syncStatus.isRunning && logs.length > 0 && (
            <div className="mt-6">
              <div className="flex justify-between items-center mb-2">
                <div className="text-gray-400">📋 Canlı Log Akışı:</div>
                <button
                  onClick={() => {
                    const logText = logs.map(log => `[${log.timestamp}] ${log.message}`).join('\n');
                    navigator.clipboard.writeText(logText);
                    alert('✅ Loglar kopyalandı!');
                  }}
                  className="text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 px-3 py-1 rounded transition-all"
                >
                  📋 Logları Kopyala
                </button>
              </div>
              <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm text-gray-100 max-h-96 overflow-y-auto border border-gray-700">
                {logs.map((log, idx) => (
                  <div key={idx} className={`py-1 ${
                    log.level === 'error' ? 'text-red-400' :
                    log.level === 'warn' ? 'text-yellow-400' :
                    log.level === 'info' ? 'text-green-400' :
                    'text-gray-300'
                  }`}>
                    <span className="text-gray-500">[{log.timestamp}]</span> {log.message}
                  </div>
                ))}
                <div ref={logsEndRef} />
              </div>
            </div>
          )}
        </div>

        {/* Sync History */}
        <div className="bg-white rounded-lg shadow-sm border p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Senkronizasyon Geçmişi</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Tarih
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Durum
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Parser
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Çekilen
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Oluşturulan
                  </th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                    Güncellenen
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {history.map((sync: any) => (
                  <tr key={sync.id}>
                    <td className="px-4 py-2 text-sm text-gray-900">
                      {new Date(sync.started_at).toLocaleString('tr-TR')}
                    </td>
                    <td className="px-4 py-2 text-sm">
                      <span
                        className={`px-2 py-1 rounded-full text-xs font-medium ${
                          sync.status === 'SUCCESS'
                            ? 'bg-green-100 text-green-800'
                            : sync.status === 'FAILED'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-yellow-100 text-yellow-800'
                        }`}
                      >
                        {sync.status}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-sm text-gray-900">{sync.parser_version}</td>
                    <td className="px-4 py-2 text-sm text-gray-900">{sync.projects_fetched || 0}</td>
                    <td className="px-4 py-2 text-sm text-gray-900">{sync.projects_created || 0}</td>
                    <td className="px-4 py-2 text-sm text-gray-900">{sync.projects_updated || 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}

