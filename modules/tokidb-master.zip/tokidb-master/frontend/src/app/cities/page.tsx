'use client';

import { useEffect, useState } from 'react';
import { apiClient } from '@/lib/api';
import Link from 'next/link';
import { Header } from '@/components/Header';

interface City {
  id: number;
  name: string;
  projects?: number;
  projectCount?: number;
}

interface CityStats {
  name: string;
  projectCount: number;
  percentage: number;
}

export default function CitiesPage() {
  const [cities, setCities] = useState<CityStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [totalProjects, setTotalProjects] = useState(0);

  useEffect(() => {
    const fetchCities = async () => {
      try {
        setLoading(true);
        const response = await apiClient.getCities();

        // Calculate total projects
        const citiesData = response.data as any[];
        const total = citiesData.reduce((sum: number, city: any) => sum + (city.projects?.length || 0), 0);
        setTotalProjects(total);

        // Transform data
        const statsData = citiesData.map((city: any) => ({
          name: city.name,
          projectCount: city.projects?.length || 0,
          percentage: total > 0 ? parseFloat(((city.projects?.length || 0) / total * 100).toFixed(2)) : 0,
        }))
        .sort((a: CityStats, b: CityStats) => b.projectCount - a.projectCount);

        setCities(statsData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to fetch cities');
      } finally {
        setLoading(false);
      }
    };

    fetchCities();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-gray-600">Şehirler yükleniyor...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-lg text-red-600">Hata: {error}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="p-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">🏙️ Şehirler</h1>
            <p className="text-gray-600">Toplam: <span className="font-bold text-blue-600">{cities.length}</span> şehir, <span className="font-bold text-green-600">{totalProjects}</span> proje</p>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Şehir Adı</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Proje Sayısı</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Yüzdelik Dağılım</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-900">Grafik</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {cities.map((city, index) => (
                  <tr key={index} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{city.name}</td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full font-semibold">
                        {city.projectCount}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">{city.percentage}%</td>
                    <td className="px-6 py-4 text-sm">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full"
                          style={{ width: `${city.percentage}%` }}
                        ></div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

