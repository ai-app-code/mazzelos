'use client';

import { useProject } from '@/hooks/useProjects';
import { Header } from '@/components/Header';
import { ProjectStatus, ChangeType } from '@tokidb/shared';
import Link from 'next/link';

export function ProjectDetailContent({ tokiId }: { tokiId: string }) {
  const { data, isLoading, error } = useProject(tokiId);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !data?.data) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <p className="text-red-800">Proje bulunamadı</p>
          </div>
        </div>
      </div>
    );
  }

  const project: any = data.data;

  const statusLabels = {
    [ProjectStatus.ACTIVE]: 'Devam Ediyor',
    [ProjectStatus.COMPLETED]: 'Tamamlandı',
    [ProjectStatus.PLANNED]: 'Planlandı',
    [ProjectStatus.CANCELLED]: 'İptal',
    [ProjectStatus.UNKNOWN]: 'Bilinmiyor',
  };

  const changeTypeLabels = {
    [ChangeType.CREATED]: 'Oluşturuldu',
    [ChangeType.UPDATED]: 'Güncellendi',
    [ChangeType.REGRESSED]: 'Geriledi',
    [ChangeType.META_UPDATED]: 'Metadata Güncellendi',
    [ChangeType.DELETED]: 'Silindi',
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link href="/" className="text-blue-600 hover:text-blue-700">
            ← Projelere Dön
          </Link>
        </div>

        {/* Project Header */}
        <div className="bg-white rounded-lg shadow-sm border p-8 mb-6">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">{project.name}</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <p className="text-sm text-gray-600 mb-1">İl</p>
              <p className="text-lg font-medium">{project.city.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Proje Tipi</p>
              <p className="text-lg font-medium">{project.project_type.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 mb-1">Durum</p>
              <p className="text-lg font-medium">{statusLabels[project.status as ProjectStatus]}</p>
            </div>
            {project.seviye_pct !== null && (
              <div>
                <p className="text-sm text-gray-600 mb-1">Seviye</p>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-blue-600 h-3 rounded-full transition-all"
                      style={{ width: `${project.seviye_pct}%` }}
                    />
                  </div>
                  <span className="text-lg font-medium">%{project.seviye_pct}</span>
                </div>
              </div>
            )}
            {project.yuklenici && (
              <div className="md:col-span-2">
                <p className="text-sm text-gray-600 mb-1">Yüklenici</p>
                <p className="text-lg font-medium">{project.yuklenici}</p>
              </div>
            )}
          </div>
        </div>

        {/* Changes */}
        {project.changes && project.changes.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Değişim Geçmişi</h2>
            <div className="space-y-4">
              {project.changes.map((change: any) => (
                <div key={change.id} className="border-l-4 border-blue-500 pl-4 py-2">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-900">
                      {changeTypeLabels[change.change_type as ChangeType]}
                    </span>
                    <span className="text-sm text-gray-500">
                      {new Date(change.detected_at).toLocaleDateString('tr-TR')}
                    </span>
                  </div>
                  {change.field_name && (
                    <p className="text-sm text-gray-600">
                      Alan: <span className="font-medium">{change.field_name}</span>
                    </p>
                  )}
                  {change.old_value && (
                    <p className="text-sm text-gray-600">
                      Eski: <span className="line-through">{change.old_value}</span>
                    </p>
                  )}
                  {change.new_value && (
                    <p className="text-sm text-gray-600">
                      Yeni: <span className="font-medium text-green-600">{change.new_value}</span>
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Snapshots */}
        {project.snapshots && project.snapshots.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Anlık Görüntüler</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                      Tarih
                    </th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                      Seviye
                    </th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                      Durum
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {project.snapshots.map((snapshot: any) => (
                    <tr key={snapshot.id}>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {new Date(snapshot.snapshot_at).toLocaleDateString('tr-TR')}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {snapshot.seviye_pct !== null ? `%${snapshot.seviye_pct}` : '-'}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-900">
                        {statusLabels[snapshot.status as ProjectStatus]}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

