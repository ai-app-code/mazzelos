import { ProjectDetailContent } from './ProjectDetailContent';

export default async function ProjectDetailPage({ params }: { params: Promise<{ tokiId: string }> }) {
  const { tokiId } = await params;
  return <ProjectDetailContent tokiId={tokiId} />;
}

