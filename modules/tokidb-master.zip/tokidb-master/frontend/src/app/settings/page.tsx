'use client';

import { useState } from 'react';
import { Header } from '@/components/Header';

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    syncEnabled: true,
    syncCron: '0 2 * * *',
    slackEnabled: false,
    slackWebhook: '',
    snapshotRetentionDays: 180,
    parserVersion: 'auto',
  });

  const handleSave = () => {
    alert('Ayarlar kaydedildi! (Bu özellik henüz backend ile entegre değil)');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">
            Sistem Ayarları
          </h1>

          {/* Sync Settings */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Senkronizasyon Ayarları
            </h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-gray-700">Otomatik Sync</label>
                <input
                  type="checkbox"
                  checked={settings.syncEnabled}
                  onChange={(e) =>
                    setSettings({ ...settings, syncEnabled: e.target.checked })
                  }
                  className="h-5 w-5"
                />
              </div>
              <div>
                <label className="block text-gray-700 mb-2">
                  Sync Zamanlaması (Cron)
                </label>
                <input
                  type="text"
                  value={settings.syncCron}
                  onChange={(e) =>
                    setSettings({ ...settings, syncCron: e.target.value })
                  }
                  className="w-full border border-gray-300 rounded-md px-3 py-2"
                  placeholder="0 2 * * *"
                />
                <p className="text-sm text-gray-500 mt-1">
                  Varsayılan: Her gün saat 02:00 UTC
                </p>
              </div>
            </div>
          </div>

          {/* Parser Settings */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Parser Ayarları
            </h2>
            <div>
              <label className="block text-gray-700 mb-2">Parser Versiyonu</label>
              <select
                value={settings.parserVersion}
                onChange={(e) =>
                  setSettings({ ...settings, parserVersion: e.target.value })
                }
                className="w-full border border-gray-300 rounded-md px-3 py-2"
              >
                <option value="auto">Otomatik (v1 → v2 → v3)</option>
                <option value="v1">V1 (Cheerio)</option>
                <option value="v2">V2 (Playwright)</option>
                <option value="v3">V3 (Heuristic)</option>
              </select>
            </div>
          </div>

          {/* Slack Settings */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Slack Bildirimleri
            </h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-gray-700">Slack Entegrasyonu</label>
                <input
                  type="checkbox"
                  checked={settings.slackEnabled}
                  onChange={(e) =>
                    setSettings({ ...settings, slackEnabled: e.target.checked })
                  }
                  className="h-5 w-5"
                />
              </div>
              {settings.slackEnabled && (
                <div>
                  <label className="block text-gray-700 mb-2">
                    Slack Webhook URL
                  </label>
                  <input
                    type="text"
                    value={settings.slackWebhook}
                    onChange={(e) =>
                      setSettings({ ...settings, slackWebhook: e.target.value })
                    }
                    className="w-full border border-gray-300 rounded-md px-3 py-2"
                    placeholder="https://hooks.slack.com/services/..."
                  />
                </div>
              )}
            </div>
          </div>

          {/* Snapshot Settings */}
          <div className="mb-8">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">
              Snapshot Ayarları
            </h2>
            <div>
              <label className="block text-gray-700 mb-2">
                Snapshot Saklama Süresi (Gün)
              </label>
              <input
                type="number"
                value={settings.snapshotRetentionDays}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    snapshotRetentionDays: parseInt(e.target.value),
                  })
                }
                className="w-full border border-gray-300 rounded-md px-3 py-2"
                min="1"
                max="365"
              />
              <p className="text-sm text-gray-500 mt-1">
                Varsayılan: 180 gün (6 ay)
              </p>
            </div>
          </div>

          {/* Save Button */}
          <div className="flex gap-4">
            <button
              onClick={handleSave}
              className="bg-blue-600 text-white px-6 py-3 rounded-md hover:bg-blue-700 transition-colors"
            >
              Ayarları Kaydet
            </button>
            <button
              onClick={() => window.history.back()}
              className="bg-gray-200 text-gray-700 px-6 py-3 rounded-md hover:bg-gray-300 transition-colors"
            >
              İptal
            </button>
          </div>

          <div className="mt-6 bg-yellow-50 border border-yellow-200 rounded-md p-4">
            <p className="text-sm text-yellow-800">
              ℹ️ <strong>Not:</strong> Bu ayarlar şu anda sadece frontend'de saklanmaktadır.
              Backend entegrasyonu için environment variables kullanılmaktadır.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

