'use client';

import { useState, useEffect, useRef } from 'react';
import { Header } from '@/components/Header';
import { apiClient } from '@/lib/api';
import { useMutation, useQuery } from '@tanstack/react-query';

export default function ParsingPage() {
  const [logs, setLogs] = useState<Array<{ timestamp: string; level: string; message: string }>>([]);
  const logsEndRef = useRef<HTMLDivElement>(null);
  const [isRunning, setIsRunning] = useState(false);

  // Fetch LLM health
  const { data: health } = useQuery({
    queryKey: ['parsingHealth'],
    queryFn: () => apiClient.getParsingHealth(),
    refetchInterval: 5000,  // Check every 5 seconds
  });

  // Fetch parsing progress
  const { data: progress, refetch: refetchProgress } = useQuery({
    queryKey: ['parsingProgress'],
    queryFn: () => apiClient.request('/api/parsing/progress'),
    refetchInterval: isRunning ? 2000 : false,
  });

  // Fetch logs
  const fetchLogs = async () => {
    try {
      const response = await fetch('/api/logs/stream?lines=100');
      if (!response.ok) return;
      const logsData = await response.json();
      if (logsData.success && logsData.data) {
        setLogs(logsData.data);
        setTimeout(() => {
          logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 0);
      }
    } catch (error) {
      console.error('Log fetch error:', error);
    }
  };

  useEffect(() => {
    if (isRunning) {
      fetchLogs();
      const interval = setInterval(fetchLogs, 2000);
      return () => clearInterval(interval);
    }
  }, [isRunning]);

  // Full parsing mutation
  const fullParsingMutation = useMutation({
    mutationFn: () => apiClient.fullParsing(),
    onSuccess: () => {
      setIsRunning(true);
      refetchProgress();
    },
    onError: (error: any) => {
      alert(`❌ Error: ${error?.response?.data?.error || error?.message}`);
    },
  });

  // First run mutation
  const firstRunMutation = useMutation({
    mutationFn: () => apiClient.firstRunParsing(),
    onSuccess: () => {
      setIsRunning(true);
      refetchProgress();
    },
    onError: (error: any) => {
      alert(`❌ Error: ${error?.response?.data?.error || error?.message}`);
    },
  });

  const progressData = (progress?.data as any) || {};
  const total = progressData.total_contractors || 0;
  const completed = progressData.completed_count || 0;
  const failed = progressData.failed_count || 0;
  const progress_pct = progressData.progress_pct || 0;

  const healthData = (health?.data as any) || {};
  const llmHealthy = healthData.healthy || false;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Contractor Parsing</h1>
            <p className="text-gray-600">LLM-based contractor parsing with cache optimization</p>
          </div>
          <div className={`px-4 py-2 rounded-lg font-medium ${
            llmHealthy
              ? 'bg-green-100 text-green-800'
              : 'bg-red-100 text-red-800'
          }`}>
            {llmHealthy ? '✅ LLM Connected' : '❌ LLM Disconnected'}
          </div>
        </div>

        {/* Progress Section */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Progress</h2>
          
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-600">Overall Progress</span>
              <span className="font-bold">{progress_pct.toFixed(1)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-blue-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progress_pct}%` }}
              />
            </div>
          </div>

          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{total}</div>
              <div className="text-sm text-blue-600">Total</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{completed}</div>
              <div className="text-sm text-green-600">Completed</div>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-yellow-600">{progressData.pending_llm_count || 0}</div>
              <div className="text-sm text-yellow-600">Pending LLM</div>
            </div>
            <div className="bg-red-50 p-4 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{failed}</div>
              <div className="text-sm text-red-600">Failed</div>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => firstRunMutation.mutate()}
              disabled={isRunning || firstRunMutation.isPending}
              className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {firstRunMutation.isPending ? '⏳ Starting...' : '▶️ First Run'}
            </button>
            <button
              onClick={() => {
                if (confirm('⚠️ Re-parse ALL contractors?')) {
                  fullParsingMutation.mutate();
                }
              }}
              disabled={isRunning || fullParsingMutation.isPending}
              className="bg-orange-600 text-white px-6 py-2 rounded-md hover:bg-orange-700 disabled:opacity-50"
            >
              {fullParsingMutation.isPending ? '⏳ Starting...' : '🔄 Full Re-Parse'}
            </button>
          </div>
        </div>

        {/* Live Terminal */}
        {isRunning && (
          <div className="bg-white rounded-lg shadow-sm border p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-gray-900">📋 Live Terminal</h2>
              <button
                onClick={() => {
                  const logText = logs.map(log => `[${log.timestamp}] ${log.message}`).join('\n');
                  navigator.clipboard.writeText(logText);
                  alert('✅ Logs copied!');
                }}
                className="text-xs bg-gray-700 hover:bg-gray-600 text-gray-200 px-3 py-1 rounded"
              >
                📋 Copy Logs
              </button>
            </div>
            <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm text-gray-100 max-h-96 overflow-y-auto border border-gray-700">
              {logs.length === 0 ? (
                <div className="text-gray-500">Waiting for logs...</div>
              ) : (
                logs.map((log, idx) => (
                  <div key={idx} className={`py-1 ${
                    log.level === 'error' ? 'text-red-400' :
                    log.level === 'warn' ? 'text-yellow-400' :
                    log.level === 'info' ? 'text-green-400' :
                    'text-gray-300'
                  }`}>
                    <span className="text-gray-500">[{log.timestamp}]</span> {log.message}
                  </div>
                ))
              )}
              <div ref={logsEndRef} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

