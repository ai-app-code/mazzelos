import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api';
import { ProjectListQuery } from '@tokidb/shared';

export function useProjects(query: ProjectListQuery) {
  return useQuery({
    queryKey: ['projects', query],
    queryFn: () => apiClient.getProjects(query),
  });
}

export function useProject(tokiId: string) {
  return useQuery({
    queryKey: ['project', tokiId],
    queryFn: () => apiClient.getProjectByTokiId(tokiId),
    enabled: !!tokiId,
  });
}

