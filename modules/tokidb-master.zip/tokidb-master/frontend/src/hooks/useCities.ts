import { useQuery } from '@tanstack/react-query';
import { apiClient } from '@/lib/api';

export function useCities() {
  return useQuery({
    queryKey: ['cities'],
    queryFn: () => apiClient.getCities(),
    staleTime: 5 * 60 * 1000, // 5 minutes (cities rarely change)
  });
}

