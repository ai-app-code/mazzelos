# 🚀 Performance Optimization Plan

**Tarih:** 25 Ekim 2025  
**Hedef:** Frontend & Backend performansını optimize etmek

---

## 📊 Başlangıç Metrikleri

### Frontend
- [ ] First Contentful Paint (FCP): < 2s
- [ ] Largest Contentful Paint (LCP): < 2.5s
- [ ] Cumulative Layout Shift (CLS): < 0.1
- [ ] Bundle Size: < 500KB
- [ ] Time to Interactive (TTI): < 3s

### Backend
- [ ] API Response Time: < 200ms
- [ ] Database Query Time: < 100ms
- [ ] Throughput: > 1000 req/s
- [ ] Memory Usage: < 500MB
- [ ] CPU Usage: < 80%

---

## 🎯 Frontend Optimization

### 1. Bundle Size Optimization
```bash
# Tree-shaking
npm run build -- --analyze

# Code splitting
# - Dynamic imports for admin pages
# - Lazy load components
# - Remove unused dependencies
```

**Hedefler:**
- [ ] Main bundle: < 300KB
- [ ] Admin bundle: < 200KB
- [ ] Shared bundle: < 100KB

### 2. Image Optimization
```tsx
// Use next/image for automatic optimization
import Image from 'next/image';

<Image
  src="/project.jpg"
  alt="Project"
  width={400}
  height={300}
  priority={false}
  loading="lazy"
/>
```

**Hedefler:**
- [ ] WebP format
- [ ] Responsive images
- [ ] Lazy loading

### 3. CSS Optimization
```bash
# Tailwind CSS purge
# - Remove unused styles
# - Minify CSS
# - Critical CSS extraction
```

**Hedefler:**
- [ ] CSS < 50KB
- [ ] Critical CSS inline
- [ ] Unused CSS removed

### 4. API Response Caching
```tsx
// TanStack Query caching
const { data } = useQuery({
  queryKey: ['projects'],
  queryFn: () => api.getProjects(),
  staleTime: 5 * 60 * 1000, // 5 minutes
  cacheTime: 10 * 60 * 1000, // 10 minutes
});
```

**Hedefler:**
- [ ] Cache hit rate > 80%
- [ ] Stale time: 5-10 minutes
- [ ] Background refetch

---

## 🔧 Backend Optimization

### 1. Database Query Optimization
```prisma
// Eager loading
const projects = await prisma.project.findMany({
  include: {
    city: true,
    type: true,
    changes: { take: 10 }
  }
});

// Indexes
CREATE INDEX idx_projects_seviye ON projects(seviye_pct);
CREATE INDEX idx_changes_toki_id_at ON changes(toki_id, at DESC);
```

**Hedefler:**
- [ ] Query time < 100ms
- [ ] N+1 queries eliminated
- [ ] Indexes optimized

### 2. API Response Compression
```typescript
// gzip compression
app.use(compression());

// Response caching
app.use(cacheControl({
  maxAge: 5 * 60 * 1000 // 5 minutes
}));
```

**Hedefler:**
- [ ] Response size < 50KB
- [ ] Compression ratio > 70%

### 3. Connection Pooling
```prisma
// Prisma connection pooling
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
  
  // Connection pool
  // max_pool_size = 10
  // min_pool_size = 2
}
```

**Hedefler:**
- [ ] Pool size: 5-10
- [ ] Connection reuse > 90%

### 4. Rate Limiting Tuning
```typescript
// Optimize rate limits
const limiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 100, // 100 requests per window
  skip: (req) => req.user?.role === 'admin' // Skip for admins
});
```

**Hedefler:**
- [ ] Admin: 1 req/5min (sync)
- [ ] Public: 30 req/5min
- [ ] API: 100 req/5min

---

## 📈 Monitoring & Metrics

### Frontend Monitoring
```typescript
// Web Vitals
import { getCLS, getFID, getFCP, getLCP, getTTFB } from 'web-vitals';

getCLS(console.log);
getFID(console.log);
getFCP(console.log);
getLCP(console.log);
getTTFB(console.log);
```

### Backend Monitoring
```typescript
// Response time tracking
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    logger.info(`${req.method} ${req.path} ${duration}ms`);
  });
  next();
});
```

---

## ✅ Optimization Checklist

### Frontend
- [ ] Bundle size analyzed
- [ ] Code splitting implemented
- [ ] Images optimized
- [ ] CSS purged
- [ ] Caching configured
- [ ] Web Vitals monitored

### Backend
- [ ] Queries optimized
- [ ] Indexes created
- [ ] Compression enabled
- [ ] Connection pooling configured
- [ ] Rate limiting tuned
- [ ] Metrics tracked

---

## 🎯 Success Criteria

- ✅ FCP < 2s
- ✅ API response < 200ms
- ✅ Bundle size < 500KB
- ✅ Cache hit rate > 80%
- ✅ Query time < 100ms
- ✅ Throughput > 1000 req/s

---

**Tahmini Süre:** 1 gün

