# 🏗️ TOKİ Veri Uygulaması — Nihai Mimari Plan v2 (Prod-Ready)

## 📋 Proje Özeti

**Amaç:** TOKİ "İllere Göre Projeler" sayfasından verileri otomatik olarak çekip, doğrulayıp, karşılaştırıp, saklayan ve tarihçesini tutan modern web uygulaması.

**Hedef Kullanıcı:** Veri analisti, araştırmacı, gayrimenkul profesyonelleri, TOKİ izleyicileri

**Temel Özellikler:**
- ✅ TOKİ verilerini otomatik çekme (Cheerio + Playwright fallback)
- ✅ **Seviye-merkezli güncelleme** (↑=updated, ↓=regressed, =&alan_değişti=meta_updated)
- ✅ Verileri PostgreSQL'de saklama + tarihçe (snapshot + change log)
- ✅ Periyodik güncelleme (BullMQ, 02:00 + manuel tetik)
- ✅ Değişiklikleri takip etme (diff, timeline, regressed projeler)
- ✅ Modern UI ile veri görüntüleme (Next.js + Tailwind)
- ✅ Export (CSV + JSON; V2'de Excel)
- ✅ Arama, filtreleme, bulk export
- ✅ Admin panel (sync trigger, logs, alerts)

---

## 🛠️ Teknoloji Stack (Onaylı)

### Frontend
```
Framework:      Next.js 14 (App Router)
Styling:        Tailwind CSS 3.x
UI Components:  shadcn/ui
State:          TanStack Query (React Query)
Forms:          React Hook Form + Zod
Charts:         Recharts
Icons:          Lucide React
```

### Backend & Ingest
```
Runtime:        Node.js 20+
Framework:      Express.js
Database:       PostgreSQL 15+
ORM:            Prisma
Validation:     Zod
Logging:        Winston (rotation, Sentry integration)
HTML Parse:     Cheerio (primary) + Playwright (fallback)
Task Queue:     BullMQ (Redis 7)
Duplicate Det:  Levenshtein distance
```

### DevOps & Monitoring
```
Package Manager: pnpm
Version Control: Git
Container:      Docker + docker-compose
Database:       PostgreSQL 15 + Redis 7
Monitoring:     Sentry (FE/BE), Winston logs
Auth:           JWT (admin)
Alerts:         Slack webhook + Email + Sentry
```

---

## 📁 Klasör Yapısı

```
tokidb/app/
├── frontend/                 # Next.js Frontend
│   ├── app/                  # App Router
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   ├── dashboard/
│   │   ├── projects/
│   │   ├── analytics/
│   │   └── settings/
│   ├── components/           # Reusable components
│   │   ├── ui/               # shadcn/ui components
│   │   ├── layout/
│   │   ├── forms/
│   │   └── charts/
│   ├── lib/                  # Utilities
│   │   ├── api.ts            # API client
│   │   ├── hooks.ts          # Custom hooks
│   │   └── utils.ts
│   ├── styles/               # Global styles
│   ├── public/               # Static files
│   └── package.json
│
├── backend/                  # Express Backend
│   ├── src/
│   │   ├── index.ts          # Entry point
│   │   ├── config/           # Configuration
│   │   ├── routes/           # API routes
│   │   │   ├── projects.ts
│   │   │   ├── cities.ts
│   │   │   ├── sync.ts
│   │   │   └── analytics.ts
│   │   ├── controllers/      # Business logic
│   │   ├── services/         # External services
│   │   │   ├── scraper.ts    # TOKİ scraper
│   │   │   ├── sync.ts       # Sync logic
│   │   │   └── diff.ts       # Diff calculation
│   │   ├── models/           # Database models
│   │   ├── middleware/       # Express middleware
│   │   ├── utils/            # Utilities
│   │   └── jobs/             # Cron jobs
│   │       └── syncJob.ts
│   ├── prisma/
│   │   ├── schema.prisma     # Database schema
│   │   └── migrations/
│   ├── .env.example
│   └── package.json
│
├── shared/                   # Shared code
│   ├── types.ts              # TypeScript types
│   ├── constants.ts
│   └── validators.ts
│
├── docker-compose.yml        # Docker setup
├── .env.example
└── README.md
```

---

## 🗄️ Veritabanı Tasarımı (Revize)

### Tablo Yapısı

```sql
-- Cities (İller)
CREATE TABLE cities (
  id INT PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Project Types (Proje Tipleri)
CREATE TABLE project_types (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Projects (Projeler — en güncel görünüm)
CREATE TABLE projects (
  toki_id INT PRIMARY KEY,
  city_id INT NOT NULL REFERENCES cities(id),
  project_type_id INT REFERENCES project_types(id),
  name VARCHAR(255) NOT NULL,
  status VARCHAR(100),
  contractor VARCHAR(255),
  unit_count INT,
  seviye_pct NUMERIC(5,2),
  detail_url TEXT NOT NULL,
  first_seen_at TIMESTAMPTZ DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ DEFAULT NOW(),
  row_hash CHAR(40),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Project Snapshots (Zaman Serisi)
CREATE TABLE project_snapshots (
  snapshot_id BIGSERIAL PRIMARY KEY,
  toki_id INT NOT NULL REFERENCES projects(toki_id),
  payload JSONB NOT NULL,
  snapshot_hash CHAR(40),
  snapshot_time TIMESTAMPTZ DEFAULT NOW()
);

-- Changes (Fark Günlüğü)
CREATE TABLE changes (
  id BIGSERIAL PRIMARY KEY,
  toki_id INT NOT NULL REFERENCES projects(toki_id),
  change_type VARCHAR(50) NOT NULL,
  fields JSONB,
  at TIMESTAMPTZ DEFAULT NOW()
);

-- Sync History (Senkronizasyon Geçmişi)
CREATE TABLE sync_history (
  id SERIAL PRIMARY KEY,
  started_at TIMESTAMPTZ DEFAULT NOW(),
  finished_at TIMESTAMPTZ,
  total INT,
  created INT,
  updated INT,
  regressed INT,
  meta_updated INT,
  deleted INT,
  errors INT,
  duration_ms INT,
  status VARCHAR(50),
  error_message TEXT
);
```

**İndeksler:**
```sql
CREATE INDEX idx_projects_city_id ON projects(city_id);
CREATE INDEX idx_projects_type_id ON projects(project_type_id);
CREATE INDEX idx_projects_seviye ON projects(seviye_pct);
CREATE INDEX idx_projects_status ON projects(status);
CREATE INDEX idx_changes_toki_id_at ON changes(toki_id, at DESC);
CREATE INDEX idx_snapshots_toki_id_time ON project_snapshots(toki_id, snapshot_time DESC);
CREATE INDEX idx_sync_history_started ON sync_history(started_at DESC);
```

**Tracked Fields (Change Log Granülarite):**
```
["seviye_pct", "status", "contractor", "unit_count", "name", "project_type_id", "detail_url"]
```

---

## 🔄 Veri Senkronizasyon Akışı (Seviye-Öncelikli)

```
1. FETCH (TOKİ'den veri çek)
   ├─ GET /illere-gore-projeler (timeout 60s, retry 3x)
   ├─ HTML snapshot logu (anomali kontrol)
   └─ Cheerio parse (fallback: Playwright)

2. PARSE & VALIDATE (Ayrıştır ve doğrula)
   ├─ Parser auto-detect (versiyonlu: v1, v2, v3)
   ├─ Zod schema validation
   ├─ Seviye ayrıştırması (%, metin, varyantlar)
   ├─ Duplicate detection (Levenshtein)
   └─ Validation error logging

3. COMPARE (Veritabanı ile karşılaştır — Seviye-Merkezli)
   ├─ Seviye ↑ → change_type=updated (+snapshot)
   ├─ Seviye ↓ → change_type=regressed (+snapshot)
   ├─ Seviye = & alan değişti → change_type=meta_updated (+snapshot)
   ├─ Yeni → change_type=created
   └─ Kayboldu → change_type=deleted (soft; is_active=false)

4. STORE (Veritabanına kaydet)
   ├─ BEGIN TRANSACTION
   ├─ UPSERT cities & project_types
   ├─ INSERT/UPDATE projects
   ├─ CREATE snapshots (seçici: 180 gün sıcak, >180 gün zstd arşiv)
   ├─ LOG changes (TRACKED_FIELDS)
   ├─ UPDATE sync_history
   └─ COMMIT

5. ALERT (Uyarı gönder)
   ├─ Job başarısız → Slack + Email + Sentry
   ├─ HTML anomali → Slack + Sentry
   ├─ Parse error → Log + Sentry
   └─ Duplicate detected → Log + UI rozeti
```

---

## 🎨 Frontend Sayfaları (Revize)

1. **Dashboard**
   - Toplam proje, ortalama Seviye, bugün created/updated/regressed/deleted sayıları
   - Şehir/tip dağılım kartları, mini-çizgi grafikleri

2. **Projects (Liste)**
   - Filtre: İl, Tip, Durum, Seviye min/max, **Sadece Regressed**, metin arama
   - Kolonlar: Ad, İl, Tip, Durum, Konut, **Seviye %**, Son Değişim
   - Seviye ↑/↓ ikonlar, "Meta Updated" rozetleri
   - **Bulk export** (aktif filtre ile)

3. **Project Detail**
   - Üstte son değerler (Seviye büyük fontla)
   - **Timeline**: created → updated/meta_updated → regressed → …
   - **Diff viewer**: tracked fields değişimleri (önce/sonra)
   - Snapshot karşılaştırma

4. **Sync / Admin Panel**
   - "Şimdi Tara" butonu (JWT admin token)
   - Son 10 job durumu/puan çizelgesi
   - Ingest logları (errors, warnings)

5. **Settings** (opsiyonel V2)
   - Konfigürasyon, manuel sync trigger

---

## 🔌 API Endpoints (Revize)

```
GET    /api/cities                           # {id, name, project_count, avg_seviye}
GET    /api/project-types

GET    /api/projects?city_id=&type_id=&status=&min_seviye=&q=&page=&size=&regressed_only=
GET    /api/projects/:toki_id                # {project, recent_changes[0..N]}
GET    /api/projects/:toki_id/changes?limit=

GET    /api/export.csv?...                   # CSV export (aktif filtre ile)
GET    /api/export.json?...                  # JSON export

GET    /api/sync/status                      # {last_job, created, updated, regressed, deleted, errors}
POST   /api/admin/sync/trigger               # JWT required, rate-limit 1/5dk

GET    /api/analytics/summary                # {total, avg_seviye, by_city, by_type}
GET    /api/analytics/changes?days=          # Değişiklik geçmişi (son N gün)

POST   /auth/login                           # {username, password} → JWT token
```

**CORS + Rate Limit + Helmet başlıkları aktif**

---

## ⏰ Senkronizasyon Stratejisi (BullMQ)

```
Periyodik Sync:
├─ Her gün 02:00 UTC'de çalış (jitter ±20 dk)
├─ Concurrency: 1 (kibar erişim)
├─ Retry: 3 (exponential backoff 5s, 15s, 45s)
└─ Timeout: 5 dakika

Manual Sync:
├─ Admin panel "Şimdi Tara" butonu (JWT)
├─ Rate limit: 1 istek/5 dakika
└─ Listeners: on('completed'), on('failed')

Monitoring:
├─ SLO: Başarı oranı ≥ 99%/ay
├─ Ortalama ingest süresi < 3 dk
├─ HTML boyut anomalisi (±50%) → alarm
└─ Job başarısız → Slack + Email + Sentry
```

---

## 🔐 Güvenlik & Monitoring

**Güvenlik:**
- ✅ Environment variables (.env.example)
- ✅ Input validation (Zod schema)
- ✅ SQL injection prevention (Prisma ORM)
- ✅ CORS whitelist
- ✅ Rate limiting (express-rate-limit)
- ✅ Helmet.js (security headers)
- ✅ JWT admin auth + audit log
- ✅ No sensitive data in logs

**Monitoring & Logging:**
- ✅ Winston logger (rotation, levels: INFO/WARN/ERROR/DEBUG)
- ✅ Sentry integration (FE/BE error tracking)
- ✅ Alert mekanizması (Slack webhook, Email, Sentry)
- ✅ Sync history tracking (created/updated/regressed/deleted/errors)
- ✅ HTML snapshot logu (anomali kontrol)

---

## 📊 Performans Hedefleri

| Metrik | Hedef |
|--------|-------|
| İlk yükleme | < 2 saniye |
| Proje listesi | < 500ms |
| Senkronizasyon | < 5 dakika |
| Database query | < 100ms |
| API response | < 200ms |

---

## 📅 Geliştirme Takvimi (Revize)

| Faza | Görev | Süre | Detay |
|------|-------|------|-------|
| **F1** | İskelet & Şema | 2–3 gün | Monorepo, Docker, Prisma, JWT, Zod, enum'lar, parser v1, fixtures |
| **F2** | Ingest & Diff | 3–4 gün | Parser auto-detect + Playwright, diff kuralları, snapshots (seçici), change log |
| **F3** | REST API | 3 gün | Liste, detay, changes, export (CSV/JSON), BullMQ job, Sentry |
| **F4** | Frontend UI | 4 gün | Dashboard, Projects, Detail, Sync Panel, filtre/rozetler |
| **F5** | Stabilizasyon | 2 gün | Testler, temizlik, dokümantasyon |
| **TOPLAM** | | **14–16 gün** | Prod-ready |

---

## 📋 F1 Kontrol Listesi (İskelet & Şema)

- [ ] Monorepo yapısı (`tokidb/app/frontend`, `backend`, `shared`)
- [ ] Docker Compose (postgres, redis, api, web)
- [ ] Prisma şema + ilk migration
- [ ] Seed script (81 il, proje tipleri)
- [ ] JWT auth setup + admin token
- [ ] Zod şemaları (ProjectRowSchema, vb.)
- [ ] Enum'lar & constants (`shared/constants.ts`)
- [ ] Parser v1 (Cheerio, versiyonlu)
- [ ] Parser fixtures (≥20 test case)
- [ ] Winston logger config
- [ ] Sentry integration
- [ ] Alert mekanizması (Slack, Email, Sentry)
- [ ] .env.example (tüm variables)

---

**Hazırlayan:** Augment Agent (Revize)
**Tarih:** 2025-10-24
**Durum:** Prod-Ready Plan ✅ → F1 Başlangıç 🚀

