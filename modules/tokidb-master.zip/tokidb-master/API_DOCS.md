# 📚 API Documentation

**TOKİDB REST API Reference**

---

## 🔑 Authentication

### Login
```http
POST /auth/login
Content-Type: application/json

{
  "email": "admin@tokidb.local",
  "password": "admin123"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIs...",
    "user": {
      "email": "admin@tokidb.local",
      "role": "admin"
    },
    "expiresIn": "24h"
  }
}
```

**Headers for Protected Endpoints:**
```http
Authorization: Bearer <token>
```

---

## 🏙️ Cities Endpoints

### Get All Cities
```http
GET /api/cities
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "İstanbul",
      "projectCount": 45,
      "avgSeviye": 75.5
    }
  ]
}
```

### Get City Detail
```http
GET /api/cities/:id
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "name": "İstanbul",
    "projects": [
      {
        "tokiId": 1001,
        "name": "Proje 1",
        "seviyePct": 80.5
      }
    ]
  }
}
```

---

## 📋 Projects Endpoints

### Get Projects List
```http
GET /api/projects?city_id=1&status=Devam%20Ediyor&min_seviye=50&max_seviye=100&q=proje&page=1&size=20
```

**Query Parameters:**
- `city_id` (number) - Filter by city
- `type_id` (number) - Filter by type
- `status` (string) - Filter by status
- `min_seviye` (number) - Min progress
- `max_seviye` (number) - Max progress
- `q` (string) - Search query
- `page` (number) - Page number (default: 1)
- `size` (number) - Items per page (default: 20, max: 100)

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "tokiId": 1001,
      "name": "Proje 1",
      "city": { "id": 1, "name": "İstanbul" },
      "type": { "id": 1, "name": "Konut" },
      "status": "Devam Ediyor",
      "seviyePct": 80.5,
      "unitCount": 500,
      "contractor": "Müteahhit A",
      "lastSeenAt": "2025-10-25T10:30:00Z"
    }
  ],
  "pagination": {
    "page": 1,
    "size": 20,
    "total": 150
  }
}
```

### Get Project Detail
```http
GET /api/projects/:tokiId
```

**Response:**
```json
{
  "success": true,
  "data": {
    "tokiId": 1001,
    "name": "Proje 1",
    "city": { "id": 1, "name": "İstanbul" },
    "type": { "id": 1, "name": "Konut" },
    "status": "Devam Ediyor",
    "seviyePct": 80.5,
    "unitCount": 500,
    "contractor": "Müteahhit A",
    "detailUrl": "https://toki.gov.tr/...",
    "firstSeenAt": "2025-01-01T00:00:00Z",
    "lastSeenAt": "2025-10-25T10:30:00Z",
    "changes": [
      {
        "id": 1,
        "changeType": "updated",
        "fields": { "seviyePct": 80.5 },
        "at": "2025-10-25T10:30:00Z"
      }
    ]
  }
}
```

---

## 📤 Export Endpoints

### Export Projects as CSV
```http
GET /api/export/projects.csv?city_id=1&status=Devam%20Ediyor
```

**Response:** CSV file (text/csv)

### Export Projects as JSON
```http
GET /api/export/projects.json?city_id=1&status=Devam%20Ediyor
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "tokiId": 1001,
      "name": "Proje 1",
      "city": "İstanbul",
      "status": "Devam Ediyor",
      "seviyePct": 80.5
    }
  ],
  "exportedAt": "2025-10-25T10:30:00Z",
  "totalCount": 150
}
```

### Export Analytics
```http
GET /api/export/analytics.json
```

**Response:**
```json
{
  "success": true,
  "data": {
    "totalProjects": 1500,
    "avgSeviye": 65.5,
    "byStatus": {
      "Devam Ediyor": 800,
      "Tamamlandı": 500,
      "Planlama": 200
    },
    "byCity": {
      "İstanbul": 150,
      "Ankara": 120
    },
    "recentChanges": {
      "created": 10,
      "updated": 25,
      "regressed": 5
    }
  }
}
```

---

## 🔧 Admin Endpoints (Protected)

### Trigger Manual Sync
```http
POST /api/admin/sync/trigger
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "jobId": "job-123456",
    "message": "Sync job queued"
  }
}
```

### Get Logs
```http
GET /api/admin/logs?limit=100
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "logs": [
      {
        "id": 1,
        "timestamp": "2025-10-25T10:30:00Z",
        "level": "info",
        "message": "Sync completed",
        "status": "completed",
        "stats": {
          "total": 1500,
          "created": 10,
          "updated": 25,
          "regressed": 5
        }
      }
    ],
    "total": 150
  }
}
```

### Get Alerts
```http
GET /api/admin/alerts?limit=50
Authorization: Bearer <token>
```

**Response:**
```json
{
  "success": true,
  "data": {
    "alerts": [
      {
        "id": 1,
        "type": "sync_failed",
        "severity": "critical",
        "title": "❌ Sync Failed",
        "message": "Database connection error",
        "timestamp": "2025-10-25T10:30:00Z"
      }
    ],
    "total": 5
  }
}
```

---

## ❌ Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": "Invalid request",
  "code": "INVALID_REQUEST"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "error": "Unauthorized",
  "code": "UNAUTHORIZED"
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": "Not found",
  "code": "NOT_FOUND"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": "Internal server error",
  "code": "INTERNAL_ERROR"
}
```

---

## 📊 Rate Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| Public API | 30 req | 5 min |
| Admin API | 1 req | 5 min |
| Login | 5 req | 15 min |

---

## 🔗 Base URL

- **Development:** http://localhost:3000
- **Production:** https://tokidb.com

---

**Last Updated:** 25 Ekim 2025

