# ⚡ TOKİDB Quick Start

**5 dakikada projeyi ayağa kaldır!**

---

## 🚀 Hızlı Başlangıç (Docker ile)

### 1. Docker Desktop Kur
- Windows: https://www.docker.com/products/docker-desktop
- Mac: https://www.docker.com/products/docker-desktop
- Linux: `sudo apt-get install docker.io docker-compose`

### 2. Projeyi Başlat

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

# Tüm services'i başlat
docker-compose up -d

# Logs'u izle
docker-compose logs -f
```

### 3. Database Setup

```bash
docker-compose exec backend pnpm run db:setup
```

### 4. Tarayıcıda Aç

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:3001
- **Admin Panel:** http://localhost:3000/admin

### 5. Giriş Yap

- **Email:** admin@tokidb.local
- **Şifre:** admin123

---

## 💻 Hızlı Başlangıç (Lokal Development)

### 1. Node.js Kur

**Windows:**
```powershell
# Chocolatey ile
choco install nodejs

# Veya https://nodejs.org/ adresinden indir
```

**Mac:**
```bash
brew install node
```

**Linux:**
```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
```

### 2. pnpm Kur

```bash
npm install -g pnpm
```

### 3. Dependencies Kur

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app
pnpm install
```

### 4. Database Başlat (Docker ile)

```bash
docker-compose up -d postgres redis
```

### 5. Environment Setup

```bash
cp .env.example .env
# .env dosyasını düzenle (opsiyonel)
```

### 6. Database Migration

```bash
pnpm run db:setup
```

### 7. Development Servers Başlat

**Terminal 1: Backend**
```bash
cd backend
pnpm run dev
```

**Terminal 2: Frontend**
```bash
cd frontend
pnpm run dev
```

### 8. Tarayıcıda Aç

- **Frontend:** http://localhost:3000
- **Backend API:** http://localhost:3001

---

## 🧪 Tests Çalıştır

```bash
# Tüm tests
pnpm run test

# Integration tests
pnpm run test:integration

# E2E tests
pnpm run test:e2e

# Coverage
pnpm run test:coverage
```

---

## 📊 Monitoring

### Logs

```bash
# Backend logs
docker-compose logs -f backend

# Frontend logs
docker-compose logs -f frontend

# Database logs
docker-compose logs -f postgres
```

### Health Check

```bash
# Backend health
curl http://localhost:3001/health

# Frontend
curl http://localhost:3000
```

### Services Status

```bash
docker-compose ps
```

---

## 🛑 Durdur

```bash
# Tüm services'i durdur
docker-compose down

# Volumes'ü sil (database reset)
docker-compose down -v
```

---

## 🆘 Sorun Giderme

### Port Zaten Kullanımda

```bash
# Port kullanan process'i bul ve kapat
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Mac/Linux
lsof -i :3000
kill -9 <PID>
```

### Database Bağlantı Hatası

```bash
# PostgreSQL çalışıyor mu kontrol et
docker-compose ps postgres

# Logs kontrol et
docker-compose logs postgres

# Yeniden başlat
docker-compose restart postgres
```

### Dependencies Hatası

```bash
# Cache temizle
pnpm store prune

# Yeniden kur
pnpm install --force
```

---

## 📚 Daha Fazla Bilgi

- **Kurulum Rehberi:** SETUP_INSTRUCTIONS.md
- **Sorun Giderme:** TROUBLESHOOTING.md
- **API Referansı:** API_DOCS.md
- **Deployment:** DEPLOYMENT_GUIDE.md

---

## ✅ Başarılı Kurulum Kontrol Listesi

- [ ] Docker Desktop kurulu ve çalışıyor
- [ ] `docker-compose up -d` başarılı
- [ ] `docker-compose ps` tüm services'i gösteriyor
- [ ] `pnpm run db:setup` başarılı
- [ ] http://localhost:3000 açılıyor
- [ ] Login sayfası görünüyor
- [ ] Demo kimlik bilgileri ile giriş yapılıyor
- [ ] Projects sayfası yükleniyor
- [ ] Admin panel erişilebiliyor

---

## 🎯 Sonraki Adımlar

1. ✅ Projeyi başlat
2. ✅ Frontend'i test et
3. ✅ Admin panel'i test et
4. ✅ API endpoints'i test et
5. ✅ Tests çalıştır
6. ✅ Production deployment'ı yap

---

**Kurulum Süresi:** ~5 dakika ⚡

**Sorun mu var?** Bkz. TROUBLESHOOTING.md

