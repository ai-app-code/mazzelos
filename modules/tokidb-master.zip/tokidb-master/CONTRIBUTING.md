# 🤝 Contributing Guide

**TOKİDB Projesine Katkıda Bulunma Rehberi**

---

## 📋 Başlamadan Önce

1. **Projeyi Fork Et**
   ```bash
   git clone https://github.com/YOUR_USERNAME/tokidb.git
   cd tokidb/app
   ```

2. **Dependencies Kur**
   ```bash
   pnpm install
   ```

3. **Development Branch Oluştur**
   ```bash
   git checkout -b feature/your-feature-name
   ```

---

## 🎯 Katkı Türleri

### 🐛 Bug Fix
```bash
git checkout -b fix/bug-description
# Fix yap
git commit -m "fix: description of the fix"
```

### ✨ Feature
```bash
git checkout -b feature/feature-name
# Feature yap
git commit -m "feat: description of the feature"
```

### 📚 Documentation
```bash
git checkout -b docs/documentation-name
# Docs yaz
git commit -m "docs: description of the documentation"
```

### 🎨 Style
```bash
git checkout -b style/style-changes
# Style değiştir
git commit -m "style: description of the style changes"
```

### ♻️ Refactor
```bash
git checkout -b refactor/refactor-name
# Refactor yap
git commit -m "refactor: description of the refactor"
```

---

## 💻 Development Setup

### Backend Development
```bash
# Terminal 1: Backend
cd backend
pnpm run dev

# Terminal 2: Database
docker-compose up postgres redis

# Terminal 3: Tests
pnpm run test:watch
```

### Frontend Development
```bash
# Terminal 1: Frontend
cd frontend
pnpm run dev

# Terminal 2: Tests
pnpm run test:watch
```

### Full Stack Development
```bash
# Docker ile
docker-compose up

# Veya manual
pnpm run dev
```

---

## 📝 Commit Conventions

### Format
```
<type>(<scope>): <subject>

<body>

<footer>
```

### Types
- `feat:` - Yeni feature
- `fix:` - Bug fix
- `docs:` - Documentation
- `style:` - Code style (formatting, semicolons, etc)
- `refactor:` - Code refactoring
- `perf:` - Performance improvement
- `test:` - Test addition/modification
- `chore:` - Build, dependencies, etc

### Examples
```bash
git commit -m "feat(projects): add project filtering by city"
git commit -m "fix(api): handle null values in response"
git commit -m "docs(readme): update installation instructions"
git commit -m "refactor(parser): simplify HTML parsing logic"
```

---

## 🧪 Testing

### Unit Tests
```bash
pnpm run test
pnpm run test:watch
pnpm run test:coverage
```

### Integration Tests
```bash
pnpm run test:integration
```

### E2E Tests
```bash
pnpm run test:e2e
```

### Coverage Hedefleri
- Statements: > 80%
- Branches: > 75%
- Functions: > 80%
- Lines: > 80%

---

## 🔍 Code Quality

### Linting
```bash
pnpm run lint
pnpm run lint:fix
```

### Type Checking
```bash
pnpm run type-check
```

### Formatting
```bash
pnpm run format
pnpm run format:check
```

### Pre-commit Hooks
```bash
# Husky setup
pnpm run prepare

# Otomatik olarak:
# - Lint
# - Format
# - Type check
# - Tests
```

---

## 📦 Pull Request Process

### 1. Commit & Push
```bash
git add .
git commit -m "feat: your feature"
git push origin feature/your-feature-name
```

### 2. Create Pull Request
- GitHub'da PR oluştur
- Template'i doldur
- Description ekle
- Screenshots/videos ekle (UI changes için)

### 3. PR Template
```markdown
## Description
Yaptığın değişiklikleri açıkla

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
Nasıl test ettin?

## Checklist
- [ ] Tests pass
- [ ] No linting errors
- [ ] Documentation updated
- [ ] No breaking changes
```

### 4. Review Process
- Minimum 1 approval gerekli
- CI/CD checks pass etmeli
- Conflicts resolve edilmeli

### 5. Merge
```bash
# Squash and merge
git merge --squash feature/your-feature-name
```

---

## 📁 Project Structure

```
tokidb/app/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   ├── middleware/
│   │   ├── services/
│   │   ├── routes/
│   │   ├── jobs/
│   │   └── index.ts
│   ├── prisma/
│   ├── __tests__/
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   ├── components/
│   │   ├── lib/
│   │   └── styles/
│   ├── e2e/
│   └── package.json
│
├── shared/
│   └── src/
│
└── package.json
```

---

## 🎨 Code Style

### TypeScript
```typescript
// ✅ Good
interface User {
  id: number;
  email: string;
  role: 'admin' | 'user';
}

const getUser = async (id: number): Promise<User> => {
  // implementation
};

// ❌ Bad
const getUser = async (id) => {
  // implementation
};
```

### React Components
```tsx
// ✅ Good
interface ProjectCardProps {
  project: Project;
  onSelect: (id: number) => void;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({
  project,
  onSelect
}) => {
  return (
    <div onClick={() => onSelect(project.id)}>
      {project.name}
    </div>
  );
};

// ❌ Bad
export const ProjectCard = ({ project, onSelect }) => {
  return <div onClick={() => onSelect(project.id)}>{project.name}</div>;
};
```

---

## 📚 Documentation

### README
- Setup instructions
- Usage examples
- API reference

### Code Comments
```typescript
// ✅ Good - Neden yapıldığını açıkla
// Cache 5 dakika boyunca geçerli, sonra refresh et
const staleTime = 5 * 60 * 1000;

// ❌ Bad - Açık olan şeyi açıklama
// Set stale time
const staleTime = 5 * 60 * 1000;
```

### JSDoc
```typescript
/**
 * Projeleri şehre göre filtrele
 * @param projects - Proje listesi
 * @param cityId - Şehir ID'si
 * @returns Filtrelenmiş projeler
 */
const filterByCity = (projects: Project[], cityId: number): Project[] => {
  return projects.filter(p => p.cityId === cityId);
};
```

---

## 🚀 Release Process

### Version Numbering
- Major: Breaking changes (1.0.0)
- Minor: New features (1.1.0)
- Patch: Bug fixes (1.1.1)

### Release Steps
```bash
# 1. Update version
npm version patch

# 2. Create tag
git tag v1.0.0

# 3. Push
git push origin main --tags

# 4. Create release on GitHub
```

---

## 📞 Communication

- **Issues:** GitHub Issues
- **Discussions:** GitHub Discussions
- **Email:** dev@tokidb.local
- **Slack:** #tokidb-dev

---

## 📋 Code of Conduct

- Saygılı ve kapsayıcı ol
- Yapıcı feedback ver
- Farklılıklara saygı duy
- Taciz ve ayrımcılığa tolerans yok

---

## ✅ Checklist

Katkı göndermeden önce:
- [ ] Fork ve clone ettim
- [ ] Feature branch oluşturdum
- [ ] Tests yazdım
- [ ] Tests pass ediyor
- [ ] Linting pass ediyor
- [ ] Type checking pass ediyor
- [ ] Documentation güncelledim
- [ ] Commit message format doğru
- [ ] PR template doldurdum

---

**Katkılarınız için teşekkürler! 🙏**

**Last Updated:** 25 Ekim 2025

