# 🚀 TOKİDB Kurulum Rehberi

**Projeyi ayağa kaldırmak için adım adım talimatlar**

---

## 📋 Gereksinimler

- **Node.js:** 20+ (LTS)
- **npm:** 10+
- **pnpm:** 8+
- **Docker:** 24+ (opsiyonel, production için)
- **Docker Compose:** 2.20+ (opsiyonel, production için)
- **PostgreSQL:** 15 (Docker ile veya lokal)
- **Redis:** 7 (Docker ile veya lokal)

---

## 🪟 Windows Kurulumu

### 1. Node.js Kurulumu

**Option A: Installer ile (Kolay)**
1. https://nodejs.org/ adresine git
2. LTS versiyonunu (20+) indir
3. Installer'ı çalıştır
4. "Add to PATH" seçeneğini işaretle
5. Kurulumu tamamla

**Option B: Chocolatey ile**
```powershell
choco install nodejs
```

**Option C: Windows Package Manager ile**
```powershell
winget install OpenJS.NodeJS
```

### 2. pnpm Kurulumu

```powershell
npm install -g pnpm
```

### 3. Versiyonları Kontrol Et

```powershell
node --version      # v20+
npm --version       # 10+
pnpm --version      # 8+
```

### 4. Docker Kurulumu (Opsiyonel)

1. https://www.docker.com/products/docker-desktop adresine git
2. Docker Desktop for Windows'u indir
3. Installer'ı çalıştır
4. WSL 2 backend'i seç
5. Kurulumu tamamla

```powershell
docker --version
docker-compose --version
```

---

## 🐧 Linux Kurulumu

### 1. Node.js Kurulumu

```bash
# Ubuntu/Debian
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Fedora/RHEL
sudo dnf install nodejs npm

# Arch
sudo pacman -S nodejs npm
```

### 2. pnpm Kurulumu

```bash
npm install -g pnpm
```

### 3. Docker Kurulumu

```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y docker.io docker-compose

# Fedora/RHEL
sudo dnf install -y docker docker-compose

# Arch
sudo pacman -S docker docker-compose

# Docker daemon başlat
sudo systemctl start docker
sudo systemctl enable docker

# Kullanıcıyı docker grubuna ekle
sudo usermod -aG docker $USER
```

---

## 🚀 Proje Kurulumu

### 1. Dependencies Kurulumu

```bash
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

pnpm install
```

### 2. Environment Setup

```bash
# .env dosyası oluştur
cp .env.example .env

# .env dosyasını düzenle
# Önemli değişkenler:
# - DATABASE_URL
# - REDIS_URL
# - JWT_SECRET
# - ADMIN_EMAIL
# - ADMIN_PASSWORD
```

### 3. Database Setup

**Option A: Docker ile (Kolay)**
```bash
docker-compose up -d postgres redis
```

**Option B: Lokal PostgreSQL ile**
```bash
# PostgreSQL 15 kur ve başlat
# Veritabanı oluştur
createdb tokidb

# .env'de DATABASE_URL ayarla
DATABASE_URL="postgresql://user:password@localhost:5432/tokidb"
```

### 4. Prisma Migration

```bash
pnpm run db:setup
```

### 5. Development Mode

**Terminal 1: Backend**
```bash
cd backend
pnpm run dev
# Backend: http://localhost:3001
```

**Terminal 2: Frontend**
```bash
cd frontend
pnpm run dev
# Frontend: http://localhost:3000
```

---

## 🐳 Docker ile Kurulum (Production)

### 1. Docker Compose ile Başlat

```bash
docker-compose -f docker-compose.prod.yml up -d
```

### 2. Logs Kontrol Et

```bash
docker-compose logs -f
```

### 3. Services Kontrol Et

```bash
docker-compose ps
```

### 4. Database Setup

```bash
docker-compose exec backend pnpm run db:setup
```

---

## 🧪 Tests Çalıştır

### Integration Tests

```bash
pnpm run test:integration
```

### E2E Tests

```bash
pnpm run test:e2e
```

### Tüm Tests

```bash
pnpm run test
```

---

## 📊 Monitoring

### Logs

```bash
# Backend logs
docker-compose logs -f backend

# Frontend logs
docker-compose logs -f frontend

# Database logs
docker-compose logs -f postgres
```

### Health Check

```bash
# Backend health
curl http://localhost:3001/health

# Frontend
curl http://localhost:3000
```

---

## 🔐 Demo Kimlik Bilgileri

- **Email:** admin@tokidb.local
- **Şifre:** admin123

---

## 🆘 Sorun Giderme

### Port Zaten Kullanımda

```powershell
# Port kullanan process bul
Get-NetTCPConnection -LocalPort 3000 | Select-Object OwningProcess

# Process'i kapat
Stop-Process -Id <PID> -Force
```

### Database Bağlantı Hatası

```bash
# PostgreSQL çalışıyor mu kontrol et
docker-compose ps postgres

# Logs kontrol et
docker-compose logs postgres

# Yeniden başlat
docker-compose restart postgres
```

### Dependencies Hatası

```bash
# Cache temizle
pnpm store prune

# Yeniden kur
pnpm install --force
```

---

## ✅ Başarılı Kurulum Kontrol Listesi

- [ ] Node.js 20+ kurulu
- [ ] pnpm 8+ kurulu
- [ ] Dependencies kuruldu (`pnpm install`)
- [ ] .env dosyası oluşturuldu
- [ ] PostgreSQL çalışıyor
- [ ] Redis çalışıyor
- [ ] Database migration tamamlandı (`pnpm run db:setup`)
- [ ] Backend dev server çalışıyor (`pnpm run dev`)
- [ ] Frontend dev server çalışıyor (`pnpm run dev`)
- [ ] http://localhost:3000 açılıyor
- [ ] Login sayfası görünüyor
- [ ] Demo kimlik bilgileri ile giriş yapılıyor

---

## 🎯 Sonraki Adımlar

1. ✅ Kurulumu tamamla
2. ✅ Tests çalıştır
3. ✅ Frontend'i aç ve test et
4. ✅ Admin panel'e gir
5. ✅ Sync trigger'ı test et
6. ✅ Production deployment'ı yap

---

**Kurulum Süresi:** ~10-15 dakika

**Sorun mu var?** Bkz. TROUBLESHOOTING.md

