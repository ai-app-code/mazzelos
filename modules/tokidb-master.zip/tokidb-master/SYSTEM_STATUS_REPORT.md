# 🔍 Sistem Durumu Raporu

**Tarih:** 25 Ekim 2025  
**Sistem:** Windows (PowerShell)

---

## ⚠️ Mevcut Durum

### Kurulu Olmayan Bileşenler ❌

| Bileşen | Durum | Gerekli | Öncelik |
|---------|-------|---------|---------|
| **Node.js** | ❌ Kurulu değil | ✅ GEREKLI | 🔴 KRITIK |
| **npm** | ❌ Kurulu değil | ✅ GEREKLI | 🔴 KRITIK |
| **pnpm** | ❌ Kurulu değil | ✅ GEREKLI | 🔴 KRITIK |
| **Docker** | ❌ İndiriliyor | ✅ GEREKLI | 🔴 KRITIK |
| **Docker Compose** | ❌ İndiriliyor | ✅ GEREKLI | 🔴 KRITIK |
| **Python** | ❌ Stub sadece | ⚠️ Opsiyonel | 🟡 ORTA |
| **PostgreSQL** | ❌ Kurulu değil | ✅ GEREKLI | 🔴 KRITIK |
| **Redis** | ❌ Kurulu değil | ✅ GEREKLI | 🔴 KRITIK |
| **Git** | ❌ Kontrol edilmedi | ⚠️ Opsiyonel | 🟢 DÜŞÜK |

---

## 🔴 KRITIK: Hemen Kurulması Gereken

### 1. Node.js 20+ (KRITIK)

**Neden gerekli?**
- Backend (Express.js) çalıştırmak için
- Frontend (Next.js) çalıştırmak için
- pnpm package manager çalıştırmak için

**Kurulum:**

**Windows:**
```powershell
# Option A: Chocolatey ile (Kolay)
choco install nodejs

# Option B: Direct download
# https://nodejs.org/ adresinden LTS (20+) indir ve kur

# Option C: Windows Package Manager
winget install OpenJS.NodeJS
```

**Kurulum sonrası kontrol:**
```powershell
node --version      # v20+
npm --version       # 10+
```

---

### 2. Docker Desktop (KRITIK)

**Neden gerekli?**
- PostgreSQL 15 çalıştırmak için
- Redis 7 çalıştırmak için
- Production deployment için

**Kurulum:**
1. https://www.docker.com/products/docker-desktop adresine git
2. "Docker Desktop for Windows" indir
3. Installer'ı çalıştır
4. WSL 2 backend'i seç
5. Kurulumu tamamla
6. Bilgisayarı yeniden başlat

**Kurulum sonrası kontrol:**
```powershell
docker --version
docker-compose --version
```

---

### 3. PostgreSQL 15 (KRITIK)

**Seçenekler:**

**Option A: Docker ile (Önerilen)**
```bash
docker-compose up -d postgres
```

**Option B: Lokal kurulum**
1. https://www.postgresql.org/download/windows/ adresinden indir
2. Installer'ı çalıştır
3. Port: 5432
4. Password: secure_password

---

### 4. Redis 7 (KRITIK)

**Seçenekler:**

**Option A: Docker ile (Önerilen)**
```bash
docker-compose up -d redis
```

**Option B: Lokal kurulum**
1. https://github.com/microsoftarchive/redis/releases adresinden indir
2. Installer'ı çalıştır
3. Port: 6379

---

## 🟡 ORTA: Python (Opsiyonel)

### Mevcut Durum
- Python stub var (Microsoft Store redirect)
- Gerçek Python kurulu değil

### Gerekli mi?
- ❌ Backend için gerekli değil
- ❌ Frontend için gerekli değil
- ⚠️ Bazı build tools için gerekli olabilir

### Kurulum (Opsiyonel)

**Windows:**
```powershell
# Option A: Python.org'dan indir
# https://www.python.org/downloads/

# Option B: Chocolatey ile
choco install python

# Option C: Windows Package Manager
winget install Python.Python.3.11
```

**Önerilen Sürümler:**
- Python 3.11 (Stable)
- Python 3.12 (Latest)

---

## 📦 Proje Bağımlılıkları

### Backend Bağımlılıkları

```json
{
  "dependencies": {
    "express": "^4.18.2",
    "prisma": "^5.0.0",
    "typescript": "^5.0.0",
    "zod": "^3.22.0",
    "winston": "^3.11.0",
    "bullmq": "^4.0.0",
    "redis": "^4.6.0",
    "cheerio": "^1.0.0",
    "playwright": "^1.40.0",
    "helmet": "^7.1.0",
    "express-rate-limit": "^7.1.0",
    "jsonwebtoken": "^9.1.0",
    "dotenv": "^16.3.1"
  }
}
```

### Frontend Bağımlılıkları

```json
{
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "typescript": "^5.0.0",
    "tailwindcss": "^3.3.0",
    "@tanstack/react-query": "^5.0.0",
    "react-hook-form": "^7.48.0",
    "zod": "^3.22.0",
    "axios": "^1.6.0"
  }
}
```

### DevOps Bağımlılıkları

```
- Docker 24+
- Docker Compose 2.20+
- PostgreSQL 15
- Redis 7
- Nginx (Docker image)
```

---

## ✅ Kurulum Sırası

### Adım 1: Node.js Kur (5 dakika)
```powershell
# Chocolatey ile
choco install nodejs

# Kontrol et
node --version
npm --version
```

### Adım 2: Docker Desktop Kur (10 dakika)
```
1. https://www.docker.com/products/docker-desktop indir
2. Installer'ı çalıştır
3. WSL 2 seç
4. Kurulumu tamamla
5. Bilgisayarı yeniden başlat
```

### Adım 3: pnpm Kur (1 dakika)
```powershell
npm install -g pnpm
pnpm --version
```

### Adım 4: PostgreSQL & Redis Başlat (2 dakika)
```bash
docker-compose up -d postgres redis
docker-compose ps
```

### Adım 5: Dependencies Kur (5 dakika)
```bash
pnpm install
```

### Adım 6: Database Setup (2 dakika)
```bash
pnpm run db:setup
```

### Adım 7: Projeyi Başlat (1 dakika)
```bash
# Terminal 1: Backend
cd backend && pnpm run dev

# Terminal 2: Frontend
cd frontend && pnpm run dev
```

---

## 📊 Toplam Kurulum Süresi

| Adım | Süre |
|------|------|
| Node.js | 5 min |
| Docker | 10 min |
| pnpm | 1 min |
| PostgreSQL & Redis | 2 min |
| Dependencies | 5 min |
| Database Setup | 2 min |
| **TOPLAM** | **~25 dakika** |

---

## 🎯 Kurulum Kontrol Listesi

- [ ] Node.js 20+ kurulu
- [ ] npm 10+ kurulu
- [ ] Docker Desktop kurulu
- [ ] Docker Compose kurulu
- [ ] pnpm 8+ kurulu
- [ ] PostgreSQL 15 çalışıyor
- [ ] Redis 7 çalışıyor
- [ ] `pnpm install` başarılı
- [ ] `pnpm run db:setup` başarılı
- [ ] Backend dev server çalışıyor
- [ ] Frontend dev server çalışıyor
- [ ] http://localhost:3000 açılıyor

---

## 🆘 Sorun Giderme

### Node.js kurulumu başarısız

```powershell
# Chocolatey yüklü mü kontrol et
choco --version

# Chocolatey yüklü değilse:
# https://chocolatey.org/install adresinden kur

# Veya direct download:
# https://nodejs.org/ adresinden LTS indir
```

### Docker kurulumu başarısız

```powershell
# WSL 2 kurulu mu kontrol et
wsl --list --verbose

# WSL 2 yüklü değilse:
# https://learn.microsoft.com/en-us/windows/wsl/install
```

### Port zaten kullanımda

```powershell
# Port kullanan process'i bul
netstat -ano | findstr :3000

# Process'i kapat
taskkill /PID <PID> /F
```

---

## 📝 Notlar

- **Python:** Proje için gerekli değil (opsiyonel)
- **Git:** Zaten kurulu olabilir (kontrol et)
- **Chocolatey:** Windows package manager (opsiyonel ama kolay)
- **WSL 2:** Docker Desktop için gerekli

---

## 🚀 Sonraki Adımlar

1. ✅ Node.js kur
2. ✅ Docker Desktop kur
3. ✅ pnpm kur
4. ✅ PostgreSQL & Redis başlat
5. ✅ Dependencies kur
6. ✅ Database setup
7. ✅ Projeyi başlat

---

**Tahmini Kurulum Süresi:** ~25 dakika

**Başlamaya hazır mısınız?**

