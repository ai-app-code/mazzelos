import { autoDetectParse } from './src/parser/auto-detect';

async function test() {
  console.log('🚀 TOKİ veri çekme testi başlıyor...\n');
  
  try {
    const result = await autoDetectParse();
    
    console.log('\n✅ SONUÇ:');
    console.log('Success:', result.success);
    console.log('Parser Version:', result.parser_version);
    console.log('Proje Sayısı:', result.projects.length);
    console.log('Hata:', result.error || 'Yok');
    
    if (result.projects.length > 0) {
      console.log('\n📊 İLK 3 PROJE:');
      result.projects.slice(0, 3).forEach((p, i) => {
        console.log(`\n${i + 1}. ${p.name}`);
        console.log(`   İl: ${p.city_name}`);
        console.log(`   Durum: ${p.status}`);
        console.log(`   Seviye: ${p.seviye_pct}%`);
      });
    }
  } catch (error) {
    console.error('\n❌ HATA:', error);
  }
  
  process.exit(0);
}

test();

