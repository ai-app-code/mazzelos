/**
 * LLM Service - Gemini API Integration
 * Handles contractor parsing using Google Gemini API
 */

import { GoogleGenerativeAI } from '@google/generative-ai';
import { ParsedCompany } from './parsing.types';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  throw new Error('GEMINI_API_KEY environment variable is not set');
}

const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);

export class LLMService {
  private model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
  private isHealthy = true;
  private lastError: string | null = null;

  /**
   * Check if LLM service is healthy
   */
  async healthCheck(): Promise<{ healthy: boolean; error?: string }> {
    try {
      // Just check if API key is set, don't make actual API call
      if (!GEMINI_API_KEY) {
        throw new Error('GEMINI_API_KEY not set');
      }
      this.isHealthy = true;
      this.lastError = null;
      return { healthy: true };
    } catch (error: any) {
      this.isHealthy = false;
      this.lastError = error.message;
      return { healthy: false, error: error.message };
    }
  }

  /**
   * Get LLM service status
   */
  getStatus() {
    return {
      healthy: this.isHealthy,
      lastError: this.lastError,
      model: 'gemini-1.5-flash'
    };
  }

  /**
   * Parse contractor string using Gemini LLM
   * Returns structured company data
   */
  async parseContractor(contractor: string): Promise<ParsedCompany> {
    if (!contractor || contractor.trim().length === 0) {
      return {
        companies: [],
        company_type: null,
        is_partnership: false,
        company_count: 0,
        confidence: 0
      };
    }

    try {
      const prompt = this.buildPrompt(contractor);
      
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();

      // Extract JSON from response
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        console.error('No JSON found in LLM response:', text);
        return this.getDefaultResponse();
      }

      const parsed = JSON.parse(jsonMatch[0]);

      return {
        companies: parsed.companies || [],
        company_type: parsed.company_type || null,
        is_partnership: parsed.is_partnership || false,
        company_count: parsed.company_count || 0,
        confidence: parsed.confidence || 95
      };
    } catch (error: any) {
      console.error('LLM parsing error:', error);
      return this.getDefaultResponse();
    }
  }

  /**
   * Build prompt for contractor parsing
   */
  private buildPrompt(contractor: string): string {
    return `Aşağıdaki TOKİ proje yüklenicisi bilgisini incele ve analiz et:

"${contractor}"

GÖREV:
1. Bu bir ortaklık mı değil mi? (2+ firma varsa ortaklık)
2. Eğer ortaklık ise: Ortak firmaların isimlerini parse et
3. Eğer ortaklık değilse: Tek firma adını döndür

PARSING KURALLARI:
- Ortaklık ayırıcıları: "-", "/", ",", "ve", "ile"
- Her firma adını temizle:
  * Suffix'leri kaldır: "A.Ş.", "Ltd. Şti.", "San. Ltd. Şti.", "İnş. San. Ltd. Şti.", "San. Ve Tic. Ltd. Şti.", vb.
  * Boşlukları normalize et
  * Başında/sonunda boşluk kaldır
- Şirket tipini belirle (son suffix'ten)

YANIT FORMAT (SADECE JSON, başka hiçbir şey yazma):
{
  "is_partnership": true/false,
  "companies": ["Firma 1", "Firma 2"],
  "company_count": 2,
  "company_type": "Ltd. Şti.",
  "confidence": 95
}`;
  }

  /**
   * Default response when parsing fails
   */
  private getDefaultResponse(): ParsedCompany {
    return {
      companies: [],
      company_type: null,
      is_partnership: false,
      company_count: 0,
      confidence: 0
    };
  }
}

export default new LLMService();

