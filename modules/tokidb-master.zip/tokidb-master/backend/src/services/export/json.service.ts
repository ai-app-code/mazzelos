/**
 * JSON Export Service
 * Exports projects to JSON format with nested objects
 */

import prisma from '../../config/database';
import { ProjectFilter } from '@tokidb/shared';
import logger from '../../config/logger';

export async function exportToJSON(
  filters?: ProjectFilter,
  includeSnapshots: boolean = false,
  includeChanges: boolean = false
): Promise<string> {
  try {
    logger.info('Exporting projects to JSON...');

    // Build where clause
    const where: any = {};
    if (filters?.city_id) where.city_id = filters.city_id;
    if (filters?.project_type_id) where.project_type_id = filters.project_type_id;
    if (filters?.status) where.status = filters.status;
    if (filters?.min_seviye !== undefined || filters?.max_seviye !== undefined) {
      where.seviye_pct = {};
      if (filters.min_seviye !== undefined) where.seviye_pct.gte = filters.min_seviye;
      if (filters.max_seviye !== undefined) where.seviye_pct.lte = filters.max_seviye;
    }
    if (filters?.search) {
      where.name = {
        contains: filters.search,
        mode: 'insensitive',
      };
    }

    // Fetch projects with relations
    const projects = await prisma.project.findMany({
      where,
      include: {
        city: true,
        project_type: true,
        snapshots: includeSnapshots ? { take: 10, orderBy: { snapshot_at: 'desc' } } : false,
        changes: includeChanges ? { take: 20, orderBy: { detected_at: 'desc' } } : false,
      },
      orderBy: { created_at: 'desc' },
      take: 10000, // Max export limit
    });

    const json = JSON.stringify(
      {
        exported_at: new Date().toISOString(),
        total_projects: projects.length,
        filters: filters || {},
        projects: projects.map((p) => ({
          toki_id: p.toki_id,
          name: p.name,
          city: {
            id: p.city.id,
            name: p.city.name,
            plate_code: p.city.plate_code,
          },
          project_type: {
            id: p.project_type.id,
            name: p.project_type.name,
            slug: p.project_type.slug,
          },
          status: p.status,
          seviye_pct: p.seviye_pct,
          contractor: p.contractor,
          unit_count: p.unit_count,
          detail_url: p.detail_url,
          last_synced_at: p.last_synced_at,
          created_at: p.created_at,
          updated_at: p.updated_at,
          ...(includeSnapshots && { snapshots: p.snapshots }),
          ...(includeChanges && { changes: p.changes }),
        })),
      },
      null,
      2
    );

    logger.info(`Exported ${projects.length} projects to JSON`);
    return json;
  } catch (error) {
    logger.error('JSON export failed:', error);
    throw error;
  }
}

