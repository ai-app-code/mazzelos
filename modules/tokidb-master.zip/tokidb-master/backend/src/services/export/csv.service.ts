/**
 * CSV Export Service
 * Exports projects to CSV format (UTF-8 with BOM)
 */

import prisma from '../../config/database';
import { ProjectFilter } from '@tokidb/shared';
import logger from '../../config/logger';

export async function exportToCSV(filters?: ProjectFilter): Promise<string> {
  try {
    logger.info('Exporting projects to CSV...');

    // Build where clause
    const where: any = {};
    if (filters?.city_id) where.city_id = filters.city_id;
    if (filters?.project_type_id) where.project_type_id = filters.project_type_id;
    if (filters?.status) where.status = filters.status;
    if (filters?.min_seviye !== undefined || filters?.max_seviye !== undefined) {
      where.seviye_pct = {};
      if (filters.min_seviye !== undefined) where.seviye_pct.gte = filters.min_seviye;
      if (filters.max_seviye !== undefined) where.seviye_pct.lte = filters.max_seviye;
    }
    if (filters?.search) {
      where.name = {
        contains: filters.search,
        mode: 'insensitive',
      };
    }

    // Fetch projects with relations
    const projects = await prisma.project.findMany({
      where,
      include: {
        city: true,
        project_type: true,
      },
      orderBy: { created_at: 'desc' },
      take: 10000, // Max export limit
    });

    // Build CSV
    const headers = [
      'TOKİ ID',
      'Proje Adı',
      'İl',
      'Proje Tipi',
      'Durum',
      'Seviye (%)',
      'Yüklenici',
      'Konut Sayısı',
      'Detay URL',
      'Son Senkronizasyon',
      'Oluşturulma Tarihi',
    ];

    const rows = projects.map((p) => [
      p.toki_id,
      p.name,
      p.city.name,
      p.project_type.name,
      p.status,
      p.seviye_pct?.toString() || '',
      p.contractor || '',
      p.unit_count?.toString() || '',
      p.detail_url || '',
      p.last_synced_at?.toISOString() || '',
      p.created_at.toISOString(),
    ]);

    // UTF-8 BOM for Excel compatibility
    const BOM = '\uFEFF';
    const csv = BOM + [headers, ...rows].map((row) => row.map(escapeCSV).join(',')).join('\n');

    logger.info(`Exported ${projects.length} projects to CSV`);
    return csv;
  } catch (error) {
    logger.error('CSV export failed:', error);
    throw error;
  }
}

function escapeCSV(value: string): string {
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}

