/**
 * Slack Alert Service
 * Sends notifications to Slack webhook
 */

import axios from 'axios';
import prisma from '../../config/database';
import { AlertType } from '@tokidb/shared';
import logger from '../../config/logger';

const SLACK_WEBHOOK_URL = process.env.SLACK_WEBHOOK_URL;

export async function sendAlert(
  alertType: AlertType,
  projectId: number | null,
  message: string,
  metadata?: any
): Promise<void> {
  try {
    // Save alert to database
    await prisma.alert.create({
      data: {
        alert_type: alertType,
        project_id: projectId,
        message,
        metadata: metadata || {},
        sent_at: null,
      },
    });

    // Send to Slack if configured
    if (SLACK_WEBHOOK_URL) {
      await sendToSlack(alertType, message, metadata);
    } else {
      logger.debug('Slack webhook not configured, alert saved to database only');
    }
  } catch (error) {
    logger.error('Failed to send alert:', error);
  }
}

async function sendToSlack(
  alertType: AlertType,
  message: string,
  metadata?: any
): Promise<void> {
  if (!SLACK_WEBHOOK_URL || SLACK_WEBHOOK_URL.includes('YOUR/WEBHOOK')) {
    logger.debug('Slack webhook not configured or invalid, skipping');
    return;
  }

  try {
    const color = getAlertColor(alertType);
    const emoji = getAlertEmoji(alertType);

    await axios.post(SLACK_WEBHOOK_URL, {
      text: `${emoji} *TOKİDB Alert*`,
      attachments: [
        {
          color,
          fields: [
            {
              title: 'Type',
              value: alertType,
              short: true,
            },
            {
              title: 'Message',
              value: message,
              short: false,
            },
          ],
          footer: 'TOKİDB',
          ts: Math.floor(Date.now() / 1000),
        },
      ],
    });

    logger.info(`Slack alert sent: ${alertType}`);
  } catch (error) {
    logger.error('Failed to send Slack notification:', error);
  }
}

function getAlertColor(alertType: AlertType): string {
  switch (alertType) {
    case AlertType.NEW_PROJECT:
      return 'good'; // green
    case AlertType.LEVEL_INCREASE:
      return 'good'; // green
    case AlertType.LEVEL_DECREASE:
      return 'danger'; // red
    case AlertType.STATUS_CHANGE:
      return 'warning'; // yellow
    case AlertType.SYNC_ERROR:
      return 'danger'; // red
    case AlertType.PARSER_FALLBACK:
      return 'warning'; // yellow
    default:
      return '#808080'; // gray
  }
}

function getAlertEmoji(alertType: AlertType): string {
  switch (alertType) {
    case AlertType.NEW_PROJECT:
      return '🆕';
    case AlertType.LEVEL_INCREASE:
      return '📈';
    case AlertType.LEVEL_DECREASE:
      return '📉';
    case AlertType.STATUS_CHANGE:
      return '🔄';
    case AlertType.SYNC_ERROR:
      return '❌';
    case AlertType.PARSER_FALLBACK:
      return '⚠️';
    default:
      return '📢';
  }
}

