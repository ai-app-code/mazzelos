/**
 * Ingest Service - 5-Step Orchestration
 * 
 * Steps:
 * 1. FETCH - Parse TOKİ website
 * 2. DUPLICATE CHECK - Remove duplicates
 * 3. COMPARE - Detect changes (diff)
 * 4. UPDATE - Update database
 * 5. ALERT - Send notifications
 */

import prisma from '../../config/database';
import { autoDetectParse } from '../../parser/auto-detect';
import { removeDuplicates } from './duplicate-detection.service';
import { detectChanges, shouldCreateSnapshot } from './diff.service';
import { createSnapshot } from './snapshot.service';
import { sendAlert } from '../alerts/slack.service';
import { ParsedProject, ChangeType, AlertType } from '@tokidb/shared';
import logger from '../../config/logger';
import crypto from 'crypto';
import llmService from '../llm.service';

// Generate hash ID from project name (max 255 chars)
function generateTokiId(projectName: string): string {
  const hash = crypto.createHash('sha256').update(projectName).digest('hex');
  return hash.substring(0, 64); // 64 char hash (safe for VARCHAR(255))
}

// Truncate project name to 500 chars
function truncateProjectName(name: string): string {
  return name.substring(0, 500);
}

export interface IngestResult {
  success: boolean;
  parser_version: string;
  projects_fetched: number;
  projects_created: number;
  projects_updated: number;
  projects_deleted: number;
  error?: string;
}

export async function runIngest(): Promise<IngestResult> {
  const startTime = new Date(); // ✓ Sync başlangıcı
  const startTimeMs = Date.now();
  logger.info('=== Starting 5-Step Ingest Process ===');

  let projectsFetched = 0;
  let projectsCreated = 0;
  let projectsUpdated = 0;
  let projectsDeleted = 0;
  let parserVersion = 'unknown';

  try {
    // STEP 1: FETCH - Parse TOKİ website
    logger.info('[STEP 1/5] FETCH - Parsing TOKİ website...');
    const parseResult = await autoDetectParse();

    // ✓ Better error handling
    if (!parseResult.success) {
      throw new Error(`Parse failed: ${parseResult.error || 'Unknown error'}`);
    }

    if (parseResult.projects.length === 0) {
      throw new Error('Parse succeeded but no projects found - this might indicate a website structure change');
    }

    parserVersion = parseResult.version;
    projectsFetched = parseResult.projects.length;
    logger.info(`[STEP 1/5] ✓ Fetched ${projectsFetched} projects using parser ${parserVersion}`);

    // STEP 2: DUPLICATE CHECK - Remove duplicates
    logger.info('[STEP 2/5] DUPLICATE CHECK - Removing duplicates...');
    const uniqueProjects = removeDuplicates(parseResult.projects);
    logger.info(`[STEP 2/5] ✓ ${uniqueProjects.length} unique projects (removed ${projectsFetched - uniqueProjects.length} duplicates)`);

    // STEP 3 & 4: COMPARE & UPDATE - Process each project
    logger.info('[STEP 3/5] COMPARE - Detecting changes...');
    logger.info('[STEP 4/5] UPDATE - Updating database...');

    const processedTokiIds = new Set<string>();

    const nullProjects: Array<{name: string; city: string; type: string}> = [];
    let processedCount = 0;

    for (const parsedProject of uniqueProjects) {
      try {
        const hashedTokiId = await processProject(parsedProject);
        processedCount++;

        if (hashedTokiId) {
          processedTokiIds.add(hashedTokiId);
        } else {
          nullProjects.push({
            name: parsedProject.name,
            city: parsedProject.city_name,
            type: parsedProject.project_type_name
          });
          logger.error(`[CRITICAL] Project returned null: "${parsedProject.name}" | City: "${parsedProject.city_name}" | Type: "${parsedProject.project_type_name}"`);
        }
      } catch (error) {
        logger.error(`[CRITICAL] Failed to process project ${parsedProject.name}:`, error);
      }
    }

    logger.info(`[DEBUG] Loop completed: ${processedCount} projects processed`);
    logger.info(`[DEBUG] processedTokiIds size: ${processedTokiIds.size} out of ${uniqueProjects.length}`);
    if (nullProjects.length > 0) {
      logger.error(`[DEBUG] ⚠️ ${nullProjects.length} projects returned null:`);
      nullProjects.forEach(p => {
        logger.error(`  - Project: "${p.name}" | City: "${p.city}" | Type: "${p.type}"`);
      });
    }

    // Count created/updated - Pass sync start time!
    const stats = await getIngestStats(startTime);
    projectsCreated = stats.created;
    projectsUpdated = stats.updated;

    logger.info(`[STEP 4/5] ✓ Created: ${projectsCreated}, Updated: ${projectsUpdated}`);

    // STEP 5: ALERT - Mark deleted projects (soft delete)
    logger.info('[STEP 5/5] ALERT - Checking for deleted projects...');
    projectsDeleted = await markDeletedProjects(processedTokiIds);
    logger.info(`[STEP 5/5] ✓ Marked ${projectsDeleted} projects as deleted`);

    const duration = ((Date.now() - startTimeMs) / 1000).toFixed(2);
    logger.info(`=== Ingest Complete in ${duration}s ===`);

    return {
      success: true,
      parser_version: parserVersion,
      projects_fetched: projectsFetched,
      projects_created: projectsCreated,
      projects_updated: projectsUpdated,
      projects_deleted: projectsDeleted,
    };
  } catch (error: any) {
    logger.error('Ingest failed:', error);
    return {
      success: false,
      parser_version: parserVersion,
      projects_fetched: projectsFetched,
      projects_created: projectsCreated,
      projects_updated: projectsUpdated,
      projects_deleted: projectsDeleted,
      error: error.message,
    };
  }
}

async function processProject(parsedProject: ParsedProject): Promise<string | null> {
  // Generate hash ID from project name
  const hashedTokiId = generateTokiId(parsedProject.name);

  // Find city
  const city = await prisma.city.findFirst({
    where: { name: parsedProject.city_name },
  });

  if (!city) {
    logger.error(`[DEBUG] City not found for project: ${parsedProject.name} | City: ${parsedProject.city_name}`);
    return null;
  }

  // Find project type
  const projectType = await prisma.projectType.findFirst({
    where: { name: parsedProject.project_type_name },
  });

  if (!projectType) {
    logger.error(`[DEBUG] Project type not found for project: ${parsedProject.name} | Type: ${parsedProject.project_type_name}`);
    return null;
  }

  // Check if project exists
  const existingProject = await prisma.project.findUnique({
    where: { toki_id: hashedTokiId },
  });

  // Detect changes
  const diffResult = detectChanges(existingProject, parsedProject);

  if (!existingProject) {
    // Create new project
    const newProject = await prisma.project.create({
      data: {
        toki_id: hashedTokiId,
        name: truncateProjectName(parsedProject.name),
        city_id: city.id,
        project_type_id: projectType.id,
        status: parsedProject.status,
        seviye_pct: parsedProject.seviye_pct,
        contractor: parsedProject.contractor,
        is_partnership: null,  // Will be set by parsing service
        unit_count: parsedProject.unit_count,
        detail_url: parsedProject.detail_url,
        last_synced_at: new Date(),
      },
    });

    // Parse contractor BEFORE saving to DB (new project)
    let parsedContractorData: any = {
      companies: [] as string[],
      is_partnership: false,
      company_count: 0,
      company_type: null as string | null,
      confidence: 0
    };

    if (parsedProject.contractor) {
      try {
        console.log(`🤖 LLM parsing for NEW project ${newProject.id}: ${parsedProject.contractor}`);
        parsedContractorData = await llmService.parseContractor(parsedProject.contractor);
      } catch (error: any) {
        console.error(`❌ LLM parsing failed for project ${newProject.id}:`, error.message);
      }
    }

    // Save parsed contractor to DB
    await prisma.parsedContractor.create({
      data: {
        project_id: newProject.id,
        original_contractor: parsedProject.contractor || 'UNKNOWN',
        parsed_companies: parsedContractorData.companies || [],
        is_partnership: parsedContractorData.is_partnership,
        company_count: parsedContractorData.company_count,
        company_type: parsedContractorData.company_type,
        parsing_method: 'LLM',
        confidence: parsedContractorData.confidence,
        parsing_status: 'COMPLETED',
        needs_parsing: false  // Already parsed
      }
    }).catch(() => {
      // If it already exists, just skip
    });

    // Update project with partnership flag
    await prisma.project.update({
      where: { id: newProject.id },
      data: { is_partnership: parsedContractorData.is_partnership }
    });

    // Create initial snapshot (non-blocking - don't fail if snapshot fails)
    try {
      await createSnapshot(newProject, parsedProject);
    } catch (snapshotError) {
      logger.warn(`Snapshot creation failed for project ${newProject.toki_id}, but project was created successfully`);
    }

    // Log change
    await prisma.projectChange.create({
      data: {
        project_id: newProject.id,
        change_type: ChangeType.CREATED,
        detected_at: new Date(),
      },
    });

    // Send alert
    await sendAlert(AlertType.NEW_PROJECT, newProject.id, `New project: ${parsedProject.name}`);

    // Return the hashed toki_id so it can be added to processedTokiIds
    return hashedTokiId;
  } else {
    // Check if contractor changed
    const contractorChanged = existingProject.contractor !== parsedProject.contractor;

    // Update existing project
    await prisma.project.update({
      where: { id: existingProject.id },
      data: {
        name: truncateProjectName(parsedProject.name),
        status: parsedProject.status,
        seviye_pct: parsedProject.seviye_pct,
        contractor: parsedProject.contractor,
        unit_count: parsedProject.unit_count,
        detail_url: parsedProject.detail_url,
        last_synced_at: new Date(),
      },
    });

    // If contractor changed, parse it BEFORE saving
    if (contractorChanged && parsedProject.contractor) {
      let parsedContractorData: any = {
        companies: [] as string[],
        is_partnership: false,
        company_count: 0,
        company_type: null as string | null,
        confidence: 0
      };

      try {
        console.log(`🤖 LLM parsing for CHANGED contractor project ${existingProject.id}: ${parsedProject.contractor}`);
        parsedContractorData = await llmService.parseContractor(parsedProject.contractor);
      } catch (error: any) {
        console.error(`❌ LLM parsing failed for project ${existingProject.id}:`, error.message);
      }

      await prisma.parsedContractor.upsert({
        where: { project_id: existingProject.id },
        create: {
          project_id: existingProject.id,
          original_contractor: parsedProject.contractor,
          parsed_companies: parsedContractorData.companies || [],
          is_partnership: parsedContractorData.is_partnership,
          company_count: parsedContractorData.company_count,
          company_type: parsedContractorData.company_type,
          parsing_method: 'LLM',
          confidence: parsedContractorData.confidence,
          parsing_status: 'COMPLETED',
          needs_parsing: false  // Already parsed
        },
        update: {
          original_contractor: parsedProject.contractor,
          parsed_companies: parsedContractorData.companies || [],
          is_partnership: parsedContractorData.is_partnership,
          company_count: parsedContractorData.company_count,
          company_type: parsedContractorData.company_type,
          parsing_method: 'LLM',
          confidence: parsedContractorData.confidence,
          parsing_status: 'COMPLETED',
          needs_parsing: false,  // Already parsed
          updated_at: new Date()
        }
      });

      // Update project with new partnership flag
      await prisma.project.update({
        where: { id: existingProject.id },
        data: { is_partnership: parsedContractorData.is_partnership }
      });
    }

    // Create snapshot if needed (non-blocking - don't fail if snapshot fails)
    if (shouldCreateSnapshot(diffResult)) {
      try {
        await createSnapshot(existingProject, parsedProject);
      } catch (snapshotError) {
        logger.warn(`Snapshot creation failed for project ${existingProject.toki_id}, but project was updated successfully`);
      }
    }

    // Log changes
    for (const fieldChange of diffResult.field_changes) {
      await prisma.projectChange.create({
        data: {
          project_id: existingProject.id,
          change_type: diffResult.change_type,
          field_name: fieldChange.field_name,
          old_value: String(fieldChange.old_value),
          new_value: String(fieldChange.new_value),
          detected_at: new Date(),
        },
      });
    }

    // Send alerts for significant changes
    if (diffResult.change_type === ChangeType.UPDATED) {
      await sendAlert(AlertType.LEVEL_INCREASE, existingProject.id, `Level increased for ${parsedProject.name}`);
    } else if (diffResult.change_type === ChangeType.REGRESSED) {
      await sendAlert(AlertType.LEVEL_DECREASE, existingProject.id, `Level DECREASED for ${parsedProject.name}`);
    }

    // Return the hashed toki_id so it can be added to processedTokiIds
    return hashedTokiId;
  }

  // Should never reach here, but return null just in case
  return null;
}

async function getIngestStats(syncStartTime: Date) {
  // ✓ Count all changes from sync start time (not just last minute!)
  const recentChanges = await prisma.projectChange.findMany({
    where: {
      detected_at: {
        gte: syncStartTime, // From sync start, not last minute!
      },
    },
  });

  const created = recentChanges.filter((c) => c.change_type === ChangeType.CREATED).length;
  const updated = recentChanges.filter((c) => c.change_type !== ChangeType.CREATED).length;

  logger.info(`[Stats] Created: ${created}, Updated: ${updated}, Total changes: ${recentChanges.length}`);
  return { created, updated };
}

async function markDeletedProjects(processedIds: Set<string>): Promise<number> {
  // Find projects not in current sync
  const allProjects = await prisma.project.findMany({
    select: { id: true, toki_id: true },
  });

  let deletedCount = 0;

  for (const project of allProjects) {
    if (!processedIds.has(project.toki_id)) {
      await prisma.projectChange.create({
        data: {
          project_id: project.id,
          change_type: ChangeType.DELETED,
          detected_at: new Date(),
        },
      });
      deletedCount++;
    }
  }

  return deletedCount;
}

