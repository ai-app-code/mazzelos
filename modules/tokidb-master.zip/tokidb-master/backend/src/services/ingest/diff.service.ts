/**
 * Diff Service - Level-based Change Detection
 * 
 * Logic:
 * - Seviye ↑ → UPDATED (+snapshot)
 * - Seviye ↓ → REGRESSED (+snapshot)
 * - Seviye = but tracked fields changed → META_UPDATED (+snapshot)
 * - New project → CREATED
 * - Missing project → DELETED (soft delete)
 */

import { Project } from '@prisma/client';
import { ParsedProject, ChangeType, DiffResult, FieldChange, TRACKED_FIELDS } from '@tokidb/shared';
import logger from '../../config/logger';

export function detectChanges(
  existingProject: Project | null,
  parsedProject: ParsedProject
): DiffResult {
  // New project
  if (!existingProject) {
    return {
      change_type: ChangeType.CREATED,
      field_changes: [],
      needs_snapshot: true,
    };
  }

  const fieldChanges: FieldChange[] = [];
  const oldSeviye = existingProject.seviye_pct;
  const newSeviye = parsedProject.seviye_pct;

  // Check each tracked field
  TRACKED_FIELDS.forEach((field) => {
    let oldValue: any;
    let newValue: any;

    switch (field) {
      case 'seviye_pct':
        oldValue = existingProject.seviye_pct;
        newValue = parsedProject.seviye_pct;
        break;
      case 'status':
        oldValue = existingProject.status;
        newValue = parsedProject.status;
        break;
      case 'contractor':
        oldValue = existingProject.contractor;
        newValue = parsedProject.contractor;
        break;
      case 'unit_count':
        oldValue = existingProject.unit_count;
        newValue = parsedProject.unit_count;
        break;
      case 'name':
        oldValue = existingProject.name;
        newValue = parsedProject.name;
        break;
      case 'detail_url':
        oldValue = existingProject.detail_url;
        newValue = parsedProject.detail_url;
        break;
    }

    // Normalize null vs undefined
    const normalizedOld = oldValue === undefined ? null : oldValue;
    const normalizedNew = newValue === undefined ? null : newValue;

    if (normalizedOld !== normalizedNew) {
      fieldChanges.push({
        field_name: field,
        old_value: normalizedOld,
        new_value: normalizedNew,
      });
    }
  });

  // No changes
  if (fieldChanges.length === 0) {
    return {
      change_type: ChangeType.UPDATED,
      field_changes: [],
      needs_snapshot: false,
    };
  }

  // Determine change type based on seviye_pct
  const seviyeChanged = fieldChanges.some((fc) => fc.field_name === 'seviye_pct');

  if (seviyeChanged) {
    // Level increased
    if (newSeviye !== null && oldSeviye !== null && newSeviye > oldSeviye) {
      logger.info(`Project ${parsedProject.toki_id}: Level increased ${oldSeviye}% → ${newSeviye}%`);
      return {
        change_type: ChangeType.UPDATED,
        field_changes: fieldChanges,
        needs_snapshot: true,
      };
    }

    // Level decreased (regression)
    if (newSeviye !== null && oldSeviye !== null && newSeviye < oldSeviye) {
      logger.warn(`Project ${parsedProject.toki_id}: Level REGRESSED ${oldSeviye}% → ${newSeviye}%`);
      return {
        change_type: ChangeType.REGRESSED,
        field_changes: fieldChanges,
        needs_snapshot: true,
      };
    }
  }

  // Level unchanged but other tracked fields changed
  logger.info(`Project ${parsedProject.toki_id}: Metadata updated (${fieldChanges.length} fields)`);
  return {
    change_type: ChangeType.META_UPDATED,
    field_changes: fieldChanges,
    needs_snapshot: true,
  };
}

export function shouldCreateSnapshot(diffResult: DiffResult): boolean {
  return diffResult.needs_snapshot;
}

