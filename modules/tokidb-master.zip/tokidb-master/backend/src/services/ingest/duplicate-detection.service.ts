/**
 * Duplicate Detection Service
 * Uses Levenshtein distance to detect duplicate projects
 * Threshold: distance < 3
 */

import { ParsedProject } from '@tokidb/shared';
import logger from '../../config/logger';

const LEVENSHTEIN_THRESHOLD = 10; // Increased from 3 to avoid false positives

/**
 * Calculate Levenshtein distance between two strings
 */
function levenshteinDistance(str1: string, str2: string): number {
  const len1 = str1.length;
  const len2 = str2.length;
  const matrix: number[][] = [];

  // Initialize matrix
  for (let i = 0; i <= len1; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= len2; j++) {
    matrix[0][j] = j;
  }

  // Fill matrix
  for (let i = 1; i <= len1; i++) {
    for (let j = 1; j <= len2; j++) {
      const cost = str1[i - 1] === str2[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1, // deletion
        matrix[i][j - 1] + 1, // insertion
        matrix[i - 1][j - 1] + cost // substitution
      );
    }
  }

  return matrix[len1][len2];
}

/**
 * Remove numbers, bölge/etap/kısım variations for comparison
 * This helps identify true duplicates while ignoring phase/section differences
 */
function normalizeForDuplicateCheck(str: string): string {
  return str
    .toLowerCase()
    // Remove all numbers (phases, sections, unit counts)
    .replace(/\d+/g, '')
    // Remove common phase/section keywords
    .replace(/\b(bölge|etap|kısım|aşama|faz|adası|mıntıka)\b/g, '')
    // Remove extra spaces and special chars
    .replace(/[^a-z]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Normalize string for comparison (original - keeps structure)
 */
function normalizeString(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

/**
 * Check if two projects are duplicates
 * Uses smart comparison: removes numbers/phases to find true duplicates
 */
export function isDuplicate(project1: ParsedProject, project2: ParsedProject): boolean {
  // Same toki_id = not duplicate (same project)
  if (project1.toki_id === project2.toki_id) {
    return false;
  }

  // Different cities = not duplicate
  if (project1.city_name !== project2.city_name) {
    return false;
  }

  // Compare normalized names (for structure)
  const name1 = normalizeString(project1.name);
  const name2 = normalizeString(project2.name);
  const distance = levenshteinDistance(name1, name2);

  // If very similar (distance < 3), it's likely a true duplicate
  if (distance < 3) {
    logger.warn(`Potential duplicate detected: "${project1.name}" vs "${project2.name}" (distance: ${distance})`);
    return true;
  }

  // For distance 3-10, use smart comparison (remove numbers/phases)
  if (distance < LEVENSHTEIN_THRESHOLD) {
    const normalized1 = normalizeForDuplicateCheck(project1.name);
    const normalized2 = normalizeForDuplicateCheck(project2.name);

    // If they're identical after removing numbers/phases, they're duplicates
    if (normalized1 === normalized2 && normalized1.length > 10) {
      logger.warn(`Potential duplicate detected (after normalization): "${project1.name}" vs "${project2.name}"`);
      return true;
    }
  }

  return false;
}

/**
 * Remove duplicates from parsed projects
 * Keeps the first occurrence
 *
 * DISABLED: Duplicate detection was too aggressive and removing legitimate projects
 * (e.g., "1. Bölge" vs "2. Bölge" are different projects, not duplicates)
 *
 * TODO: Implement smarter duplicate detection that:
 * - Only removes exact duplicates (distance = 0)
 * - Ignores phase/section/block number differences
 * - Requires manual review for edge cases
 */
export function removeDuplicates(projects: ParsedProject[]): ParsedProject[] {
  // DISABLED: Return all projects without removing any
  logger.info(`Duplicate detection DISABLED: Keeping all ${projects.length} projects`);
  return projects;
}

