/**
 * Snapshot Service
 * Manages selective snapshots (only on changes)
 * Retention: 180 days hot, >180 days archived
 */

import prisma from '../../config/database';
import { Project } from '@prisma/client';
import { ParsedProject } from '@tokidb/shared';
import logger from '../../config/logger';

const SNAPSHOT_RETENTION_DAYS = 180;

/**
 * Truncate text to safe length for database
 */
function truncateText(text: string | null | undefined, maxLength: number): string | null {
  if (!text) return null;
  return text.length > maxLength ? text.substring(0, maxLength) : text;
}

/**
 * Create a snapshot of a project
 */
export async function createSnapshot(
  project: Project,
  parsedData: ParsedProject
): Promise<void> {
  try {
    // Get project_type_id from parsed data
    const projectType = await prisma.projectType.findFirst({
      where: {
        name: parsedData.project_type_name,
      },
    });

    if (!projectType) {
      logger.warn(`Project type not found: ${parsedData.project_type_name}`);
      return;
    }

    await prisma.projectSnapshot.create({
      data: {
        project_id: project.id,
        seviye_pct: parsedData.seviye_pct,
        status: truncateText(parsedData.status || 'UNKNOWN', 50) || 'UNKNOWN',
        contractor: truncateText(parsedData.contractor, 500),
        unit_count: parsedData.unit_count,
        name: truncateText(parsedData.name || 'Unknown', 1000) || 'Unknown', // Truncate to safe length
        project_type_id: projectType.id,
        detail_url: truncateText(parsedData.detail_url, 1000),
        snapshot_at: new Date(),
      },
    });

    logger.debug(`Snapshot created for project ${project.toki_id}`);
  } catch (error) {
    logger.error(`Failed to create snapshot for project ${project.toki_id}:`, error);
    throw error;
  }
}

/**
 * Clean old snapshots (>180 days)
 * In production, these would be compressed and archived
 */
export async function cleanOldSnapshots(): Promise<number> {
  try {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - SNAPSHOT_RETENTION_DAYS);

    const result = await prisma.projectSnapshot.deleteMany({
      where: {
        snapshot_at: {
          lt: cutoffDate,
        },
      },
    });

    logger.info(`Cleaned ${result.count} old snapshots (older than ${SNAPSHOT_RETENTION_DAYS} days)`);
    return result.count;
  } catch (error) {
    logger.error('Failed to clean old snapshots:', error);
    throw error;
  }
}

/**
 * Get snapshot count for a project
 */
export async function getSnapshotCount(projectId: number): Promise<number> {
  return await prisma.projectSnapshot.count({
    where: { project_id: projectId },
  });
}

/**
 * Get recent snapshots for a project
 */
export async function getRecentSnapshots(projectId: number, limit: number = 10) {
  return await prisma.projectSnapshot.findMany({
    where: { project_id: projectId },
    orderBy: { snapshot_at: 'desc' },
    take: limit,
  });
}

