/**
 * Parsing Service Types
 */

export interface ParsedCompany {
  companies: string[];
  company_type: string | null;
  is_partnership: boolean;
  company_count: number;
  confidence: number;
}

export interface ParsingProgress {
  total_contractors: number;
  completed_count: number;
  pending_llm_count: number;
  rate_limited_count: number;
  failed_count: number;
  progress_pct: number;
  last_processed_id?: number | null;
  is_rate_limited?: boolean;
  retry_after_seconds?: number;
  current_batch_job_id?: string;
  current_batch_status?: string;
}

export interface RateLimitInfo {
  requests_used: number;
  tokens_used: number;
  requests_today: number;
  rpm_limit: number;
  tpm_limit: number;
  rpd_limit: number;
  rpm_reset_at: Date | null;
  tpm_reset_at: Date | null;
  rpd_reset_at: Date | null;
  is_rate_limited: boolean;
  retry_after_seconds?: number;
  last_error?: string;
}

export enum ParsingStatus {
  COMPLETED = 'COMPLETED',
  PENDING_LLM = 'PENDING_LLM',
  RATE_LIMITED = 'RATE_LIMITED',
  FAILED = 'FAILED'
}

export enum ParsingMethod {
  REGEX = 'regex',
  LLM = 'llm',
  MANUAL = 'manual'
}

export interface SuffixPattern {
  pattern: RegExp;
  suffix: string;
  company_type: string;
}

