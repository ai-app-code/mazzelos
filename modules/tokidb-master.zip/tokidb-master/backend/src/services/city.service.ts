/**
 * City Service
 * Handles city-related operations
 */

import prisma from '../config/database';
import logger from '../config/logger';

export async function getAllCities() {
  try {
    const cities = await prisma.city.findMany({
      orderBy: { plate_code: 'asc' },
    });
    return cities;
  } catch (error) {
    logger.error('Failed to fetch cities:', error);
    throw error;
  }
}

export async function getCityById(id: number) {
  try {
    const city = await prisma.city.findUnique({
      where: { id },
      include: {
        _count: {
          select: { projects: true },
        },
      },
    });
    return city;
  } catch (error) {
    logger.error(`Failed to fetch city ${id}:`, error);
    throw error;
  }
}

export async function getCityByPlateCode(plateCode: number) {
  try {
    const city = await prisma.city.findUnique({
      where: { plate_code: plateCode },
    });
    return city;
  } catch (error) {
    logger.error(`Failed to fetch city with plate code ${plateCode}:`, error);
    throw error;
  }
}

