/**
 * Contractor Parsing Service
 * Handles LLM-based parsing with cache checking
 * NO REGEX - All parsing done by LLM
 */

import { PrismaClient } from '@prisma/client';
import llmService from './llm.service';
import {
  ParsedCompany,
  ParsingProgress,
  ParsingStatus,
  ParsingMethod
} from './parsing.types';

const db = new PrismaClient();

export class ParsingService {
  /**
   * Parse contractor - Check cache first, then use LLM
   * OPTIMIZATION: Don't waste LLM tokens on already parsed contractors
   */
  async parseContractor(contractor: string, projectId: number): Promise<ParsedCompany> {
    if (!contractor || contractor.trim().length === 0) {
      return {
        companies: [],
        company_type: null,
        is_partnership: false,
        company_count: 0,
        confidence: 0
      };
    }

    // STEP 1: Check if already parsed in DB (CACHE)
    const cached = await db.parsedContractor.findUnique({
      where: { project_id: projectId }
    });

    if (cached && cached.original_contractor === contractor && cached.needs_parsing === false) {
      console.log(`✅ Cache hit for project ${projectId}: ${contractor}`);
      return {
        companies: cached.parsed_companies,
        company_type: cached.company_type,
        is_partnership: cached.is_partnership,
        company_count: cached.company_count,
        confidence: cached.confidence
      };
    }

    // STEP 2: Not in cache or needs re-parsing - Use LLM
    console.log(`🤖 LLM parsing for project ${projectId}: ${contractor}`);
    const parsed = await llmService.parseContractor(contractor);

    return {
      ...parsed,
      confidence: 95  // LLM parsing confidence
    };
  }

  /**
   * FirstRun: Parse ONLY contractors that need parsing (needs_parsing: true)
   * These are new or changed contractors from TOKİ
   */
  async firstRunParsing(): Promise<ParsingProgress> {
    let status = await db.parsingStatus.findFirst();

    if (!status) {
      status = await db.parsingStatus.create({
        data: {
          total_contractors: 0,
          completed_count: 0,
          pending_llm_count: 0,
          rate_limited_count: 0,
          failed_count: 0,
          progress_pct: 0
        }
      });
    }

    // Get ONLY contractors that need parsing (new or changed from TOKİ)
    const needsParsing = await db.parsedContractor.findMany({
      where: { needs_parsing: true },
      orderBy: { id: 'asc' },
      take: 10  // Smaller batch size for token optimization
    });

    const total = await db.parsedContractor.count({
      where: { needs_parsing: true }
    });

    for (const parsed_contractor of needsParsing) {
      try {
        console.log(`🤖 LLM parsing for project ${parsed_contractor.project_id}: ${parsed_contractor.original_contractor}`);

        const parsed = await llmService.parseContractor(parsed_contractor.original_contractor);

        await db.parsedContractor.update({
          where: { project_id: parsed_contractor.project_id },
          data: {
            parsed_companies: parsed.companies,
            company_type: parsed.company_type,
            is_partnership: parsed.is_partnership,
            company_count: parsed.company_count,
            parsing_method: ParsingMethod.LLM,
            confidence: parsed.confidence,
            parsing_status: ParsingStatus.COMPLETED,
            needs_parsing: false
          }
        });

        await db.project.update({
          where: { id: parsed_contractor.project_id },
          data: { is_partnership: parsed.is_partnership }
        });

        status = await db.parsingStatus.update({
          where: { id: status.id },
          data: {
            completed_count: { increment: 1 }
          }
        });
      } catch (error: any) {
        console.error(`❌ Error parsing contractor ${parsed_contractor.project_id}:`, error.message);
        await db.parsingStatus.update({
          where: { id: status.id },
          data: { failed_count: { increment: 1 } }
        });
      }
    }

    return this.getParsingProgress();
  }

  /**
   * Full parsing - Parse ALL contractors with LLM (backward + forward compatible)
   * Resets progress and re-parses everything
   */
  async fullParsing(): Promise<ParsingProgress> {
    await db.parsingStatus.deleteMany({});

    const totalCount = await db.project.count({
      where: { contractor: { not: null } }
    });

    const status = await db.parsingStatus.create({
      data: {
        total_contractors: totalCount,
        completed_count: 0,
        pending_llm_count: 0,
        rate_limited_count: 0,
        failed_count: 0,
        progress_pct: 0
      }
    });

    let processedCount = 0;
    let offset = 0;
    const batchSize = 10;  // Smaller batch size for token optimization

    while (processedCount < totalCount) {
      const contractors = await db.project.findMany({
        where: { contractor: { not: null } },
        orderBy: { id: 'asc' },
        skip: offset,
        take: batchSize
      });

      if (contractors.length === 0) break;

      for (const project of contractors) {
        try {
          const parsed = await this.parseContractor(project.contractor!, project.id);

          await db.parsedContractor.upsert({
            where: { project_id: project.id },
            create: {
              project_id: project.id,
              original_contractor: project.contractor!,
              parsed_companies: parsed.companies,
              company_type: parsed.company_type,
              is_partnership: parsed.is_partnership,
              company_count: parsed.company_count,
              parsing_method: ParsingMethod.LLM,
              confidence: parsed.confidence,
              parsing_status: ParsingStatus.COMPLETED,
              needs_parsing: false
            },
            update: {
              parsed_companies: parsed.companies,
              company_type: parsed.company_type,
              is_partnership: parsed.is_partnership,
              company_count: parsed.company_count,
              parsing_status: ParsingStatus.COMPLETED,
              confidence: parsed.confidence,
              needs_parsing: false
            }
          });

          await db.project.update({
            where: { id: project.id },
            data: { is_partnership: parsed.is_partnership }
          });

          await db.parsingStatus.update({
            where: { id: status.id },
            data: { completed_count: { increment: 1 } }
          });

          processedCount++;
        } catch (error: any) {
          console.error(`Error parsing contractor ${project.id}:`, error);
          await db.parsingStatus.update({
            where: { id: status.id },
            data: { failed_count: { increment: 1 } }
          });
          processedCount++;
        }
      }

      offset += batchSize;

      const progress_pct = totalCount > 0 ? (processedCount / totalCount) * 100 : 0;
      await db.parsingStatus.update({
        where: { id: status.id },
        data: { progress_pct }
      });
    }

    return this.getParsingProgress();
  }

  /**
   * Resume parsing from rate limit
   */
  async resumeParsing(): Promise<ParsingProgress> {
    const status = await db.parsingStatus.findFirst();

    if (!status) {
      return this.firstRunParsing();
    }

    // Check if rate limit is still active
    if (status.is_rate_limited && status.rate_limit_reset_at) {
      if (status.rate_limit_reset_at > new Date()) {
        console.log('Still rate limited, waiting...');
        return this.getParsingProgress();
      }
    }

    // Clear rate limit flag and resume
    await db.parsingStatus.update({
      where: { id: status.id },
      data: {
        is_rate_limited: false,
        retry_after_seconds: null,
        rate_limit_reset_at: null
      }
    });

    return this.firstRunParsing();
  }

  /**
   * Get current parsing progress
   */
  async getParsingProgress(): Promise<ParsingProgress> {
    const status = await db.parsingStatus.findFirst();

    if (!status) {
      return {
        total_contractors: 0,
        completed_count: 0,
        pending_llm_count: 0,
        rate_limited_count: 0,
        failed_count: 0,
        progress_pct: 0
      };
    }

    return {
      total_contractors: status.total_contractors,
      completed_count: status.completed_count,
      pending_llm_count: status.pending_llm_count,
      rate_limited_count: status.rate_limited_count,
      failed_count: status.failed_count,
      progress_pct: status.progress_pct
    };
  }
}

export default new ParsingService();

