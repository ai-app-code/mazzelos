import request from 'supertest';
import express from 'express';
import citiesRoutes from '../routes/cities.routes';
import projectsRoutes from '../routes/projects.routes';
import authRoutes from '../routes/auth.routes';

const app = express();
app.use(express.json());
app.use('/api/cities', citiesRoutes);
app.use('/api/projects', projectsRoutes);
app.use('/api/auth', authRoutes);

describe('API Integration Tests', () => {
  describe('GET /api/cities', () => {
    it('should return list of cities', async () => {
      const response = await request(app)
        .get('/api/cities')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(Array.isArray(response.body.data)).toBe(true);
    });
  });

  describe('GET /api/projects', () => {
    it('should return paginated projects', async () => {
      const response = await request(app)
        .get('/api/projects?page=1&limit=10')
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.meta).toBeDefined();
      expect(response.body.meta.page).toBe(1);
      expect(response.body.meta.limit).toBe(10);
    });

    it('should filter by city_id', async () => {
      const response = await request(app)
        .get('/api/projects?city_id=1')
        .expect(200);

      expect(response.body.success).toBe(true);
    });

    it('should filter by status', async () => {
      const response = await request(app)
        .get('/api/projects?status=ACTIVE')
        .expect(200);

      expect(response.body.success).toBe(true);
    });
  });

  describe('POST /api/auth/login', () => {
    it('should login with valid credentials', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'admin@tokidb.local',
          password: 'admin123',
        })
        .expect(200);

      expect(response.body.success).toBe(true);
      expect(response.body.data.token).toBeDefined();
    });

    it('should reject invalid credentials', async () => {
      const response = await request(app)
        .post('/api/auth/login')
        .send({
          email: 'wrong@email.com',
          password: 'wrongpass',
        })
        .expect(401);

      expect(response.body.success).toBe(false);
    });
  });
});

