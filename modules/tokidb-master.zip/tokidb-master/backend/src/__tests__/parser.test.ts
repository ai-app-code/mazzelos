import { parseSeviye, parseUnitCount } from '../parser/seviye-parser';

describe('Parser Utilities', () => {
  describe('parseSeviye', () => {
    it('should parse percentage values', () => {
      expect(parseSeviye('75%')).toBe(75);
      expect(parseSeviye('100%')).toBe(100);
      expect(parseSeviye('0%')).toBe(0);
      expect(parseSeviye('45.5%')).toBe(45.5);
    });

    it('should detect completed status', () => {
      expect(parseSeviye('Tamamlandı')).toBe(100);
      expect(parseSeviye('tamamlandi')).toBe(100);
      expect(parseSeviye('Bitmiş')).toBe(100);
      expect(parseSeviye('completed')).toBe(100);
    });

    it('should return null for invalid input', () => {
      expect(parseSeviye('')).toBeNull();
      expect(parseSeviye(null)).toBeNull();
      expect(parseSeviye(undefined)).toBeNull();
      expect(parseSeviye('invalid')).toBeNull();
    });

    it('should handle edge cases', () => {
      expect(parseSeviye('150%')).toBeNull(); // Out of range
      expect(parseSeviye('-10%')).toBeNull(); // Negative
      expect(parseSeviye('Seviye: 80%')).toBe(80);
    });
  });

  describe('parseUnitCount', () => {
    it('should parse unit counts', () => {
      expect(parseUnitCount('500')).toBe(500);
      expect(parseUnitCount('1.234')).toBe(1234);
      expect(parseUnitCount('2,500')).toBe(2500);
    });

    it('should extract numbers from text', () => {
      expect(parseUnitCount('500 konut')).toBe(500);
      expect(parseUnitCount('Toplam 1234 adet')).toBe(1234);
    });

    it('should return null for invalid input', () => {
      expect(parseUnitCount('')).toBeNull();
      expect(parseUnitCount(null)).toBeNull();
      expect(parseUnitCount('invalid')).toBeNull();
    });
  });
});

