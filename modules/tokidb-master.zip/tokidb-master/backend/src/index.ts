/**
 * TOKİDB Backend - Express App
 */

import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import * as Sentry from '@sentry/node';
import logger from './config/logger';
import { errorHandler } from './middleware/errorHandler';
import { generalLimiter } from './middleware/rateLimiter';
import { scheduleDailySync } from './jobs/sync.job';
import prisma from './config/database';

// Import routes
import citiesRoutes from './routes/cities.routes';
import projectsRoutes from './routes/projects.routes';
import exportRoutes from './routes/export.routes';
import syncRoutes from './routes/sync.routes';
import authRoutes from './routes/auth.routes';
import logsRoutes from './routes/logs.routes';
import dashboardRoutes from './routes/dashboard.routes';
import companiesRoutes from './routes/companies.routes';
import partnershipsRoutes from './routes/partnerships.routes';
import parsingRoutes from './routes/parsing.routes';

const app = express();
const PORT = process.env.PORT || 3001;
const NODE_ENV = process.env.NODE_ENV || 'development';

// Initialize Sentry
if (process.env.SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: NODE_ENV,
    tracesSampleRate: NODE_ENV === 'production' ? 0.1 : 1.0,
  });
  app.use(Sentry.Handlers.requestHandler());
  app.use(Sentry.Handlers.tracingHandler());
}

// Middleware
app.use(helmet());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(generalLimiter);

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    environment: NODE_ENV,
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/cities', citiesRoutes);
app.use('/api/projects', projectsRoutes);
app.use('/api/companies', companiesRoutes);
app.use('/api/partnerships', partnershipsRoutes);
app.use('/api/parsing', parsingRoutes);
app.use('/api/export', exportRoutes);
app.use('/api/sync', syncRoutes);
app.use('/api/logs', logsRoutes);
app.use('/api/dashboard', dashboardRoutes);

// Sentry error handler (must be before other error handlers)
if (process.env.SENTRY_DSN) {
  app.use(Sentry.Handlers.errorHandler());
}

// Error handler (must be last)
app.use(errorHandler);

// Start server
async function startServer() {
  try {
    // Clean up stuck RUNNING syncs on startup (10 minutes threshold)
    const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000);
    const stuckSyncs = await prisma.syncHistory.updateMany({
      where: {
        status: 'RUNNING',
        started_at: {
          lt: tenMinutesAgo,
        },
      },
      data: {
        status: 'FAILED',
        error_message: 'Sync timed out - marked as failed on server startup',
        completed_at: new Date(),
      },
    });

    if (stuckSyncs.count > 0) {
      logger.warn(`⚠️ Cleaned up ${stuckSyncs.count} stuck RUNNING syncs on startup`);
    }

    // Schedule daily sync job
    await scheduleDailySync();
    logger.info('Daily sync job scheduled');

    app.listen(PORT, () => {
      logger.info(`🚀 TOKİDB Backend running on port ${PORT}`);
      logger.info(`Environment: ${NODE_ENV}`);
      logger.info(`Health check: http://localhost:${PORT}/health`);
    });
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('SIGTERM received, shutting down gracefully...');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('SIGINT received, shutting down gracefully...');
  process.exit(0);
});

// Start
startServer();

