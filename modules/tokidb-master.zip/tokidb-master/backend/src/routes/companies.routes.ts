import { Router, type Router as ExpressRouter } from 'express';
import prisma from '../config/database';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// GET /api/companies - Get all companies (contractors) with project counts
router.get('/', async (req, res, next) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const skip = (page - 1) * limit;

    // Get parsed companies
    const parsedCompanies = await prisma.parsedContractor.findMany({
      select: { parsed_companies: true },
      where: {
        parsing_status: 'COMPLETED',
        needs_parsing: false,  // Only count parsed companies
      },
    });

    // Extract unique companies from parsed data
    const companyMap = new Map<string, {
      name: string;
      totalProjects: number;
      completedProjects: number;
      ongoingProjects: number;
      avgSeviye: number;
    }>();

    // Process parsed companies
    for (const pc of parsedCompanies) {
      for (const company of pc.parsed_companies) {
        if (!company || company.trim().length === 0) continue;

        const companyName = company.trim();
        if (!companyMap.has(companyName)) {
          companyMap.set(companyName, {
            name: companyName,
            totalProjects: 0,
            completedProjects: 0,
            ongoingProjects: 0,
            avgSeviye: 0,
          });
        }
      }
    }

    // Get all projects and count by company
    const projects = await prisma.project.findMany({
      select: { contractor: true, status: true, seviye_pct: true },
      where: { contractor: { not: null } },
    });

    // Fallback: For unparsed contractors, add them to companyMap
    const unparsedContractors = await prisma.project.findMany({
      select: { contractor: true },
      where: {
        contractor: { not: null },
        parsed_contractor: { is: null }, // No parsed record
      },
      distinct: ['contractor'],
    });

    for (const uc of unparsedContractors) {
      if (!uc.contractor) continue;
      const contractors = uc.contractor
        .split(/\s*[-/,]\s*|\s+ve\s+/)
        .map(c => c.trim())
        .filter(c => c.length > 0);

      contractors.forEach(contractor => {
        if (!companyMap.has(contractor)) {
          companyMap.set(contractor, {
            name: contractor,
            totalProjects: 0,
            completedProjects: 0,
            ongoingProjects: 0,
            avgSeviye: 0,
          });
        }
      });
    }

    projects.forEach(project => {
      if (!project.contractor) return;

      // Split contractors if partnership
      const contractors = project.contractor
        .split(/\s*[-/,]\s*|\s+ve\s+/)
        .map(c => c.trim())
        .filter(c => c.length > 0);

      contractors.forEach(contractor => {
        if (!companyMap.has(contractor)) {
          companyMap.set(contractor, {
            name: contractor,
            totalProjects: 0,
            completedProjects: 0,
            ongoingProjects: 0,
            avgSeviye: 0,
          });
        }

        const company = companyMap.get(contractor)!;
        company.totalProjects++;
        
        if (project.status === 'Tamamlandı') {
          company.completedProjects++;
        } else if (project.status === 'İnşaat Halinde') {
          company.ongoingProjects++;
        }

        // Calculate average seviye
        if (project.seviye_pct) {
          company.avgSeviye = (company.avgSeviye * (company.totalProjects - 1) + project.seviye_pct) / company.totalProjects;
        }
      });
    });

    // Convert to array and sort by total projects
    const sortedCompanies = Array.from(companyMap.values())
      .sort((a, b) => b.totalProjects - a.totalProjects);

    const totalCompanies = sortedCompanies.length;
    const companies = sortedCompanies.slice(skip, skip + limit);

    res.json({
      success: true,
      data: {
        companies,
        totalCompanies,
        page,
        limit,
        totalPages: Math.ceil(totalCompanies / limit),
        topCompanies: sortedCompanies.slice(0, 10),
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/companies/:name - Get company details and their projects
router.get('/:name', async (req, res, next) => {
  try {
    const companyName = decodeURIComponent(req.params.name);

    // Find all projects for this company
    const projects = await prisma.project.findMany({
      where: {
        contractor: {
          contains: companyName,
          mode: 'insensitive',
        },
      },
      include: {
        city: true,
        project_type: true,
      },
      orderBy: { seviye_pct: 'desc' },
    });

    if (projects.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Company not found',
      });
    }

    // Calculate stats
    const stats = {
      name: companyName,
      totalProjects: projects.length,
      completedProjects: projects.filter(p => p.status === 'Tamamlandı').length,
      ongoingProjects: projects.filter(p => p.status === 'İnşaat Halinde').length,
      avgSeviye: projects.reduce((sum, p) => sum + (p.seviye_pct || 0), 0) / projects.length,
      totalUnits: projects.reduce((sum, p) => sum + (p.unit_count || 0), 0),
    };

    res.json({
      success: true,
      data: {
        stats,
        projects: projects.map(p => ({
          id: p.id,
          name: p.name,
          city: p.city.name,
          type: p.project_type.name,
          status: p.status,
          seviye: p.seviye_pct,
          unitCount: p.unit_count,
        })),
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;

