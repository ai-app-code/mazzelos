import { Router, type Router as ExpressRouter } from 'express';
import { exportToCSV } from '../services/export/csv.service';
import { exportToJSON } from '../services/export/json.service';
import { ProjectFilterSchema, ExportFormatSchema } from '@tokidb/shared';
import { authMiddleware } from '../middleware/auth';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// POST /api/export - Export projects (requires auth)
router.post('/', authMiddleware, async (req, res, next) => {
  try {
    const { format, filters, include_snapshots, include_changes } = req.body;

    // Validate format
    const validatedFormat = ExportFormatSchema.parse(format);

    // Validate filters (optional)
    const validatedFilters = filters ? ProjectFilterSchema.parse(filters) : undefined;

    let data: string;
    let contentType: string;
    let filename: string;

    if (validatedFormat === 'csv') {
      data = await exportToCSV(validatedFilters);
      contentType = 'text/csv; charset=utf-8';
      filename = `tokidb-projects-${new Date().toISOString().split('T')[0]}.csv`;
    } else {
      data = await exportToJSON(validatedFilters, include_snapshots, include_changes);
      contentType = 'application/json';
      filename = `tokidb-projects-${new Date().toISOString().split('T')[0]}.json`;
    }

    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(data);
  } catch (error) {
    next(error);
  }
});

export default router;

