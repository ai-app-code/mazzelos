import { Router, type Router as ExpressRouter } from 'express';
import { authMiddleware } from '../middleware/auth';
import fs from 'fs';
import path from 'path';

const router: ExpressRouter = Router();

// Get logs stream (for real-time display)
router.get('/stream', async (req, res) => {
  try {
    const lines = parseInt(req.query.lines as string) || 100;
    const logFile = path.join(process.cwd(), 'logs/combined.log');

    if (!fs.existsSync(logFile)) {
      return res.json({
        success: true,
        data: [],
      });
    }

    const logContent = fs.readFileSync(logFile, 'utf-8');
    const logLines = logContent.split('\n').filter(line => line.trim());
    const recentLogs = logLines.slice(-lines);

    const parsedLogs = recentLogs.map((line, index) => {
      try {
        const parsed = JSON.parse(line);
        return {
          id: index,
          timestamp: parsed.timestamp,
          level: parsed.level,
          message: parsed.message,
          service: parsed.service,
        };
      } catch {
        return {
          id: index,
          timestamp: new Date().toISOString(),
          level: 'info',
          message: line,
          service: 'tokidb-backend',
        };
      }
    });

    res.json({
      success: true,
      data: parsedLogs,
    });
  } catch (error) {
    console.error('Failed to read logs:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to read logs',
    });
  }
});

// Get all logs
router.get('/', authMiddleware, async (req, res) => {
  try {
    const logFile = path.join(process.cwd(), 'logs/combined.log');

    if (!fs.existsSync(logFile)) {
      return res.json({
        success: true,
        data: [],
      });
    }

    const logContent = fs.readFileSync(logFile, 'utf-8');
    const lines = logContent.split('\n').filter(line => line.trim());
    const recentLogs = lines.slice(-100).reverse();

    const parsedLogs = recentLogs.map(line => {
      try {
        return JSON.parse(line);
      } catch {
        return {
          level: 'info',
          message: line,
          timestamp: new Date().toISOString(),
        };
      }
    });

    res.json({
      success: true,
      data: parsedLogs,
    });
  } catch (error) {
    console.error('Failed to read logs:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to read logs',
    });
  }
});

// Get error logs only
router.get('/errors', authMiddleware, async (req, res) => {
  try {
    const logFile = path.join(process.cwd(), 'logs/error.log');
    
    if (!fs.existsSync(logFile)) {
      return res.json({
        success: true,
        data: [],
      });
    }

    const logContent = fs.readFileSync(logFile, 'utf-8');
    const lines = logContent.split('\n').filter(line => line.trim());
    const recentLogs = lines.slice(-50).reverse();

    const parsedLogs = recentLogs.map(line => {
      try {
        return JSON.parse(line);
      } catch {
        return {
          level: 'error',
          message: line,
          timestamp: new Date().toISOString(),
        };
      }
    });

    res.json({
      success: true,
      data: parsedLogs,
    });
  } catch (error) {
    console.error('Failed to read error logs:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to read error logs',
    });
  }
});

export default router;

