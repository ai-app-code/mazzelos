import { Router, type Router as ExpressRouter } from 'express';
import { getAllCities, getCityById } from '../services/city.service';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// GET /api/cities - Get all cities
router.get('/', async (req, res, next) => {
  try {
    const cities = await getAllCities();
    res.json({
      success: true,
      data: cities,
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/cities/:id - Get city by ID
router.get('/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    const city = await getCityById(id);

    if (!city) {
      return res.status(404).json({
        success: false,
        error: 'City not found',
      });
    }

    res.json({
      success: true,
      data: city,
    });
  } catch (error) {
    next(error);
  }
});

export default router;

