import { Router, type Router as ExpressRouter } from 'express';
import prisma from '../config/database';
import { ProjectListQuerySchema } from '@tokidb/shared';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// GET /api/projects - List projects with filters and pagination
router.get('/', async (req, res, next) => {
  try {
    const query = ProjectListQuerySchema.parse(req.query);

    // Build where clause
    const where: any = {};
    if (query.city_id) where.city_id = query.city_id;
    if (query.project_type_id) where.project_type_id = query.project_type_id;
    if (query.status) where.status = query.status;
    if (query.min_seviye !== undefined || query.max_seviye !== undefined) {
      where.seviye_pct = {};
      if (query.min_seviye !== undefined) where.seviye_pct.gte = query.min_seviye;
      if (query.max_seviye !== undefined) where.seviye_pct.lte = query.max_seviye;
    }
    if (query.search) {
      where.name = {
        contains: query.search,
        mode: 'insensitive',
      };
    }

    // Get total count
    const total = await prisma.project.count({ where });

    // Get paginated results
    const projects = await prisma.project.findMany({
      where,
      include: {
        city: true,
        project_type: true,
      },
      orderBy: { updated_at: 'desc' },
      skip: (query.page - 1) * query.limit,
      take: query.limit,
    });

    res.json({
      success: true,
      data: projects,
      meta: {
        page: query.page,
        limit: query.limit,
        total,
        total_pages: Math.ceil(total / query.limit),
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/projects/:tokiId - Get project by TOKİ ID
router.get('/:tokiId', async (req, res, next) => {
  try {
    const project = await prisma.project.findUnique({
      where: { toki_id: req.params.tokiId },
      include: {
        city: true,
        project_type: true,
        snapshots: {
          orderBy: { snapshot_at: 'desc' },
          take: 10,
        },
        changes: {
          orderBy: { detected_at: 'desc' },
          take: 20,
        },
      },
    });

    if (!project) {
      return res.status(404).json({
        success: false,
        error: 'Project not found',
      });
    }

    res.json({
      success: true,
      data: project,
    });
  } catch (error) {
    next(error);
  }
});

export default router;

