/**
 * Parsing Routes
 * Endpoints for contractor parsing, progress tracking, and resume capability
 */

import { Router, type Router as ExpressRouter, Request, Response } from 'express';
import parsingService from '../services/parsing.service';
import llmService from '../services/llm.service';

const router: ExpressRouter = Router();

/**
 * GET /api/parsing/health
 * Check LLM service health
 */
router.get('/health', async (req: Request, res: Response) => {
  try {
    const health = await llmService.healthCheck();
    const status = llmService.getStatus();
    res.json({
      success: true,
      data: {
        ...health,
        ...status
      }
    });
  } catch (error: any) {
    console.error('Error checking LLM health:', error);
    res.status(500).json({
      success: false,
      error: 'Failed to check LLM health',
      message: error.message
    });
  }
});

/**
 * GET /api/parsing/progress
 * Get current parsing progress
 */
router.get('/progress', async (req: Request, res: Response) => {
  try {
    const progress = await parsingService.getParsingProgress();
    res.json(progress);
  } catch (error: any) {
    console.error('Error getting parsing progress:', error);
    res.status(500).json({
      error: 'Failed to get parsing progress',
      message: error.message
    });
  }
});

/**
 * POST /api/parsing/first-run
 * Start FirstRun parsing job
 */
router.post('/first-run', async (req: Request, res: Response) => {
  try {
    console.log('Starting FirstRun parsing job...');
    
    // Run parsing in background
    parsingService.firstRunParsing()
      .then(progress => {
        console.log('FirstRun completed:', progress);
      })
      .catch(error => {
        console.error('FirstRun error:', error);
      });

    // Return immediately
    const progress = await parsingService.getParsingProgress();
    res.json({
      status: 'started',
      message: 'FirstRun parsing job started',
      progress
    });
  } catch (error: any) {
    console.error('Error starting FirstRun:', error);
    res.status(500).json({
      error: 'Failed to start FirstRun',
      message: error.message
    });
  }
});

/**
 * POST /api/parsing/full-run
 * Full parsing - Parse ALL contractors (backward + forward compatible)
 * Resets progress and re-parses everything, overriding old data
 */
router.post('/full-run', async (req: Request, res: Response) => {
  try {
    console.log('Starting Full parsing job (all contractors)...');

    // Run parsing in background
    parsingService.fullParsing()
      .then(progress => {
        console.log('Full parsing completed:', progress);
      })
      .catch(error => {
        console.error('Full parsing error:', error);
      });

    // Return immediately
    const progress = await parsingService.getParsingProgress();
    res.json({
      status: 'started',
      message: 'Full parsing job started (all contractors will be re-parsed)',
      progress
    });
  } catch (error: any) {
    console.error('Error starting full parsing:', error);
    res.status(500).json({
      error: 'Failed to start full parsing',
      message: error.message
    });
  }
});

/**
 * POST /api/parsing/resume
 * Resume parsing from rate limit
 */
router.post('/resume', async (req: Request, res: Response) => {
  try {
    console.log('Resuming parsing job...');

    // Run parsing in background
    parsingService.resumeParsing()
      .then(progress => {
        console.log('Resume completed:', progress);
      })
      .catch(error => {
        console.error('Resume error:', error);
      });

    // Return immediately
    const progress = await parsingService.getParsingProgress();
    res.json({
      status: 'resumed',
      message: 'Parsing job resumed',
      progress
    });
  } catch (error: any) {
    console.error('Error resuming parsing:', error);
    res.status(500).json({
      error: 'Failed to resume parsing',
      message: error.message
    });
  }
});

export default router;

