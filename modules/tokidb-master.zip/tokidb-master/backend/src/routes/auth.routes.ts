import { Router, type Router as ExpressRouter } from 'express';
import bcrypt from 'bcrypt';
import { LoginSchema, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD } from '@tokidb/shared';
import { generateToken } from '../middleware/auth';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// POST /api/auth/login - Login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = LoginSchema.parse(req.body);

    // Simple admin check (in production, use database)
    const adminEmail = process.env.ADMIN_EMAIL || DEFAULT_ADMIN_EMAIL;
    const adminPassword = process.env.ADMIN_PASSWORD || DEFAULT_ADMIN_PASSWORD;

    if (email !== adminEmail || password !== adminPassword) {
      return res.status(401).json({
        success: false,
        error: 'Invalid credentials',
      });
    }

    const token = generateToken(email);

    logger.info(`Admin logged in: ${email}`);

    res.json({
      success: true,
      data: {
        token,
        user: { email },
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;

