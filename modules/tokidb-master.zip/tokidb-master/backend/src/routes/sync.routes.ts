import { Router, type Router as ExpressRouter } from 'express';
import { runIngest } from '../services/ingest/ingest.service';
import prisma from '../config/database';
import { authMiddleware } from '../middleware/auth';
import { adminSyncLimiter } from '../middleware/rateLimiter';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// POST /api/sync - Trigger manual sync (requires auth + rate limit)
router.post('/', authMiddleware, adminSyncLimiter, async (req, res, next) => {
  try {
    logger.info('Manual sync triggered by admin');

    // Check if sync is already running
    const runningSync = await prisma.syncHistory.findFirst({
      where: { status: 'RUNNING' },
    });

    if (runningSync) {
      // Check if it's actually stuck (older than 10 minutes)
      const tenMinutesAgo = new Date(Date.now() - 10 * 60 * 1000);

      if (runningSync.started_at < tenMinutesAgo) {
        // Auto-cleanup stuck sync
        logger.warn(`Auto-cleaning stuck sync ${runningSync.id} (started at ${runningSync.started_at})`);
        await prisma.syncHistory.update({
          where: { id: runningSync.id },
          data: {
            status: 'FAILED',
            error_message: 'Auto-marked as failed - sync was stuck for 10+ minutes',
            completed_at: new Date(),
          },
        });
      } else {
        // Sync is actually running
        return res.status(409).json({
          success: false,
          error: 'Senkronizasyon zaten çalışıyor! Lütfen tamamlanmasını bekleyin.',
          running_sync_id: runningSync.id,
        });
      }
    }

    // Create sync history record
    const syncHistory = await prisma.syncHistory.create({
      data: {
        started_at: new Date(),
        status: 'RUNNING',
        parser_version: 'unknown',
      },
    });

    // Run ingest (async)
    runIngest()
      .then(async (result) => {
        await prisma.syncHistory.update({
          where: { id: syncHistory.id },
          data: {
            completed_at: new Date(),
            status: result.success ? 'SUCCESS' : 'FAILED',
            parser_version: result.parser_version,
            projects_fetched: result.projects_fetched,
            projects_created: result.projects_created,
            projects_updated: result.projects_updated,
            projects_deleted: result.projects_deleted,
            error_message: result.error || null,
          },
        });
      })
      .catch(async (error) => {
        logger.error('Sync failed:', error);
        await prisma.syncHistory.update({
          where: { id: syncHistory.id },
          data: {
            completed_at: new Date(),
            status: 'FAILED',
            error_message: error.message,
          },
        });
      });

    res.json({
      success: true,
      data: {
        sync_id: syncHistory.id,
        message: 'Sync started in background',
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/sync/history - Get sync history
router.get('/history', async (req, res, next) => {
  try {
    const history = await prisma.syncHistory.findMany({
      orderBy: { started_at: 'desc' },
      take: 20,
    });

    res.json({
      success: true,
      data: history,
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/sync/cancel - Cancel running sync
router.post('/cancel', authMiddleware, async (req, res, next) => {
  try {
    logger.info('Cancelling running sync...');

    // Find running sync
    const runningSync = await prisma.syncHistory.findFirst({
      where: { status: 'RUNNING' },
    });

    if (!runningSync) {
      return res.status(404).json({
        success: false,
        error: 'No running sync found',
      });
    }

    // Mark as FAILED
    await prisma.syncHistory.update({
      where: { id: runningSync.id },
      data: {
        status: 'FAILED',
        error_message: 'Sync cancelled by user',
        completed_at: new Date(),
      },
    });

    logger.info(`Cancelled sync ${runningSync.id}`);

    res.json({
      success: true,
      data: {
        message: 'Sync cancelled successfully',
      },
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/sync/cleanup-stuck - Mark stuck RUNNING syncs as FAILED
router.post('/cleanup-stuck', authMiddleware, async (req, res, next) => {
  try {
    logger.info('Cleaning up stuck RUNNING syncs...');

    // Find syncs that have been RUNNING for more than 1 minute
    const oneMinuteAgo = new Date(Date.now() - 1 * 60 * 1000);

    const stuckSyncs = await prisma.syncHistory.updateMany({
      where: {
        status: 'RUNNING',
        started_at: {
          lt: oneMinuteAgo,
        },
      },
      data: {
        status: 'FAILED',
        error_message: 'Sync timed out - marked as failed by cleanup',
        completed_at: new Date(),
      },
    });

    logger.info(`Cleaned up ${stuckSyncs.count} stuck syncs`);

    res.json({
      success: true,
      data: {
        cleaned: stuckSyncs.count,
        message: `${stuckSyncs.count} stuck sync(s) marked as FAILED`,
      },
    });
  } catch (error) {
    next(error);
  }
});

// POST /api/sync/delete-failed - Delete FAILED syncs
router.post('/delete-failed', authMiddleware, async (req, res, next) => {
  try {
    logger.info('Deleting FAILED syncs...');

    const deletedSyncs = await prisma.syncHistory.deleteMany({
      where: {
        status: 'FAILED',
      },
    });

    logger.info(`Deleted ${deletedSyncs.count} FAILED syncs`);

    res.json({
      success: true,
      data: {
        deleted: deletedSyncs.count,
        message: `${deletedSyncs.count} FAILED sync(s) deleted`,
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/sync/status/:id - Get sync status
router.get('/status/:id', async (req, res, next) => {
  try {
    const id = parseInt(req.params.id);
    const sync = await prisma.syncHistory.findUnique({
      where: { id },
    });

    if (!sync) {
      return res.status(404).json({
        success: false,
        error: 'Sync not found',
      });
    }

    res.json({
      success: true,
      data: sync,
    });
  } catch (error) {
    next(error);
  }
});

export default router;

