import { Router, type Router as ExpressRouter } from 'express';
import prisma from '../config/database';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// GET /api/dashboard/stats - Get dashboard statistics
router.get('/stats', async (req, res, next) => {
  try {
    // Total projects
    const totalProjects = await prisma.project.count();

    // Total cities
    const totalCities = await prisma.city.count();

    // Get parsed contractors stats
    const parsedStats = await prisma.parsedContractor.aggregate({
      _count: true,
    });

    // Count partnerships: is_partnership=true AND company_count >= 2
    const parsedPartnerships = await prisma.parsedContractor.count({
      where: {
        is_partnership: true,
        company_count: { gte: 2 },  // Must have 2+ companies
        needs_parsing: false,  // Only count parsed partnerships
      },
    });

    // Get all unique parsed companies
    const parsedCompanies = await prisma.parsedContractor.findMany({
      select: { parsed_companies: true },
      where: { parsing_status: 'COMPLETED' },
    });

    const uniqueCompanies = new Set<string>();
    parsedCompanies.forEach(pc => {
      pc.parsed_companies.forEach(company => {
        if (company && company.trim().length > 0) {
          uniqueCompanies.add(company.trim());
        }
      });
    });

    // Fallback: For unparsed contractors, use old parsing logic
    const unparsedContractors = await prisma.project.findMany({
      select: { contractor: true },
      where: {
        contractor: { not: null },
        parsed_contractor: { is: null }, // No parsed record
      },
      distinct: ['contractor'],
    });

    // Parse unparsed contractors and add to set
    unparsedContractors.forEach(uc => {
      if (!uc.contractor) return;
      const contractors = uc.contractor
        .split(/\s*[-/,]\s*|\s+ve\s+/)
        .map(c => c.trim())
        .filter(c => c.length > 0);
      contractors.forEach(c => uniqueCompanies.add(c));
    });

    // Total contractors = parsed + unparsed
    const totalContractors = uniqueCompanies.size;

    // Count unparsed partnerships
    let unparsedPartnerships = 0;
    unparsedContractors.forEach(uc => {
      if (!uc.contractor) return;
      const hasPartnership =
        uc.contractor.includes(' - ') ||
        uc.contractor.includes(' / ') ||
        uc.contractor.includes(' ve ') ||
        uc.contractor.includes(', ');
      if (hasPartnership) unparsedPartnerships++;
    });

    const totalPartnerships = parsedPartnerships + unparsedPartnerships;

    // Projects by status
    const projectsByStatus = await prisma.project.groupBy({
      by: ['status'],
      _count: true,
    });

    // Projects by type
    const projectsByType = await prisma.project.groupBy({
      by: ['project_type_id'],
      _count: true,
    });

    // Get type names
    const types = await prisma.projectType.findMany();
    const typeMap = new Map(types.map(t => [t.id, t.name]));

    const projectsByTypeWithNames = projectsByType.map(pt => ({
      type: typeMap.get(pt.project_type_id) || 'Unknown',
      count: pt._count,
    }));

    // Average seviye
    const avgSeviye = await prisma.project.aggregate({
      _avg: { seviye_pct: true },
    });

    // Mosque projects count
    const mosqueCount = await prisma.project.count({
      where: {
        name: {
          contains: 'cami',
          mode: 'insensitive',
        },
      },
    });

    // Last sync
    const lastSync = await prisma.syncHistory.findFirst({
      where: { status: 'SUCCESS' },
      orderBy: { completed_at: 'desc' },
    });

    res.json({
      success: true,
      data: {
        totalProjects,
        totalCities,
        totalContractors,
        partnershipCount: totalPartnerships,
        mosqueCount,
        projectsByStatus: projectsByStatus.map(ps => ({
          status: ps.status,
          count: ps._count,
        })),
        projectsByType: projectsByTypeWithNames,
        averageSeviye: avgSeviye._avg.seviye_pct || 0,
        lastSync: lastSync ? {
          date: lastSync.completed_at,
          projectsFetched: lastSync.projects_fetched,
          projectsCreated: lastSync.projects_created,
          projectsUpdated: lastSync.projects_updated,
        } : null,
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/dashboard/mosques - Get mosque projects
router.get('/mosques', async (req, res, next) => {
  try {
    // Get minSeviye and maxSeviye from query params
    const minSeviye = req.query.minSeviye ? parseInt(req.query.minSeviye as string, 10) : 0;
    const maxSeviye = req.query.maxSeviye ? parseInt(req.query.maxSeviye as string, 10) : 100;

    const mosqueProjects = await prisma.project.findMany({
      where: {
        name: {
          contains: 'cami',
          mode: 'insensitive',
        },
        seviye_pct: {
          gte: minSeviye,
          lte: maxSeviye,
        },
      },
      include: {
        city: true,
        project_type: true,
      },
      orderBy: {
        seviye_pct: 'desc',
      },
    });

    // Deduplicate by name + city + project_type
    const uniqueProjects = Array.from(
      new Map(
        mosqueProjects.map(p => [
          `${p.name}|${p.city_id}|${p.project_type_id}`,
          p
        ])
      ).values()
    );

    const mosqueCount = uniqueProjects.length;

    res.json({
      success: true,
      data: {
        mosqueCount,
        minSeviye,
        maxSeviye,
        projects: uniqueProjects.map(p => ({
          id: p.id,
          name: p.name,
          city: p.city.name,
          type: p.project_type.name,
          status: p.status,
          seviye: p.seviye_pct,
          contractor: p.contractor,
          unitCount: p.unit_count,
        })),
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Parse contractors to detect partnerships
 * Handles formats like:
 * - "Firma A - Firma B"
 * - "Firma A / Firma B"
 * - "Firma A ve Firma B"
 * - "Firma A, Firma B"
 */
function parseContractors(contractors: string[]): {
  uniqueContractors: number;
  partnerships: number;
} {
  const uniqueSet = new Set<string>();
  let partnerships = 0;

  contractors.forEach(contractor => {
    if (!contractor) return;

    // Check for partnership indicators
    const hasPartnership =
      contractor.includes(' - ') ||
      contractor.includes(' / ') ||
      contractor.includes(' ve ') ||
      contractor.includes(', ');

    if (hasPartnership) {
      partnerships++;
      // Split and add each contractor
      const parts = contractor
        .split(/\s*[-/,]\s*|\s+ve\s+/)
        .map(p => p.trim())
        .filter(p => p.length > 0);

      parts.forEach(part => uniqueSet.add(part));
    } else {
      uniqueSet.add(contractor);
    }
  });

  return {
    uniqueContractors: uniqueSet.size,
    partnerships,
  };
}

export default router;

