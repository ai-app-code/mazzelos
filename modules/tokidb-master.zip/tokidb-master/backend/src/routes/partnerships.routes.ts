import { Router, type Router as ExpressRouter } from 'express';
import prisma from '../config/database';
import logger from '../config/logger';

const router: ExpressRouter = Router();

// Helper function to parse partnerships
function parsePartnership(contractor: string): string[] {
  return contractor
    .split(/\s*[-/,]\s*|\s+ve\s+/)
    .map(c => c.trim())
    .filter(c => c.length > 0);
}

// GET /api/partnerships - Get all partnerships
router.get('/', async (req, res, next) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const skip = (page - 1) * limit;

    // Get parsed partnerships (must have 2+ companies)
    const parsedPartnerships = await prisma.parsedContractor.findMany({
      select: { parsed_companies: true },
      where: {
        is_partnership: true,
        company_count: { gte: 2 },  // Must have 2+ companies
        parsing_status: 'COMPLETED',
        needs_parsing: false,  // Only count parsed partnerships
      },
    });

    // Find partnerships (contractors with multiple companies)
    const partnershipMap = new Map<string, {
      partners: string[];
      totalProjects: number;
      completedProjects: number;
      ongoingProjects: number;
      avgSeviye: number;
    }>();

    // Process parsed partnerships
    for (const pp of parsedPartnerships) {
      if (pp.parsed_companies.length > 1) {
        const key = pp.parsed_companies.sort().join(' | ');
        if (!partnershipMap.has(key)) {
          partnershipMap.set(key, {
            partners: pp.parsed_companies,
            totalProjects: 0,
            completedProjects: 0,
            ongoingProjects: 0,
            avgSeviye: 0,
          });
        }
      }
    }

    // Fallback: For unparsed partnerships, add them to partnershipMap
    const unparsedPartnerships = await prisma.project.findMany({
      select: { contractor: true },
      where: {
        contractor: { not: null },
        parsed_contractor: { is: null }, // No parsed record
      },
      distinct: ['contractor'],
    });

    for (const up of unparsedPartnerships) {
      if (!up.contractor) continue;
      const contractors = parsePartnership(up.contractor);

      if (contractors.length > 1) {
        const key = contractors.sort().join(' | ');
        if (!partnershipMap.has(key)) {
          partnershipMap.set(key, {
            partners: contractors,
            totalProjects: 0,
            completedProjects: 0,
            ongoingProjects: 0,
            avgSeviye: 0,
          });
        }
      }
    }

    // Get all projects to count by partnership
    const projects = await prisma.project.findMany({
      select: { contractor: true, status: true, seviye_pct: true },
      where: { contractor: { not: null } },
    });

    // Count projects for each partnership
    projects.forEach(project => {
      if (!project.contractor) return;

      const contractors = parsePartnership(project.contractor);

      // Only count if it's a partnership (2+ contractors)
      if (contractors.length > 1) {
        const key = contractors.sort().join(' | ');

        if (!partnershipMap.has(key)) {
          partnershipMap.set(key, {
            partners: contractors,
            totalProjects: 0,
            completedProjects: 0,
            ongoingProjects: 0,
            avgSeviye: 0,
          });
        }

        const partnership = partnershipMap.get(key)!;
        partnership.totalProjects++;

        if (project.status === 'Tamamlandı') {
          partnership.completedProjects++;
        } else if (project.status === 'İnşaat Halinde') {
          partnership.ongoingProjects++;
        }

        if (project.seviye_pct) {
          partnership.avgSeviye = (partnership.avgSeviye * (partnership.totalProjects - 1) + project.seviye_pct) / partnership.totalProjects;
        }
      }
    });

    // Convert to array and sort by total projects
    const sortedPartnerships = Array.from(partnershipMap.values())
      .sort((a, b) => b.totalProjects - a.totalProjects);

    const totalPartnerships = sortedPartnerships.length;
    const partnerships = sortedPartnerships.slice(skip, skip + limit);

    res.json({
      success: true,
      data: {
        partnerships,
        totalPartnerships,
        page,
        limit,
        totalPages: Math.ceil(totalPartnerships / limit),
        topPartnerships: sortedPartnerships.slice(0, 10),
      },
    });
  } catch (error) {
    next(error);
  }
});

// GET /api/partnerships/:id - Get partnership details
router.get('/:id', async (req, res, next) => {
  try {
    const partnershipId = decodeURIComponent(req.params.id);
    const partners = partnershipId.split(' | ');

    // Find all projects for this partnership
    const projects = await prisma.project.findMany({
      where: {
        contractor: {
          not: null,
        },
      },
      include: {
        city: true,
        project_type: true,
      },
    });

    // Filter projects that match this partnership
    const partnershipProjects = projects.filter(p => {
      if (!p.contractor) return false;
      const contractors = parsePartnership(p.contractor);
      return partners.every(partner => 
        contractors.some(c => c.toLowerCase() === partner.toLowerCase())
      );
    });

    if (partnershipProjects.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Partnership not found',
      });
    }

    // Calculate stats
    const stats = {
      partners,
      totalProjects: partnershipProjects.length,
      completedProjects: partnershipProjects.filter(p => p.status === 'Tamamlandı').length,
      ongoingProjects: partnershipProjects.filter(p => p.status === 'İnşaat Halinde').length,
      avgSeviye: partnershipProjects.reduce((sum, p) => sum + (p.seviye_pct || 0), 0) / partnershipProjects.length,
      totalUnits: partnershipProjects.reduce((sum, p) => sum + (p.unit_count || 0), 0),
    };

    res.json({
      success: true,
      data: {
        stats,
        projects: partnershipProjects.map(p => ({
          id: p.id,
          name: p.name,
          city: p.city.name,
          type: p.project_type.name,
          status: p.status,
          seviye: p.seviye_pct,
          unitCount: p.unit_count,
        })),
      },
    });
  } catch (error) {
    next(error);
  }
});

export default router;

