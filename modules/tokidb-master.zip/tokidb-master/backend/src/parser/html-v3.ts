/**
 * Parser V3 - Heuristic Parser
 * Last resort parser using table header matching
 * Works even if HTML structure changes
 */

import axios from 'axios';
import * as cheerio from 'cheerio';
import { ParsedProject, ParserResult, ProjectStatus } from '@tokidb/shared';
import { parseSeviye, parseUnitCount } from './seviye-parser';
import logger from '../config/logger';

const TOKI_URL = process.env.TOKI_URL || 'https://www.toki.gov.tr/illere-gore-projeler';
const TIMEOUT_MS = 5000;

export async function parseWithHeuristic(): Promise<ParserResult> {
  try {
    logger.info('[Parser V3] Starting Heuristic parse...');

    const response = await axios.get(TOKI_URL, {
      timeout: TIMEOUT_MS,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    const $ = cheerio.load(response.data);
    const projects: ParsedProject[] = [];

    // Find all tables
    $('table').each((tableIndex, table) => {
      const $table = $(table);
      
      // Find header row
      const headers: string[] = [];
      $table.find('thead tr th, thead tr td, tbody tr:first-child th, tbody tr:first-child td').each((i, th) => {
        headers.push($(th).text().trim().toLowerCase());
      });

      if (headers.length === 0) return;

      // Map headers to column indices
      const colMap: Record<string, number> = {};
      headers.forEach((header, index) => {
        if (/il|city|şehir/i.test(header)) colMap.city = index;
        if (/proje|project|ad[ıi]/i.test(header)) colMap.name = index;
        if (/tip|type|tür/i.test(header)) colMap.type = index;
        if (/durum|status|hal/i.test(header)) colMap.status = index;
        if (/seviye|progress|%|yüzde/i.test(header)) colMap.seviye = index;
        if (/yüklenici|contractor|firma/i.test(header)) colMap.contractor = index;
        if (/konut|unit|adet/i.test(header)) colMap.units = index;
        if (/detay|detail|link/i.test(header)) colMap.detail = index;
      });

      // Parse data rows
      $table.find('tbody tr').each((rowIndex, row) => {
        try {
          const $row = $(row);
          const cells = $row.find('td');

          if (cells.length === 0) return;

          const cityName = colMap.city !== undefined ? $(cells[colMap.city]).text().trim() : '';
          const projectName = colMap.name !== undefined ? $(cells[colMap.name]).text().trim() : '';
          const projectTypeName = colMap.type !== undefined ? $(cells[colMap.type]).text().trim() : 'Diğer';
          const statusText = colMap.status !== undefined ? $(cells[colMap.status]).text().trim() : '';
          const seviyeText = colMap.seviye !== undefined ? $(cells[colMap.seviye]).text().trim() : '';
          const contractorText = colMap.contractor !== undefined ? $(cells[colMap.contractor]).text().trim() : '';
          const unitCountText = colMap.units !== undefined ? $(cells[colMap.units]).text().trim() : '';
          const detailLink = colMap.detail !== undefined ? $(cells[colMap.detail]).find('a').attr('href') : '';

          if (!cityName || !projectName) return;

          const tokiId = `${cityName.toLowerCase().replace(/\s+/g, '-')}-${projectName.toLowerCase().replace(/\s+/g, '-')}-${tableIndex}-${rowIndex}`;

          let status: ProjectStatus = ProjectStatus.UNKNOWN;
          if (/devam|yapım|in progress/i.test(statusText)) {
            status = ProjectStatus.ACTIVE;
          } else if (/tamamland|bitmi|completed/i.test(statusText)) {
            status = ProjectStatus.COMPLETED;
          } else if (/planl|planned/i.test(statusText)) {
            status = ProjectStatus.PLANNED;
          } else if (/iptal|cancelled/i.test(statusText)) {
            status = ProjectStatus.CANCELLED;
          }

          const project: ParsedProject = {
            toki_id: tokiId,
            name: projectName,
            city_name: cityName,
            project_type_name: projectTypeName,
            status,
            seviye_pct: parseSeviye(seviyeText),
            contractor: contractorText || null,
            unit_count: parseUnitCount(unitCountText),
            detail_url: detailLink ? `https://www.toki.gov.tr${detailLink}` : null,
          };

          projects.push(project);
        } catch (err) {
          logger.warn(`[Parser V3] Failed to parse row ${rowIndex}:`, err);
        }
      });
    });

    logger.info(`[Parser V3] Successfully parsed ${projects.length} projects`);

    return {
      success: true,
      version: 'v3' as any,
      projects,
    };
  } catch (error: any) {
    logger.error('[Parser V3] Parse failed:', error);
    return {
      success: false,
      version: 'v3' as any,
      projects: [],
      error: error.message,
    };
  }
}

