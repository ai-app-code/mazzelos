/**
 * Parser V2 - Playwright-based Parser
 * Fallback parser when Cheerio fails (e.g., JavaScript-rendered content)
 * Slower but handles dynamic content
 */

import { chromium } from 'playwright';
import * as cheerio from 'cheerio';
import { ParsedProject, ParserResult, ProjectStatus } from '@tokidb/shared';
import { parseSeviye, parseUnitCount } from './seviye-parser';
import logger from '../config/logger';

const TOKI_URL = process.env.TOKI_URL || 'https://www.toki.gov.tr/illere-gore-projeler';
const TIMEOUT_MS = 30000;

export async function parseWithPlaywright(): Promise<ParserResult> {
  let browser;
  
  try {
    logger.info('[Parser V2] Starting Playwright parse...');

    // Launch browser
    browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    const context = await browser.newContext({
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    });

    const page = await context.newPage();
    
    // Navigate and wait for content
    await page.goto(TOKI_URL, {
      timeout: TIMEOUT_MS,
      waitUntil: 'networkidle',
    });

    // Wait for table to load
    await page.waitForSelector('table.project-table', { timeout: 10000 });

    // Get HTML content
    const html = await page.content();
    const $ = cheerio.load(html);
    const projects: ParsedProject[] = [];

    // Parse table rows (same logic as V1)
    $('table.project-table tbody tr').each((index, element) => {
      try {
        const $row = $(element);
        
        const cityName = $row.find('td:nth-child(1)').text().trim();
        const projectName = $row.find('td:nth-child(2)').text().trim();
        const projectTypeName = $row.find('td:nth-child(3)').text().trim();
        const statusText = $row.find('td:nth-child(4)').text().trim();
        const seviyeText = $row.find('td:nth-child(5)').text().trim();
        const contractorText = $row.find('td:nth-child(6)').text().trim();
        const unitCountText = $row.find('td:nth-child(7)').text().trim();
        const detailLink = $row.find('td:nth-child(8) a').attr('href');

        if (!cityName || !projectName) {
          return;
        }

        const tokiId = `${cityName.toLowerCase().replace(/\s+/g, '-')}-${projectName.toLowerCase().replace(/\s+/g, '-')}-${index}`;

        let status: ProjectStatus = ProjectStatus.UNKNOWN;
        if (/devam|yapım|in progress/i.test(statusText)) {
          status = ProjectStatus.ACTIVE;
        } else if (/tamamland|bitmi|completed/i.test(statusText)) {
          status = ProjectStatus.COMPLETED;
        } else if (/planl|planned/i.test(statusText)) {
          status = ProjectStatus.PLANNED;
        } else if (/iptal|cancelled/i.test(statusText)) {
          status = ProjectStatus.CANCELLED;
        }

        const project: ParsedProject = {
          toki_id: tokiId,
          name: projectName,
          city_name: cityName,
          project_type_name: projectTypeName || 'Diğer',
          status,
          seviye_pct: parseSeviye(seviyeText),
          contractor: contractorText || null,
          unit_count: parseUnitCount(unitCountText),
          detail_url: detailLink ? `https://www.toki.gov.tr${detailLink}` : null,
        };

        projects.push(project);
      } catch (err) {
        logger.warn(`[Parser V2] Failed to parse row ${index}:`, err);
      }
    });

    await browser.close();

    logger.info(`[Parser V2] Successfully parsed ${projects.length} projects`);

    return {
      success: true,
      version: 'v2' as any,
      projects,
    };
  } catch (error: any) {
    if (browser) {
      await browser.close();
    }
    
    logger.error('[Parser V2] Parse failed:', error);
    return {
      success: false,
      version: 'v2' as any,
      projects: [],
      error: error.message,
    };
  }
}

