/**
 * Auto-Detect Parser
 * Tries parsers in order: V1 (Cheerio) → V2 (Playwright) → V3 (Heuristic)
 * Returns first successful result
 */

import { ParserResult, ParserVersion } from '@tokidb/shared';
import { parseWithCheerio } from './html-v1';
import { parseWithPlaywright } from './html-v2';
import { parseWithHeuristic } from './html-v3';
import logger from '../config/logger';

const FORCE_PARSER = process.env.PARSER_FORCE as ParserVersion | undefined;

export async function autoDetectParse(): Promise<ParserResult> {
  logger.info('[Auto-Detect] Starting parser auto-detection...');

  // If forced to use specific parser
  if (FORCE_PARSER) {
    logger.info(`[Auto-Detect] Forced to use parser: ${FORCE_PARSER}`);
    
    switch (FORCE_PARSER) {
      case 'v1':
        return await parseWithCheerio();
      case 'v2':
        return await parseWithPlaywright();
      case 'v3':
        return await parseWithHeuristic();
      default:
        logger.warn(`[Auto-Detect] Unknown forced parser: ${FORCE_PARSER}, falling back to auto`);
    }
  }

  // Try V1 (Cheerio) - Fast and lightweight
  logger.info('[Auto-Detect] Trying V1 (Cheerio)...');
  const v1Result = await parseWithCheerio();
  
  if (v1Result.success && v1Result.projects.length > 0) {
    logger.info(`[Auto-Detect] V1 succeeded with ${v1Result.projects.length} projects`);
    return v1Result;
  }

  logger.warn('[Auto-Detect] V1 failed, trying V2 (Playwright)...');

  // Try V2 (Playwright) - Handles JavaScript-rendered content
  const v2Result = await parseWithPlaywright();
  
  if (v2Result.success && v2Result.projects.length > 0) {
    logger.info(`[Auto-Detect] V2 succeeded with ${v2Result.projects.length} projects`);
    return {
      ...v2Result,
      fallback_reason: 'V1 (Cheerio) failed or returned no projects',
    };
  }

  logger.warn('[Auto-Detect] V2 failed, trying V3 (Heuristic)...');

  // Try V3 (Heuristic) - Last resort
  const v3Result = await parseWithHeuristic();
  
  if (v3Result.success && v3Result.projects.length > 0) {
    logger.info(`[Auto-Detect] V3 succeeded with ${v3Result.projects.length} projects`);
    return {
      ...v3Result,
      fallback_reason: 'V1 and V2 failed or returned no projects',
    };
  }

  // All parsers failed
  logger.error('[Auto-Detect] All parsers failed');
  return {
    success: false,
    version: 'v3' as any,
    projects: [],
    error: 'All parsers failed to extract projects',
    fallback_reason: 'V1, V2, and V3 all failed',
  };
}

