/**
 * Parser V1 - Cheerio-based HTML Parser
 * Fast, lightweight, server-side jQuery implementation
 * Primary parser for TOKİ website
 */

import axios from 'axios';
import * as cheerio from 'cheerio';
import https from 'https';
import { ParsedProject, ParserResult, ProjectStatus } from '@tokidb/shared';
import { parseSeviye, parseUnitCount } from './seviye-parser';
import { extractCityName } from './city-extractor';
import logger from '../config/logger';

const TOKI_URL = process.env.TOKI_URL || 'https://www.toki.gov.tr/illere-gore-projeler';
const TIMEOUT_MS = 10000;

// SSL bypass agent
const httpsAgent = new https.Agent({
  rejectUnauthorized: false,
});

export async function parseWithCheerio(): Promise<ParserResult> {
  try {
    logger.info('[Parser V1] Starting Cheerio parse...');

    // Fetch HTML
    const response = await axios.get(TOKI_URL, {
      timeout: TIMEOUT_MS,
      httpsAgent,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });

    const $ = cheerio.load(response.data);
    const projects: ParsedProject[] = [];

    // DEBUG: Log table structure
    logger.info('[Parser V1 DEBUG] ===== TABLE STRUCTURE ANALYSIS =====');
    const tableSelector = $('#project-table, table.table').first();
    logger.info(`[Parser V1 DEBUG] Table found: ${tableSelector.length > 0 ? 'YES' : 'NO'}`);

    if (tableSelector.length > 0) {
      const headerRow = tableSelector.find('thead tr, tbody tr').first();
      const headers: string[] = [];
      headerRow.find('th, td').each((i, el) => {
        headers.push($(el).text().trim());
      });
      logger.info(`[Parser V1 DEBUG] Table headers (${headers.length} columns): ${JSON.stringify(headers)}`);

      // Log first 3 data rows structure
      tableSelector.find('tbody tr').slice(0, 3).each((rowIdx, row) => {
        const cells: string[] = [];
        $(row).find('td').each((cellIdx, cell) => {
          cells.push($(cell).text().trim().substring(0, 50)); // First 50 chars
        });
        logger.info(`[Parser V1 DEBUG] Row ${rowIdx} (${cells.length} cells): ${JSON.stringify(cells)}`);
      });
    }
    logger.info('[Parser V1 DEBUG] ===== END TABLE STRUCTURE =====');

    // Parse table rows - TOKİ uses #project-table or .table selector
    $('#project-table tbody tr, table.table tbody tr').each((index, element) => {
      try {
        const $row = $(element);

        // Column structure:
        // td:nth-child(1) = Sıra No (row number)
        // td:nth-child(2) = Proje Adı (city name + project name)
        // td:nth-child(3) = Proje Tipi
        // td:nth-child(4) = Proje Durumu
        // td:nth-child(5) = Yüklenici Firma
        // td:nth-child(6) = Konut Sayısı
        // td:nth-child(7) = Seviye

        const fullProjectName = $row.find('td:nth-child(2)').text().trim();
        const projectTypeName = $row.find('td:nth-child(3)').text().trim();
        const statusText = $row.find('td:nth-child(4)').text().trim();
        const contractorText = $row.find('td:nth-child(5)').text().trim();
        const unitCountText = $row.find('td:nth-child(6)').text().trim();
        const seviyeText = $row.find('td:nth-child(7)').text().trim();
        const detailLink = $row.find('td:nth-child(8) a').attr('href');

        if (!fullProjectName) {
          return; // Skip invalid rows
        }

        // Extract city name using semantic analysis
        // Handles: İl-İlçe format, punctuation, case sensitivity, government projects
        const cityName = extractCityName(fullProjectName);
        const projectName = fullProjectName;

        // DEBUG: Log first 3 projects
        if (index < 3) {
          logger.info(`[Parser V1 DEBUG] Row ${index}: city="${cityName}", project="${projectName}", type="${projectTypeName}"`);
        }

        if (!cityName || !projectName) {
          return; // Skip invalid rows
        }

        // Generate unique toki_id
        const tokiId = `${cityName.toLowerCase().replace(/\s+/g, '-')}-${projectName.toLowerCase().replace(/\s+/g, '-')}-${index}`;

        // Parse status
        let status: ProjectStatus = ProjectStatus.UNKNOWN;
        if (/devam|yapım|in progress/i.test(statusText)) {
          status = ProjectStatus.ACTIVE;
        } else if (/tamamland|bitmi|completed/i.test(statusText)) {
          status = ProjectStatus.COMPLETED;
        } else if (/planl|planned/i.test(statusText)) {
          status = ProjectStatus.PLANNED;
        } else if (/iptal|cancelled/i.test(statusText)) {
          status = ProjectStatus.CANCELLED;
        }

        const project: ParsedProject = {
          toki_id: tokiId,
          name: projectName,
          city_name: cityName,
          project_type_name: projectTypeName || 'Diğer',
          status,
          seviye_pct: parseSeviye(seviyeText),
          contractor: contractorText || null,
          unit_count: parseUnitCount(unitCountText),
          detail_url: detailLink ? `https://www.toki.gov.tr${detailLink}` : null,
        };

        projects.push(project);
      } catch (err) {
        logger.warn(`[Parser V1] Failed to parse row ${index}:`, err);
      }
    });

    logger.info(`[Parser V1] Successfully parsed ${projects.length} projects`);

    return {
      success: true,
      version: 'v1' as any,
      projects,
    };
  } catch (error: any) {
    logger.error('[Parser V1] Parse failed:', error);
    return {
      success: false,
      version: 'v1' as any,
      projects: [],
      error: error.message,
    };
  }
}

