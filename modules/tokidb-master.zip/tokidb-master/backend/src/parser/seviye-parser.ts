/**
 * Seviye (Progress) Parser
 * Extracts percentage from various formats:
 * - "Seviye: %85" → 85
 * - "%75" → 75
 * - "85%" → 85
 * - "Tamamlandı" → 100
 * - "Devam Ediyor" → null
 */

export function parseSeviye(text: string | null | undefined): number | null {
  if (!text) return null;

  const cleaned = text.trim();

  // Check for "Tamamlandı" or similar completion indicators
  if (/tamamland[ıi]|bitmi[şs]|completed/i.test(cleaned)) {
    return 100;
  }

  // Extract percentage using regex
  const percentMatch = cleaned.match(/(\d+(?:\.\d+)?)\s*%/);
  if (percentMatch) {
    const value = parseFloat(percentMatch[1]);
    return value >= 0 && value <= 100 ? value : null;
  }

  // Try to find standalone number (less reliable)
  const numberMatch = cleaned.match(/\b(\d+(?:\.\d+)?)\b/);
  if (numberMatch) {
    const value = parseFloat(numberMatch[1]);
    // Only accept if it looks like a percentage (0-100)
    return value >= 0 && value <= 100 ? value : null;
  }

  return null;
}

/**
 * Parse unit count from text
 * - "1.250 Konut" → 1250
 * - "500 konut" → 500
 */
export function parseUnitCount(text: string | null | undefined): number | null {
  if (!text) return null;

  // Remove dots used as thousand separators in Turkish format
  const cleaned = text.replace(/\./g, '').trim();

  const match = cleaned.match(/(\d+)\s*(?:konut|unit|adet)/i);
  if (match) {
    return parseInt(match[1], 10);
  }

  return null;
}

