/**
 * Semantic City Name Extractor
 * 
 * Intelligently extracts city names from Turkish project descriptions
 * Handles:
 * - İl-İlçe format (e.g., "İstanbul-Tuzla" → "İstanbul")
 * - Punctuation errors (e.g., "Ardahan," → "Ardahan")
 * - Case sensitivity (e.g., "ŞanlıUrfa" → "Şanlıurfa")
 * - Government projects (e.g., "TC Başbakanlık" → "Ankara")
 * - Special cases (e.g., "Kuzey Ankara" → "Ankara", "İzmit" → "Kocaeli")
 */

import logger from '../config/logger';

export interface City {
  name: string;
}

// Hardcoded list of 81 Turkish cities for fast lookup
// This avoids DB queries during parsing
const TURKISH_CITIES: City[] = [
  { name: 'Adana' },
  { name: 'Adıyaman' },
  { name: 'Afyonkarahisar' },
  { name: 'Ağrı' },
  { name: 'Amasya' },
  { name: 'Ankara' },
  { name: 'Antalya' },
  { name: 'Artvin' },
  { name: 'Aydın' },
  { name: 'Balıkesir' },
  { name: 'Bilecik' },
  { name: 'Bingöl' },
  { name: 'Bitlis' },
  { name: 'Bolu' },
  { name: 'Burdur' },
  { name: 'Bursa' },
  { name: 'Çanakkale' },
  { name: 'Çankırı' },
  { name: 'Çorum' },
  { name: 'Denizli' },
  { name: 'Diyarbakır' },
  { name: 'Edirne' },
  { name: 'Elazığ' },
  { name: 'Erzincan' },
  { name: 'Erzurum' },
  { name: 'Eskişehir' },
  { name: 'Gaziantep' },
  { name: 'Giresun' },
  { name: 'Gümüşhane' },
  { name: 'Hakkari' },
  { name: 'Hatay' },
  { name: 'Isparta' },
  { name: 'Mersin' },
  { name: 'İstanbul' },
  { name: 'İzmir' },
  { name: 'Kars' },
  { name: 'Kastamonu' },
  { name: 'Kayseri' },
  { name: 'Kırklareli' },
  { name: 'Kırşehir' },
  { name: 'Kocaeli' },
  { name: 'Konya' },
  { name: 'Kütahya' },
  { name: 'Malatya' },
  { name: 'Manisa' },
  { name: 'Kahramanmaraş' },
  { name: 'Mardin' },
  { name: 'Muğla' },
  { name: 'Muş' },
  { name: 'Nevşehir' },
  { name: 'Niğde' },
  { name: 'Ordu' },
  { name: 'Rize' },
  { name: 'Sakarya' },
  { name: 'Samsun' },
  { name: 'Siirt' },
  { name: 'Sinop' },
  { name: 'Sivas' },
  { name: 'Tekirdağ' },
  { name: 'Tokat' },
  { name: 'Trabzon' },
  { name: 'Tunceli' },
  { name: 'Şanlıurfa' },
  { name: 'Uşak' },
  { name: 'Van' },
  { name: 'Yozgat' },
  { name: 'Zonguldak' },
  { name: 'Aksaray' },
  { name: 'Bayburt' },
  { name: 'Karaman' },
  { name: 'Kırıkkale' },
  { name: 'Batman' },
  { name: 'Şırnak' },
  { name: 'Bartın' },
  { name: 'Ardahan' },
  { name: 'Iğdır' },
  { name: 'Yalova' },
  { name: 'Karabük' },
  { name: 'Kilis' },
  { name: 'Osmaniye' },
  { name: 'Düzce' },
];

/**
 * Extract city name from project name using semantic analysis
 * Uses hardcoded city list for fast lookup without DB queries
 */
export function extractCityName(fullProjectName: string, cities: City[] = TURKISH_CITIES): string {
  const firstWord = fullProjectName.split(/\s+/)[0];
  
  if (!firstWord) {
    logger.warn(`[City Extractor] Empty project name: "${fullProjectName}"`);
    return '';
  }

  // 1. Clean punctuation (comma, semicolon, quotes) - both at start and end
  let cleaned = firstWord.replace(/^[,;']+|[,;']+$/g, '').trim();
  
  // 2. Handle İl-İlçe format (take before dash)
  // Examples: "İstanbul-Tuzla" → "İstanbul", "Ankara-Merkez" → "Ankara"
  if (cleaned.includes('-')) {
    const parts = cleaned.split('-');
    cleaned = parts[0];
    logger.debug(`[City Extractor] İl-İlçe format detected: "${firstWord}" → "${cleaned}"`);
  }
  
  // 3. Try exact match first
  const exactMatch = cities.find(c => c.name === cleaned);
  if (exactMatch) {
    return exactMatch.name;
  }
  
  // 4. Try case-insensitive match
  // Example: "ŞanlıUrfa" → "Şanlıurfa"
  const caseInsensitiveMatch = cities.find(c => c.name.toLowerCase() === cleaned.toLowerCase());
  if (caseInsensitiveMatch) {
    logger.debug(`[City Extractor] Case-insensitive match: "${cleaned}" → "${caseInsensitiveMatch.name}"`);
    return caseInsensitiveMatch.name;
  }
  
  // 5. Handle government/institutional projects
  // These are usually in Ankara but don't have a city name
  const governmentKeywords = [
    'TC', 'T.C.', 
    'Başbakanlık', 
    'RTÜK', 
    'Kamu', 
    'MTA', 
    'Enerji', 
    'Toplu',
    'Türk-Alman',
  ];
  
  if (governmentKeywords.includes(cleaned)) {
    logger.debug(`[City Extractor] Government project detected: "${cleaned}" → "Ankara"`);
    return 'Ankara';
  }
  
  // 6. Special cases
  
  // "Kuzey Ankara Kent Girişi" → "Ankara"
  if (cleaned === 'Kuzey' && fullProjectName.includes('Ankara')) {
    logger.debug(`[City Extractor] Special case: "Kuzey Ankara" → "Ankara"`);
    return 'Ankara';
  }
  
  // "İzmit" is actually in Kocaeli province
  if (cleaned === 'İzmit') {
    logger.debug(`[City Extractor] Special case: "İzmit" → "Kocaeli"`);
    return 'Kocaeli';
  }
  
  // "Selçuk Üniversitesi" → "Konya" (Selçuk University is in Konya)
  if (cleaned === 'Selçuk' && fullProjectName.includes('Üniversitesi')) {
    logger.debug(`[City Extractor] Special case: "Selçuk Üniversitesi" → "Konya"`);
    return 'Konya';
  }
  
  // "Afyon" is the old name for "Afyonkarahisar"
  if (cleaned === 'Afyon') {
    logger.debug(`[City Extractor] Special case: "Afyon" → "Afyonkarahisar"`);
    return 'Afyonkarahisar';
  }

  // "Türk-Alman Üniversitesi" → "İstanbul" (university is in Istanbul)
  if (cleaned === 'Türk' && fullProjectName.includes('Alman Üniversitesi')) {
    logger.debug(`[City Extractor] Special case: "Türk-Alman Üniversitesi" → "İstanbul"`);
    return 'İstanbul';
  }

  // "Merkez Melikgazi" → "Kayseri" (Melikgazi is a district in Kayseri)
  if (cleaned === 'Merkez' && fullProjectName.includes('Melikgazi')) {
    logger.debug(`[City Extractor] Special case: "Merkez Melikgazi" → "Kayseri"`);
    return 'Kayseri';
  }

  // 7. If still no match, log warning and return cleaned name
  logger.warn(`[City Extractor] No match found for: "${cleaned}" (from "${fullProjectName}")`);
  return cleaned;
}

/**
 * Validate if extracted city name exists in database
 */
export function validateCityName(cityName: string, cities: City[]): boolean {
  return cities.some(c => c.name.toLowerCase() === cityName.toLowerCase());
}

/**
 * Get statistics about city extraction
 */
export function getCityExtractionStats(
  projects: Array<{ name: string; city_name: string }>,
  cities: City[]
): {
  total: number;
  valid: number;
  invalid: number;
  invalidCities: Map<string, number>;
} {
  const invalidCities = new Map<string, number>();
  let valid = 0;
  let invalid = 0;

  projects.forEach(p => {
    if (validateCityName(p.city_name, cities)) {
      valid++;
    } else {
      invalid++;
      const count = invalidCities.get(p.city_name) || 0;
      invalidCities.set(p.city_name, count + 1);
    }
  });

  return {
    total: projects.length,
    valid,
    invalid,
    invalidCities,
  };
}

