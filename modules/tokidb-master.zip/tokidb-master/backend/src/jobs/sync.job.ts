/**
 * BullMQ Sync Job
 * Scheduled daily at 02:00 UTC with ±20min jitter
 */

import { Queue, Worker } from 'bullmq';
import { redisConnection } from '../config/redis';
import { runIngest } from '../services/ingest/ingest.service';
import prisma from '../config/database';
import logger from '../config/logger';

const SYNC_QUEUE_NAME = 'sync-queue';

// Create queue
export const syncQueue = new Queue(SYNC_QUEUE_NAME, {
  connection: redisConnection,
});

// Create worker
export const syncWorker = new Worker(
  SYNC_QUEUE_NAME,
  async (job) => {
    logger.info(`[Sync Job] Starting sync job ${job.id}...`);

    // Create sync history record
    const syncHistory = await prisma.syncHistory.create({
      data: {
        started_at: new Date(),
        status: 'RUNNING',
        parser_version: 'unknown',
      },
    });

    try {
      const result = await runIngest();

      // Update sync history
      await prisma.syncHistory.update({
        where: { id: syncHistory.id },
        data: {
          completed_at: new Date(),
          status: result.success ? 'SUCCESS' : 'FAILED',
          parser_version: result.parser_version,
          projects_fetched: result.projects_fetched,
          projects_created: result.projects_created,
          projects_updated: result.projects_updated,
          projects_deleted: result.projects_deleted,
          error_message: result.error || null,
        },
      });

      logger.info(`[Sync Job] Completed: ${result.projects_fetched} fetched, ${result.projects_created} created, ${result.projects_updated} updated`);

      return result;
    } catch (error: any) {
      logger.error('[Sync Job] Failed:', error);

      await prisma.syncHistory.update({
        where: { id: syncHistory.id },
        data: {
          completed_at: new Date(),
          status: 'FAILED',
          error_message: error.message,
        },
      });

      throw error;
    }
  },
  {
    connection: redisConnection,
    concurrency: 1, // Only one sync at a time
  }
);

// Schedule daily sync at 02:00 UTC with ±20min jitter
export async function scheduleDailySync() {
  try {
    // Remove existing repeatable jobs
    const repeatableJobs = await syncQueue.getRepeatableJobs();
    for (const job of repeatableJobs) {
      await syncQueue.removeRepeatableByKey(job.key);
    }

    // Add new repeatable job
    await syncQueue.add(
      'daily-sync',
      {},
      {
        repeat: {
          pattern: '0 2 * * *', // Daily at 02:00 UTC
        },
      }
    );

    logger.info('Daily sync scheduled at 02:00 UTC');
  } catch (error) {
    logger.error('Failed to schedule daily sync:', error);
  }
}

// Worker event handlers
syncWorker.on('completed', (job) => {
  logger.info(`[Sync Job] Job ${job.id} completed`);
});

syncWorker.on('failed', (job, err) => {
  logger.error(`[Sync Job] Job ${job?.id} failed:`, err);
});

