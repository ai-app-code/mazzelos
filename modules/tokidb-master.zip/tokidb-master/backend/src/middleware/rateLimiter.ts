import rateLimit from 'express-rate-limit';

// General rate limiter: 100 requests per 5 minutes (increased for polling)
export const generalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '300000'), // 5 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS || '100'),
  message: {
    success: false,
    error: 'Too many requests, please try again later',
  },
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => {
    // Skip rate limit for log endpoints (they're read-only)
    return req.path.startsWith('/api/logs');
  },
});

// Admin sync limiter: 1 request per 5 minutes (production) or unlimited (development)
const isDev = process.env.NODE_ENV === 'development';
export const adminSyncLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS || '300000'), // 5 minutes
  max: isDev ? 1000 : parseInt(process.env.ADMIN_RATE_LIMIT_MAX || '1'), // Unlimited in dev
  message: {
    success: false,
    error: 'Sync can only be triggered once every 5 minutes',
  },
  standardHeaders: true,
  legacyHeaders: false,
});

