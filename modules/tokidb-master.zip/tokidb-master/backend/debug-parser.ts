import { autoDetectParse } from './src/parser/auto-detect';
import { removeDuplicates } from './src/services/ingest/duplicate-detection.service';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function debugParser() {
  console.log('🔍 DEBUGGING PARSER...\n');
  
  // Step 1: Parse
  console.log('📥 STEP 1: Fetching projects from TOKİ...');
  const parseResult = await autoDetectParse();
  
  if (!parseResult.success) {
    console.error('❌ Parse failed:', parseResult.error);
    return;
  }
  
  console.log(`✅ Fetched ${parseResult.projects.length} projects using parser ${parseResult.version}\n`);
  
  // Step 2: Remove duplicates
  console.log('🔄 STEP 2: Removing duplicates...');
  const uniqueProjects = removeDuplicates(parseResult.projects);
  console.log(`✅ ${uniqueProjects.length} unique projects (removed ${parseResult.projects.length - uniqueProjects.length} duplicates)\n`);
  
  // Step 3: Check City/ProjectType availability
  console.log('🏙️ STEP 3: Checking City/ProjectType availability...');
  
  const cities = await prisma.city.findMany();
  const projectTypes = await prisma.projectType.findMany();
  
  const cityNames = new Set(cities.map(c => c.name));
  const projectTypeNames = new Set(projectTypes.map(pt => pt.name));
  
  let missingCityCount = 0;
  let missingProjectTypeCount = 0;
  const missingCities = new Set<string>();
  const missingProjectTypes = new Set<string>();
  
  for (const project of uniqueProjects) {
    if (!cityNames.has(project.city_name)) {
      missingCityCount++;
      missingCities.add(project.city_name);
    }
    
    if (!projectTypeNames.has(project.project_type_name)) {
      missingProjectTypeCount++;
      missingProjectTypes.add(project.project_type_name);
    }
  }
  
  console.log(`\n📊 RESULTS:`);
  console.log(`Total fetched: ${parseResult.projects.length}`);
  console.log(`After duplicate removal: ${uniqueProjects.length}`);
  console.log(`Missing cities: ${missingCityCount} projects (${missingCities.size} unique cities)`);
  console.log(`Missing project types: ${missingProjectTypeCount} projects (${missingProjectTypes.size} unique types)`);
  
  if (missingCities.size > 0) {
    console.log(`\n❌ Missing cities:`);
    missingCities.forEach(city => console.log(`  - ${city}`));
  }
  
  if (missingProjectTypes.size > 0) {
    console.log(`\n❌ Missing project types:`);
    missingProjectTypes.forEach(type => console.log(`  - ${type}`));
  }
  
  const validProjects = uniqueProjects.filter(p =>
    cityNames.has(p.city_name) && projectTypeNames.has(p.project_type_name)
  );

  console.log(`\n✅ Valid projects (would be created): ${validProjects.length}`);
  console.log(`❌ Invalid projects (would be skipped): ${uniqueProjects.length - validProjects.length}`);

  // Detailed analysis of invalid projects
  console.log(`\n\n🔍 DETAILED ANALYSIS OF INVALID PROJECTS:\n`);

  const invalidProjects = uniqueProjects.filter(p =>
    !cityNames.has(p.city_name) || !projectTypeNames.has(p.project_type_name)
  );

  console.log(`Total invalid: ${invalidProjects.length}\n`);

  // Group by reason
  const missingCityOnly = invalidProjects.filter(p =>
    !cityNames.has(p.city_name) && projectTypeNames.has(p.project_type_name)
  );

  const missingProjectTypeOnly = invalidProjects.filter(p =>
    cityNames.has(p.city_name) && !projectTypeNames.has(p.project_type_name)
  );

  const missingBoth = invalidProjects.filter(p =>
    !cityNames.has(p.city_name) && !projectTypeNames.has(p.project_type_name)
  );

  console.log(`📍 Missing CITY only: ${missingCityOnly.length}`);
  console.log(`🏗️ Missing PROJECT TYPE only: ${missingProjectTypeOnly.length}`);
  console.log(`❌ Missing BOTH: ${missingBoth.length}\n`);

  // Show first 20 examples of each category
  if (missingCityOnly.length > 0) {
    console.log(`\n📍 EXAMPLES - Missing CITY only (first 20):`);
    missingCityOnly.slice(0, 20).forEach((p, i) => {
      console.log(`${i + 1}. City: "${p.city_name}" | Project: "${p.name}" | Type: "${p.project_type_name}"`);
    });
  }

  if (missingProjectTypeOnly.length > 0) {
    console.log(`\n🏗️ EXAMPLES - Missing PROJECT TYPE only (first 20):`);
    missingProjectTypeOnly.slice(0, 20).forEach((p, i) => {
      console.log(`${i + 1}. City: "${p.city_name}" | Project: "${p.name}" | Type: "${p.project_type_name}"`);
    });
  }

  if (missingBoth.length > 0) {
    console.log(`\n❌ EXAMPLES - Missing BOTH (first 20):`);
    missingBoth.slice(0, 20).forEach((p, i) => {
      console.log(`${i + 1}. City: "${p.city_name}" | Project: "${p.name}" | Type: "${p.project_type_name}"`);
    });
  }

  await prisma.$disconnect();
}

debugParser();

