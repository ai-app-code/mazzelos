import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function checkStats() {
  const cityCount = await prisma.city.count();
  const projectTypeCount = await prisma.projectType.count();
  const projectCount = await prisma.project.count();
  
  console.log('📊 DATABASE STATS:');
  console.log(`Cities: ${cityCount}`);
  console.log(`Project Types: ${projectTypeCount}`);
  console.log(`Projects: ${projectCount}`);
  
  // Check recent changes
  const recentChanges = await prisma.projectChange.findMany({
    where: {
      detected_at: {
        gte: new Date(Date.now() - 3600000), // Last hour
      },
    },
    orderBy: { detected_at: 'desc' },
    take: 10,
  });
  
  console.log('\n📝 RECENT CHANGES (Last hour):');
  recentChanges.forEach(change => {
    console.log(`- ${change.change_type} at ${change.detected_at}`);
  });
  
  await prisma.$disconnect();
}

checkStats();

