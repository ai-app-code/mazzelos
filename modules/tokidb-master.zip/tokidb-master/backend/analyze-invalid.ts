import { autoDetectParse } from './src/parser/auto-detect';
import { removeDuplicates } from './src/services/ingest/duplicate-detection.service';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function analyzeInvalid() {
  console.log('🔍 ANALYZING INVALID PROJECTS...\n');
  
  const parseResult = await autoDetectParse();
  const uniqueProjects = removeDuplicates(parseResult.projects);
  
  const cities = await prisma.city.findMany();
  const cityNames = new Set(cities.map(c => c.name));
  
  const invalidProjects = uniqueProjects.filter(p => !cityNames.has(p.city_name));
  
  console.log(`Total invalid: ${invalidProjects.length}\n`);
  console.log(`📋 ALL INVALID PROJECTS:\n`);
  
  // Group by city pattern
  const cityPatterns = new Map<string, any[]>();
  
  invalidProjects.forEach(p => {
    const city = p.city_name;
    if (!cityPatterns.has(city)) {
      cityPatterns.set(city, []);
    }
    cityPatterns.get(city)!.push(p);
  });
  
  // Sort by frequency
  const sorted = Array.from(cityPatterns.entries()).sort((a, b) => b[1].length - a[1].length);
  
  sorted.forEach(([city, projects], idx) => {
    console.log(`\n${idx + 1}. City: "${city}" (${projects.length} projects)`);
    console.log(`   Full project name: "${projects[0].name}"`);
    
    // Analyze pattern
    if (city.includes('-')) {
      const parts = city.split('-');
      console.log(`   ⚠️  PATTERN: İl-İlçe format → "${parts[0]}" - "${parts[1]}"`);
    } else if (city.includes(',')) {
      console.log(`   ⚠️  PATTERN: Virgül var → Parser hatası`);
    } else if (city.includes(';')) {
      console.log(`   ⚠️  PATTERN: Noktalı virgül var → Parser hatası`);
    } else if (city === 'Merkez' || city === 'TC' || city === 'Başbakanlık' || city === 'Kuzey') {
      console.log(`   ⚠️  PATTERN: Garip isim → Parser tamamen yanlış`);
    } else {
      // Check if it's a case sensitivity issue
      const lowerCity = city.toLowerCase();
      const matchingCity = cities.find(c => c.name.toLowerCase() === lowerCity);
      if (matchingCity) {
        console.log(`   ⚠️  PATTERN: Büyük/küçük harf farkı → "${city}" vs "${matchingCity.name}"`);
      } else {
        console.log(`   ⚠️  PATTERN: Bilinmeyen format`);
      }
    }
  });
  
  console.log(`\n\n📊 PATTERN SUMMARY:`);
  
  const ilIlcePattern = sorted.filter(([city]) => city.includes('-')).length;
  const punctuationPattern = sorted.filter(([city]) => city.includes(',') || city.includes(';')).length;
  const weirdPattern = sorted.filter(([city]) => ['Merkez', 'TC', 'Başbakanlık', 'Kuzey', 'Enerji', 'RTÜK', 'Toplu', 'Kamu', 'MTA', 'Türk-Alman', 'Selçuk'].includes(city)).length;
  const casePattern = sorted.filter(([city]) => {
    const lowerCity = city.toLowerCase();
    return cities.some(c => c.name.toLowerCase() === lowerCity);
  }).length;
  
  console.log(`İl-İlçe format: ${ilIlcePattern}`);
  console.log(`Noktalama hatası: ${punctuationPattern}`);
  console.log(`Garip isimler: ${weirdPattern}`);
  console.log(`Büyük/küçük harf: ${casePattern}`);
  console.log(`Diğer: ${sorted.length - ilIlcePattern - punctuationPattern - weirdPattern - casePattern}`);
  
  await prisma.$disconnect();
}

analyzeInvalid();

