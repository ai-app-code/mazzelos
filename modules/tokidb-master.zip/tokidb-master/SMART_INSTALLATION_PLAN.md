# 🧠 Akıllı Kurulum Planı - Windows 11 Pro Temiz Kurulum

**Tarih:** 27 Ekim 2025  
**Sistem:** Windows 11 Pro (Temiz Kurulum)  
**Durum:** Docker Desktop kurulu ama daemon çalışmıyor

---

## 🔍 Mevcut Durum Analizi

### ✅ Kurulu
- Docker Desktop v28.5.1 (GUI açık)
- Git (muhtemelen)

### ❌ Eksik (Temiz Kurulum Nedeniyle)
- Node.js 20+
- npm
- pnpm
- PostgreSQL 15
- Redis 7
- Python (opsiyonel)
- WSL 2 (Docker için gerekli)
- Build tools

### 🔴 KRITIK SORUN
- Docker daemon çalışmıyor
- WSL 2 engine başlatılmamış
- Docker Desktop'ın Linux backend'i aktif değil

---

## 🎯 Çözüm Stratejisi

### Seçenek 1: Docker-First Approach (Önerilen)
**Avantaj:** Tüm dependencies Docker'da, sistem temiz kalır  
**Dezavantaj:** Docker daemon'u çalıştırması gerekli

**Adımlar:**
1. Docker Desktop'ı düzgün başlat (WSL 2 engine)
2. `docker-compose up -d` ile tüm services başlat
3. Backend & Frontend Docker container'larında çalışır

### Seçenek 2: Lokal Development (Alternatif)
**Avantaj:** Daha hızlı, doğrudan kontrol  
**Dezavantaj:** Sistem'e çok şey kurulması gerekli

**Adımlar:**
1. Node.js 20+ kur
2. PostgreSQL 15 kur
3. Redis 7 kur
4. pnpm kur
5. Dependencies kur
6. Lokal dev server başlat

### Seçenek 3: Hibrit Approach (En Akıllı)
**Avantaj:** En iyisi, hızlı + temiz  
**Dezavantaj:** Biraz daha karmaşık setup

**Adımlar:**
1. Node.js 20+ kur (gerekli)
2. Docker'da PostgreSQL & Redis başlat
3. Lokal'da Backend & Frontend çalıştır

---

## 🚀 ÖNERILEN PLAN: Hibrit Approach

### FAZA 1: Docker Daemon'u Başlat (5 dakika)

**Problem:** Docker Desktop açık ama daemon çalışmıyor

**Çözüm:**
```powershell
# Docker Desktop'ı kapat
taskkill /IM "Docker Desktop.exe" /F

# WSL 2 kontrol et
wsl --list --verbose

# WSL 2 yüklü değilse:
wsl --install

# Bilgisayarı yeniden başlat

# Docker Desktop'ı tekrar aç
# (Başlat menüsünden veya C:\Program Files\Docker\Docker\Docker.exe)

# Daemon'u kontrol et
docker ps
```

### FAZA 2: Node.js 20+ Kur (5 dakika)

**Neden gerekli?**
- Backend & Frontend development için
- pnpm package manager için
- Build tools için

**Kurulum:**
```powershell
# Option A: Direct Download (Kolay)
# https://nodejs.org/ → LTS (20+) indir → Installer çalıştır
# "Add to PATH" işaretle → Kurulumu tamamla

# Option B: Windows Package Manager
winget install OpenJS.NodeJS

# Kontrol et
node --version      # v20+
npm --version       # 10+
```

### FAZA 3: pnpm Kur (1 dakika)

```powershell
npm install -g pnpm
pnpm --version      # 8+
```

### FAZA 4: PostgreSQL & Redis Docker'da Başlat (2 dakika)

```powershell
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

# Sadece database services başlat
docker-compose up -d postgres redis

# Kontrol et
docker-compose ps
```

### FAZA 5: Dependencies Kur (5 dakika)

```powershell
pnpm install
```

### FAZA 6: Database Setup (2 dakika)

```powershell
pnpm run db:setup
```

### FAZA 7: Backend Dev Server (Terminal 1)

```powershell
cd backend
pnpm run dev
```

### FAZA 8: Frontend Dev Server (Terminal 2)

```powershell
cd frontend
pnpm run dev
```

### FAZA 9: Tarayıcıda Test

```
http://localhost:3000
```

---

## 📊 Kurulum Süresi

| Faza | Adım | Süre |
|------|------|------|
| 1 | Docker Daemon | 5 min |
| 2 | Node.js | 5 min |
| 3 | pnpm | 1 min |
| 4 | PostgreSQL & Redis | 2 min |
| 5 | Dependencies | 5 min |
| 6 | Database Setup | 2 min |
| 7 | Backend Server | 1 min |
| 8 | Frontend Server | 1 min |
| **TOPLAM** | | **~22 dakika** |

---

## 🔧 Docker MCP Faydası

**Docker MCP (Model Context Protocol):**
- Docker Desktop'ı programatik olarak kontrol edebilir
- Container'ları yönetebilir
- Logs okuyabilir
- Health checks yapabilir

**Faydası:**
- ✅ Docker daemon durumunu otomatik kontrol edebilirim
- ✅ Services'i otomatik başlatıp durdurabilir
- ✅ Sorunları otomatik teşhis edebilirim
- ✅ Logs'u otomatik analiz edebilirim

**Dezavantajı:**
- ❌ Şu anda Docker daemon çalışmadığı için kullanamıyorum
- ❌ Docker daemon başladıktan sonra faydalı olur

---

## ⚠️ Kritik Noktalar

### 1. Docker Daemon Başlatılması ZORUNLU
- Şu anda çalışmıyor
- WSL 2 engine başlatılması gerekli
- Bilgisayar yeniden başlatılması gerekebilir

### 2. Node.js Kurulumu ZORUNLU
- Backend & Frontend için gerekli
- "Add to PATH" seçeneği işaretlenmelidir
- PowerShell yeniden açılmalıdır

### 3. Windows 11 Temiz Kurulum
- Çok şey eksik (normal)
- Kurulum süresi biraz uzun (normal)
- Tüm dependencies otomatik kurulacak

---

## ✅ Kontrol Listesi

- [ ] Docker Desktop kapatıldı
- [ ] WSL 2 kontrol edildi
- [ ] Docker Desktop yeniden açıldı
- [ ] `docker ps` çalışıyor
- [ ] Node.js 20+ kurulu
- [ ] npm 10+ kurulu
- [ ] pnpm 8+ kurulu
- [ ] PostgreSQL & Redis Docker'da çalışıyor
- [ ] Dependencies kuruldu
- [ ] Database migration tamamlandı
- [ ] Backend dev server çalışıyor
- [ ] Frontend dev server çalışıyor
- [ ] http://localhost:3000 açılıyor

---

## 🎯 Sonraki Adımlar

1. **Hemen:** Docker Desktop'ı düzgün başlat
2. **Sonra:** Node.js 20+ kur
3. **Sonra:** pnpm kur
4. **Sonra:** PostgreSQL & Redis başlat
5. **Sonra:** Dependencies kur
6. **Sonra:** Backend & Frontend başlat
7. **Sonra:** Tarayıcıda test et

---

## 📞 Sorun Giderme

### Docker daemon çalışmıyor
```powershell
# Docker Desktop'ı yeniden başlat
taskkill /IM "Docker Desktop.exe" /F
# Başlat menüsünden Docker Desktop'ı aç

# WSL 2 kontrol et
wsl --list --verbose

# WSL 2 yüklü değilse
wsl --install
# Bilgisayarı yeniden başlat
```

### Node.js kurulumu başarısız
```powershell
# PowerShell'i yeniden aç
# Veya PATH'i manuel ekle:
# Kontrol Paneli > Sistem > Gelişmiş Sistem Ayarları > Ortam Değişkenleri
```

### Port zaten kullanımda
```powershell
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

---

## 🎉 Özet

**Hibrit Approach en akıllı çözüm:**
- ✅ Docker'da database (PostgreSQL, Redis)
- ✅ Lokal'da Node.js (Backend, Frontend)
- ✅ Hızlı, temiz, yönetilebilir
- ✅ ~22 dakikada tamamlanır

**Başlamaya hazır mısınız?** 🚀

