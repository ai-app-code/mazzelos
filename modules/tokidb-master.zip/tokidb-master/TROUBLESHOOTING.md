# 🆘 Troubleshooting Guide

**TOKİDB Sorun Giderme Rehberi**

---

## 🔧 Kurulum Sorunları

### Node.js/pnpm Kurulumu

**Problem:** `pnpm: command not found`

**Çözüm:**
```bash
# Node.js 20+ kur
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# pnpm kur
npm install -g pnpm

# Versiyonları kontrol et
node --version  # v20+
pnpm --version  # 8+
```

### Dependencies Kurulumu

**Problem:** `pnpm install` başarısız

**Çözüm:**
```bash
# Cache temizle
pnpm store prune

# Yeniden kur
pnpm install --force

# Specific package
pnpm add package-name
```

---

## 🗄️ Database Sorunları

### PostgreSQL Bağlantı Hatası

**Problem:** `Error: connect ECONNREFUSED 127.0.0.1:5432`

**Çözüm:**
```bash
# PostgreSQL çalışıyor mu kontrol et
sudo systemctl status postgresql

# Başlat
sudo systemctl start postgresql

# Docker'da çalışıyorsa
docker-compose ps postgres
docker-compose logs postgres
```

### Migration Hatası

**Problem:** `Migration failed`

**Çözüm:**
```bash
# Mevcut migrations kontrol et
pnpm run db:status

# Reset ve yeniden migrate
pnpm run db:reset
pnpm run db:migrate

# Seed data
pnpm run db:seed
```

### Bağlantı Havuzu Dolu

**Problem:** `Error: too many connections`

**Çözüm:**
```bash
# Prisma connection pool ayarla
# .env dosyasında
DATABASE_URL="postgresql://user:pass@localhost/db?schema=public&connection_limit=10"

# Veya prisma.schema'da
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}
```

---

## 🔴 Backend Sorunları

### Port Zaten Kullanımda

**Problem:** `Error: listen EADDRINUSE :::3001`

**Çözüm:**
```bash
# Port kullanan process bul
lsof -i :3001

# Process'i kapat
kill -9 <PID>

# Veya farklı port kullan
PORT=3002 pnpm run dev
```

### JWT Token Hatası

**Problem:** `401 Unauthorized`

**Çözüm:**
```bash
# JWT_SECRET kontrol et
echo $JWT_SECRET

# Token expire oldu mu kontrol et
# Token payload'ını decode et
# https://jwt.io

# Yeni token al
curl -X POST http://localhost:3001/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@tokidb.local","password":"admin123"}'
```

### API Endpoint Hatası

**Problem:** `404 Not Found` veya `500 Internal Server Error`

**Çözüm:**
```bash
# Logs kontrol et
docker-compose logs backend

# Endpoint var mı kontrol et
curl http://localhost:3001/api/cities

# Request format kontrol et
curl -X GET http://localhost:3001/api/projects \
  -H "Content-Type: application/json"
```

### Rate Limiting

**Problem:** `429 Too Many Requests`

**Çözüm:**
```bash
# Rate limit ayarlarını kontrol et
# backend/src/index.ts

# Veya 5 dakika bekle
sleep 300
```

---

## 🎨 Frontend Sorunları

### Build Hatası

**Problem:** `Build failed`

**Çözüm:**
```bash
# Next.js cache temizle
rm -rf .next

# Yeniden build
pnpm run build

# Type errors kontrol et
pnpm run type-check
```

### API Bağlantı Hatası

**Problem:** `Failed to fetch from API`

**Çözüm:**
```bash
# API URL kontrol et
echo $NEXT_PUBLIC_API_URL

# Backend çalışıyor mu
curl http://localhost:3001/health

# CORS ayarları kontrol et
# backend/src/index.ts
```

### Login Başarısız

**Problem:** `Invalid credentials`

**Çözüm:**
```bash
# Kimlik bilgileri kontrol et
# Email: admin@tokidb.local
# Password: admin123

# Veya .env'de ayarla
ADMIN_EMAIL=admin@tokidb.local
ADMIN_PASSWORD=admin123
```

### Sayfa Yüklenmedi

**Problem:** `Blank page` veya `500 error`

**Çözüm:**
```bash
# Browser console kontrol et (F12)
# Network tab'da requests kontrol et
# Application tab'da localStorage kontrol et

# Cache temizle
# Ctrl+Shift+Delete (Chrome)
# Cmd+Shift+Delete (Mac)
```

---

## 🐳 Docker Sorunları

### Container Başlamıyor

**Problem:** `Container exited with code 1`

**Çözüm:**
```bash
# Logs kontrol et
docker-compose logs backend

# Image rebuild
docker-compose build --no-cache backend

# Yeniden başlat
docker-compose restart backend
```

### Volume Sorunları

**Problem:** `Permission denied` veya `Volume not found`

**Çözüm:**
```bash
# Volumes listele
docker volume ls

# Volume temizle
docker volume prune

# Yeniden oluştur
docker-compose down -v
docker-compose up -d
```

### Network Sorunları

**Problem:** `Cannot reach service`

**Çözüm:**
```bash
# Network kontrol et
docker network ls

# Services arasında ping
docker-compose exec backend ping redis

# DNS kontrol et
docker-compose exec backend nslookup postgres
```

---

## 📊 Performance Sorunları

### Yavaş API Response

**Problem:** `API response > 200ms`

**Çözüm:**
```bash
# Database queries optimize et
# Indexes ekle
# N+1 queries kontrol et

# Response time ölç
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:3001/api/projects

# Caching ekle
# Redis cache
# TanStack Query cache
```

### Yüksek Memory Kullanımı

**Problem:** `Out of memory`

**Çözüm:**
```bash
# Memory limit ayarla
docker-compose.yml'de
mem_limit: 512m

# Veya Node.js heap size
NODE_OPTIONS="--max-old-space-size=512"
```

### Yavaş Build

**Problem:** `Build takes > 5 minutes`

**Çözüm:**
```bash
# Cache kullan
pnpm run build -- --cache

# Parallel build
pnpm run build -- --parallel

# Incremental build
pnpm run build -- --incremental
```

---

## 🔒 Security Sorunları

### CORS Hatası

**Problem:** `Access to XMLHttpRequest blocked by CORS`

**Çözüm:**
```bash
# CORS ayarları kontrol et
# backend/src/index.ts

# Origin whitelist ekle
const corsOptions = {
  origin: ['http://localhost:3000', 'https://tokidb.com'],
  credentials: true
};
```

### SSL Certificate Hatası

**Problem:** `SSL certificate problem`

**Çözüm:**
```bash
# Certificate kontrol et
openssl x509 -in cert.pem -text -noout

# Yeni certificate oluştur
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365
```

---

## 📝 Logging & Debugging

### Debug Mode Aç

```bash
# Backend
DEBUG=* pnpm run dev

# Frontend
NEXT_DEBUG=true pnpm run dev
```

### Logs Kontrol Et

```bash
# Docker logs
docker-compose logs -f backend

# File logs
tail -f logs/app.log

# Sentry errors
# https://sentry.io/organizations/tokidb/issues/
```

---

## 📞 Daha Fazla Yardım

- **GitHub Issues:** https://github.com/tokidb/app/issues
- **Email:** support@tokidb.local
- **Slack:** #tokidb-support

---

**Last Updated:** 25 Ekim 2025

