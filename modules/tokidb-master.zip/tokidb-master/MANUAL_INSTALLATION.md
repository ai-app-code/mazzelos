# 📥 Manuel Kurulum Rehberi (Docker Dışı)

**TOKİDB Projesini Docker olmadan kurmak için adım adım talimatlar**

---

## 🔴 ADIM 1: Node.js 20+ Kur (5 dakika)

### Windows:

1. **https://nodejs.org/ adresine git**
   - LTS versiyonunu (20+) seç
   - Windows Installer (.msi) indir

2. **Installer'ı çalıştır**
   - İndirilen dosyaya çift tıkla
   - "Next" butonuna tıkla

3. **Kurulum Seçenekleri**
   - ✅ "Add to PATH" seçeneğini işaretle (ÖNEMLİ!)
   - ✅ "Automatically install the necessary tools..." seçeneğini işaretle
   - "Next" butonuna tıkla

4. **Kurulumu Tamamla**
   - "Install" butonuna tıkla
   - Kurulum tamamlanana kadar bekle
   - "Finish" butonuna tıkla

5. **PowerShell'i Yeniden Aç**
   - Tüm PowerShell pencerelerini kapat
   - Yeni bir PowerShell penceresi aç

6. **Kontrol Et**
   ```powershell
   node --version      # v20.x.x
   npm --version       # 10.x.x
   ```

---

## 🟡 ADIM 2: PostgreSQL 15 Kur (5 dakika) - Opsiyonel

### Windows:

1. **https://www.postgresql.org/download/windows/ adresine git**
   - "Download the installer" butonuna tıkla
   - En son versiyonu (15+) seç

2. **Installer'ı Çalıştır**
   - İndirilen dosyaya çift tıkla
   - "Next" butonuna tıkla

3. **Kurulum Seçenekleri**
   - Installation Directory: Varsayılan bırak
   - "Next" butonuna tıkla

4. **Port Ayarı**
   - Port: **5432** (varsayılan)
   - "Next" butonuna tıkla

5. **Password Ayarı**
   - Password: **postgres** (veya güvenli bir şifre)
   - Confirm Password: Aynı şifreyi gir
   - "Next" butonuna tıkla

6. **Kurulumu Tamamla**
   - "Install" butonuna tıkla
   - Kurulum tamamlanana kadar bekle
   - "Finish" butonuna tıkla

7. **Kontrol Et**
   ```powershell
   psql --version
   ```

---

## 🟡 ADIM 3: Redis 7 Kur (5 dakika) - Opsiyonel

### Windows:

1. **https://github.com/microsoftarchive/redis/releases adresine git**
   - "Redis-x64-x.x.x.msi" dosyasını indir

2. **Installer'ı Çalıştır**
   - İndirilen dosyaya çift tıkla
   - "Next" butonuna tıkla

3. **Kurulum Seçenekleri**
   - Installation Directory: Varsayılan bırak
   - "Next" butonuna tıkla

4. **Port Ayarı**
   - Port: **6379** (varsayılan)
   - "Next" butonuna tıkla

5. **Kurulumu Tamamla**
   - "Install" butonuna tıkla
   - Kurulum tamamlanana kadar bekle
   - "Finish" butonuna tıkla

6. **Kontrol Et**
   ```powershell
   redis-cli --version
   ```

---

## 🟢 ADIM 4: pnpm Kur (1 dakika)

```powershell
npm install -g pnpm

# Kontrol et
pnpm --version      # 8+
```

---

## 🟢 ADIM 5: Dependencies Kur (5 dakika)

```powershell
cd g:\Drive'ım\ai-uygulama-geliştirme\tokidb\app

pnpm install

# Kontrol et
pnpm list
```

---

## 🟢 ADIM 6: Environment Setup (1 dakika)

```powershell
# .env dosyası oluştur
cp .env.example .env

# .env dosyasını düzenle (opsiyonel)
# Varsayılan değerler zaten ayarlanmış
```

---

## 🟢 ADIM 7: Database Setup (2 dakika)

### Eğer PostgreSQL & Redis lokal kurulu ise:

```powershell
pnpm run db:setup
```

### Eğer Docker kullanacaksan:

```powershell
# Terminal 1: PostgreSQL & Redis başlat
docker-compose up -d postgres redis

# Bekleme: ~30 saniye

# Terminal 2: Database setup
pnpm run db:setup
```

---

## 🟢 ADIM 8: Backend Dev Server Başlat (Terminal 1)

```powershell
cd backend
pnpm run dev

# Bekleme: ~10 saniye
# Çıktı: "Server running on http://localhost:3001"
```

---

## 🟢 ADIM 9: Frontend Dev Server Başlat (Terminal 2)

```powershell
cd frontend
pnpm run dev

# Bekleme: ~15 saniye
# Çıktı: "ready - started server on 0.0.0.0:3000"
```

---

## 🟢 ADIM 10: Tarayıcıda Aç

```
http://localhost:3000
```

---

## 🟢 ADIM 11: Giriş Yap

- **Email:** admin@tokidb.local
- **Şifre:** admin123

---

## ✅ Başarılı Kurulum Kontrol Listesi

- [ ] Node.js 20+ kurulu (`node --version`)
- [ ] npm 10+ kurulu (`npm --version`)
- [ ] pnpm 8+ kurulu (`pnpm --version`)
- [ ] PostgreSQL 15 kurulu (`psql --version`) - Opsiyonel
- [ ] Redis 7 kurulu (`redis-cli --version`) - Opsiyonel
- [ ] Dependencies kuruldu (`pnpm install`)
- [ ] .env dosyası oluşturuldu
- [ ] Database migration tamamlandı (`pnpm run db:setup`)
- [ ] Backend dev server çalışıyor (Terminal 1)
- [ ] Frontend dev server çalışıyor (Terminal 2)
- [ ] http://localhost:3000 açılıyor
- [ ] Login sayfası görünüyor
- [ ] Demo kimlik bilgileri ile giriş yapılıyor

---

## 🆘 Sorun Giderme

### Node.js kurulumu başarısız

```powershell
# Kurulumdan sonra PowerShell'i yeniden aç
# Veya PATH'i manuel olarak ekle:
# Kontrol Paneli > Sistem > Gelişmiş Sistem Ayarları > Ortam Değişkenleri
```

### PostgreSQL bağlantı hatası

```powershell
# PostgreSQL çalışıyor mu kontrol et
Get-Service postgresql-x64-15

# Başlat
Start-Service postgresql-x64-15
```

### Redis bağlantı hatası

```powershell
# Redis çalışıyor mu kontrol et
Get-Service Redis

# Başlat
Start-Service Redis
```

### Port zaten kullanımda

```powershell
# Port kullanan process'i bul
netstat -ano | findstr :3000

# Process'i kapat
taskkill /PID <PID> /F
```

---

## 📊 Kurulum Süresi

| Adım | Süre |
|------|------|
| Node.js | 5 min |
| PostgreSQL | 5 min (opsiyonel) |
| Redis | 5 min (opsiyonel) |
| pnpm | 1 min |
| Dependencies | 5 min |
| Database Setup | 2 min |
| Backend Server | 1 min |
| Frontend Server | 1 min |
| **TOPLAM** | **~25 dakika** |

---

## 🎯 Sonraki Adımlar

1. ✅ Tüm adımları tamamla
2. ✅ Frontend'i test et
3. ✅ Admin panel'i test et
4. ✅ API endpoints'i test et
5. ✅ Tests çalıştır
6. ✅ Production deployment'ı yap

---

**Başlamaya hazır mısınız?** 🚀

