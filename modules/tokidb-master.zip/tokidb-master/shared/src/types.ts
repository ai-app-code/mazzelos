/**
 * Shared Types and Zod Schemas for TOKİDB
 */

import { z } from 'zod';
import { ProjectStatus, ChangeType, AlertType, ParserVersion } from './constants';

// ============================================================================
// Database Models (matching Prisma schema)
// ============================================================================

export interface City {
  id: number;
  name: string;
  plate_code: number;
  created_at: Date;
}

export interface ProjectType {
  id: number;
  name: string;
  slug: string;
  created_at: Date;
}

export interface Project {
  id: number;
  toki_id: string;
  name: string;
  city_id: number;
  project_type_id: number;
  status: ProjectStatus;
  seviye_pct: number | null;
  contractor: string | null;
  unit_count: number | null;
  detail_url: string | null;
  last_synced_at: Date | null;
  created_at: Date;
  updated_at: Date;
}

export interface ProjectSnapshot {
  id: number;
  project_id: number;
  seviye_pct: number | null;
  status: ProjectStatus;
  contractor: string | null;
  unit_count: number | null;
  name: string;
  project_type_id: number;
  detail_url: string | null;
  snapshot_at: Date;
  created_at: Date;
}

export interface ProjectChange {
  id: number;
  project_id: number;
  change_type: ChangeType;
  field_name: string | null;
  old_value: string | null;
  new_value: string | null;
  detected_at: Date;
  created_at: Date;
}

export interface SyncHistory {
  id: number;
  started_at: Date;
  completed_at: Date | null;
  status: 'RUNNING' | 'SUCCESS' | 'FAILED';
  parser_version: ParserVersion;
  projects_fetched: number;
  projects_created: number;
  projects_updated: number;
  projects_deleted: number;
  error_message: string | null;
  created_at: Date;
}

export interface Alert {
  id: number;
  alert_type: AlertType;
  project_id: number | null;
  message: string;
  metadata: any;
  sent_at: Date | null;
  created_at: Date;
}

// ============================================================================
// Zod Validation Schemas
// ============================================================================

export const ProjectStatusSchema = z.nativeEnum(ProjectStatus);
export const ChangeTypeSchema = z.nativeEnum(ChangeType);
export const AlertTypeSchema = z.nativeEnum(AlertType);
export const ParserVersionSchema = z.nativeEnum(ParserVersion);

export const CitySchema = z.object({
  id: z.number(),
  name: z.string(),
  plate_code: z.number(),
  created_at: z.date()
});

export const ProjectTypeSchema = z.object({
  id: z.number(),
  name: z.string(),
  slug: z.string(),
  created_at: z.date()
});

export const ProjectSchema = z.object({
  id: z.number(),
  toki_id: z.string(),
  name: z.string(),
  city_id: z.number(),
  project_type_id: z.number(),
  status: ProjectStatusSchema,
  seviye_pct: z.number().nullable(),
  contractor: z.string().nullable(),
  unit_count: z.number().nullable(),
  detail_url: z.string().url().nullable(),
  last_synced_at: z.date().nullable(),
  created_at: z.date(),
  updated_at: z.date()
});

// ============================================================================
// API Request/Response Types
// ============================================================================

export const PaginationQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20)
});

export const ProjectFilterSchema = z.object({
  city_id: z.coerce.number().int().optional(),
  project_type_id: z.coerce.number().int().optional(),
  status: ProjectStatusSchema.optional(),
  search: z.string().optional(),
  min_seviye: z.coerce.number().min(0).max(100).optional(),
  max_seviye: z.coerce.number().min(0).max(100).optional()
});

export const ProjectListQuerySchema = PaginationQuerySchema.merge(ProjectFilterSchema);

export type PaginationQuery = z.infer<typeof PaginationQuerySchema>;
export type ProjectFilter = z.infer<typeof ProjectFilterSchema>;
export type ProjectListQuery = z.infer<typeof ProjectListQuerySchema>;

// ============================================================================
// Parser Types
// ============================================================================

export interface ParsedProject {
  toki_id: string;
  name: string;
  city_name: string;
  project_type_name: string;
  status: ProjectStatus;
  seviye_pct: number | null;
  contractor: string | null;
  unit_count: number | null;
  detail_url: string | null;
}

export interface ParserResult {
  success: boolean;
  version: ParserVersion;
  projects: ParsedProject[];
  error?: string;
  fallback_reason?: string;
}

// ============================================================================
// Diff Types
// ============================================================================

export interface DiffResult {
  change_type: ChangeType;
  field_changes: FieldChange[];
  needs_snapshot: boolean;
}

export interface FieldChange {
  field_name: string;
  old_value: any;
  new_value: any;
}

// ============================================================================
// Export Types
// ============================================================================

export const ExportFormatSchema = z.enum(['csv', 'json']);
export type ExportFormat = z.infer<typeof ExportFormatSchema>;

export interface ExportOptions {
  format: ExportFormat;
  filters?: ProjectFilter;
  include_snapshots?: boolean;
  include_changes?: boolean;
}

// ============================================================================
// Auth Types
// ============================================================================

export const LoginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

export type LoginRequest = z.infer<typeof LoginSchema>;

export interface AuthResponse {
  token: string;
  user: {
    email: string;
  };
}

// ============================================================================
// API Response Wrapper
// ============================================================================

export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    total_pages?: number;
  };
}

