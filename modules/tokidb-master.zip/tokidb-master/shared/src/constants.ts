/**
 * Shared Constants for TOKİDB
 * Used across backend and frontend
 */

// Project Status Enum
export enum ProjectStatus {
  ACTIVE = 'ACTIVE',
  COMPLETED = 'COMPLETED',
  PLANNED = 'PLANNED',
  CANCELLED = 'CANCELLED',
  UNKNOWN = 'UNKNOWN'
}

// Change Type Enum
export enum ChangeType {
  CREATED = 'CREATED',
  UPDATED = 'UPDATED',
  REGRESSED = 'REGRESSED',
  META_UPDATED = 'META_UPDATED',
  DELETED = 'DELETED'
}

// Alert Type Enum
export enum AlertType {
  NEW_PROJECT = 'NEW_PROJECT',
  LEVEL_INCREASE = 'LEVEL_INCREASE',
  LEVEL_DECREASE = 'LEVEL_DECREASE',
  STATUS_CHANGE = 'STATUS_CHANGE',
  SYNC_ERROR = 'SYNC_ERROR',
  PARSER_FALLBACK = 'PARSER_FALLBACK'
}

// Parser Version Enum
export enum ParserVersion {
  V1_CHEERIO = 'v1',
  V2_PLAYWRIGHT = 'v2',
  V3_HEURISTIC = 'v3'
}

// Tracked Fields - Fields that trigger snapshots when changed
export const TRACKED_FIELDS = [
  'seviye_pct',
  'status',
  'contractor',
  'unit_count',
  'name',
  'project_type_id',
  'detail_url'
] as const;

// Project Types (5 types)
export const PROJECT_TYPES = [
  { id: 1, name: 'Konut', slug: 'konut' },
  { id: 2, name: 'Sosyal Donatı', slug: 'sosyal-donati' },
  { id: 3, name: 'Altyapı', slug: 'altyapi' },
  { id: 4, name: 'Kentsel Dönüşüm', slug: 'kentsel-donusum' },
  { id: 5, name: 'Diğer', slug: 'diger' }
] as const;

// Snapshot Retention
export const SNAPSHOT_RETENTION_DAYS = 180;
export const HIGH_CHURN_LIMIT_PER_DAY = 1;

// Rate Limits
export const RATE_LIMIT_WINDOW_MS = 5 * 60 * 1000; // 5 minutes
export const RATE_LIMIT_MAX_REQUESTS = 30;
export const ADMIN_RATE_LIMIT_MAX = 1; // 1 request per 5 min for admin sync

// Sync Schedule
export const SYNC_CRON = '0 2 * * *'; // Daily at 02:00 UTC
export const SYNC_JITTER_MS = 20 * 60 * 1000; // ±20 minutes

// Duplicate Detection
export const LEVENSHTEIN_THRESHOLD = 3;

// Pagination
export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 100;

// Export Limits
export const MAX_EXPORT_RECORDS = 10000;

// TOKİ URL
export const TOKI_BASE_URL = 'https://www.toki.gov.tr';
export const TOKI_PROJECTS_URL = `${TOKI_BASE_URL}/illere-gore-projeler`;

// Parser Timeouts
export const CHEERIO_TIMEOUT_MS = 10000;
export const PLAYWRIGHT_TIMEOUT_MS = 30000;
export const HEURISTIC_TIMEOUT_MS = 5000;

// Log Levels
export const LOG_LEVELS = ['error', 'warn', 'info', 'debug'] as const;
export type LogLevel = typeof LOG_LEVELS[number];

// JWT
export const JWT_EXPIRES_IN = '7d';
export const JWT_ALGORITHM = 'HS256';

// Default Admin Credentials (CHANGE IN PRODUCTION!)
export const DEFAULT_ADMIN_EMAIL = 'admin@tokidb.local';
export const DEFAULT_ADMIN_PASSWORD = 'admin123';

