# 🏗️ TOKİDB - TOKİ Proje Takip Sistemi

TOKİ (Toplu Konut İdaresi) projelerini otomatik olarak takip eden, seviye değişikliklerini izleyen ve raporlayan tam kapsamlı web uygulaması.

## ✨ Özellikler

- 🔄 **Otomatik Senkronizasyon** - Günlük 02:00 UTC'de otomatik sync
- 📊 **3-Tier Parser Sistemi** - Cheerio → Playwright → Heuristic fallback
- 📈 **Level-Based Diff** - Seviye artış/azalış otomatik tespiti
- 📸 **Selective Snapshots** - Sadece değişikliklerde snapshot
- 🔍 **Duplicate Detection** - Levenshtein distance < 3
- 🔔 **Real-time Alerts** - Slack webhook entegrasyonu
- 📤 **Export** - CSV & JSON formatında export
- 🔐 **JWT Authentication** - Güvenli admin paneli

## 🚀 Hızlı Başlangıç

```bash
# 1. Dependencies
pnpm install

# 2. Database (Docker)
docker-compose up -d postgres redis

# 3. Prisma
pnpm --filter backend run db:migrate
pnpm --filter backend run db:seed

# 4. Development
pnpm dev
```

**Erişim:**
- Frontend: http://localhost:3000
- Backend: http://localhost:3001
- Admin: `admin@tokidb.local` / `admin123`

## 📁 Yapı

```
tokidb/
├── backend/          # Node.js + Express + Prisma
├── frontend/         # Next.js 15 + React 19
├── shared/           # Ortak types
└── docker-compose.yml
```

## 🔌 API

```
GET  /api/cities
GET  /api/projects
POST /api/auth/login
POST /api/sync
POST /api/export
```

## 🐳 Production

```bash
docker-compose -f docker-compose.prod.yml up -d
```

---

**Status:** ✅ Production Ready | **Updated:** 27 Oct 2025
