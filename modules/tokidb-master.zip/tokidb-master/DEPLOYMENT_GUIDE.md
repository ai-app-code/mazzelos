# 🚀 Deployment Guide

**TOKİDB Production Deployment**

---

## 📋 Pre-Deployment Checklist

- [ ] All tests passing
- [ ] Security audit completed
- [ ] Performance optimized
- [ ] Environment variables configured
- [ ] Database backups enabled
- [ ] Monitoring setup
- [ ] SSL certificates ready
- [ ] Domain configured

---

## 🐳 Docker Deployment

### Build Docker Images

```bash
# Build backend image
docker build -f backend/Dockerfile -t tokidb-backend:latest .

# Build frontend image
docker build -f frontend/Dockerfile -t tokidb-frontend:latest .

# Or use docker-compose
docker-compose build
```

### Production docker-compose.yml

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_DB: tokidb
      POSTGRES_USER: tokidb
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U tokidb"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 5s
      retries: 5

  backend:
    image: tokidb-backend:latest
    environment:
      NODE_ENV: production
      DATABASE_URL: postgresql://tokidb:${DB_PASSWORD}@postgres:5432/tokidb
      REDIS_URL: redis://redis:6379
      JWT_SECRET: ${JWT_SECRET}
      ADMIN_EMAIL: ${ADMIN_EMAIL}
      ADMIN_PASSWORD: ${ADMIN_PASSWORD}
      SENTRY_DSN: ${SENTRY_DSN}
    ports:
      - "3001:3001"
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  frontend:
    image: tokidb-frontend:latest
    environment:
      NEXT_PUBLIC_API_URL: https://api.tokidb.com
    ports:
      - "3000:3000"
    depends_on:
      - backend
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000"]
      interval: 30s
      timeout: 10s
      retries: 3

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./ssl:/etc/nginx/ssl:ro
    depends_on:
      - frontend
      - backend

volumes:
  postgres_data:
```

### Start Services

```bash
# Start all services
docker-compose -f docker-compose.prod.yml up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

---

## 🌐 Nginx Configuration

```nginx
upstream backend {
  server backend:3001;
}

upstream frontend {
  server frontend:3000;
}

server {
  listen 80;
  server_name tokidb.com www.tokidb.com;
  
  # Redirect to HTTPS
  return 301 https://$server_name$request_uri;
}

server {
  listen 443 ssl http2;
  server_name tokidb.com www.tokidb.com;

  ssl_certificate /etc/nginx/ssl/cert.pem;
  ssl_certificate_key /etc/nginx/ssl/key.pem;

  # Security headers
  add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
  add_header X-Frame-Options "DENY" always;
  add_header X-Content-Type-Options "nosniff" always;
  add_header X-XSS-Protection "1; mode=block" always;

  # Frontend
  location / {
    proxy_pass http://frontend;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
  }

  # API
  location /api {
    proxy_pass http://backend;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    
    # Rate limiting
    limit_req zone=api burst=100 nodelay;
  }

  # Health check
  location /health {
    proxy_pass http://backend;
  }
}
```

---

## 🔐 Environment Variables

Create `.env.production`:

```bash
# Database
DATABASE_URL=postgresql://tokidb:password@postgres:5432/tokidb

# Redis
REDIS_URL=redis://redis:6379

# JWT
JWT_SECRET=your-secret-key-here

# Admin
ADMIN_EMAIL=admin@tokidb.com
ADMIN_PASSWORD=secure-password

# Monitoring
SENTRY_DSN=https://...@sentry.io/...
SLACK_WEBHOOK_URL=https://hooks.slack.com/...

# Frontend
NEXT_PUBLIC_API_URL=https://api.tokidb.com
```

---

## 📊 Database Setup

```bash
# Run migrations
docker-compose exec backend pnpm run db:migrate

# Seed data (optional)
docker-compose exec backend pnpm run db:seed

# Backup database
docker-compose exec postgres pg_dump -U tokidb tokidb > backup.sql

# Restore database
docker-compose exec -T postgres psql -U tokidb tokidb < backup.sql
```

---

## 📈 Monitoring & Logging

### Sentry Setup
```typescript
import * as Sentry from "@sentry/node";

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
  tracesSampleRate: 1.0,
});
```

### Slack Alerts
```typescript
const sendSlackAlert = async (message: string) => {
  await fetch(process.env.SLACK_WEBHOOK_URL, {
    method: 'POST',
    body: JSON.stringify({ text: message })
  });
};
```

---

## 🔄 CI/CD Pipeline

### GitHub Actions (.github/workflows/deploy.yml)

```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build images
        run: docker-compose build
      
      - name: Push to registry
        run: |
          docker login -u ${{ secrets.DOCKER_USER }} -p ${{ secrets.DOCKER_PASS }}
          docker-compose push
      
      - name: Deploy to production
        run: |
          ssh -i ${{ secrets.SSH_KEY }} user@server 'cd /app && docker-compose pull && docker-compose up -d'
```

---

## 🆘 Troubleshooting

### Container won't start
```bash
# Check logs
docker-compose logs backend

# Rebuild image
docker-compose build --no-cache backend
```

### Database connection error
```bash
# Check database is running
docker-compose ps postgres

# Check connection string
echo $DATABASE_URL
```

### Port already in use
```bash
# Find process using port
lsof -i :3000

# Kill process
kill -9 <PID>
```

---

## ✅ Post-Deployment

- [ ] Verify all services running
- [ ] Test API endpoints
- [ ] Check monitoring dashboards
- [ ] Verify backups
- [ ] Test failover
- [ ] Document deployment

---

**Last Updated:** 25 Ekim 2025

